import { test, describe } from 'node:test';
import assert from 'node:assert';
import { LocationService } from '../src/services/location/LocationService.js';
import { RouteService } from '../src/services/routing/RouteService.js';
import { calculateHaversineDistanceKm, isCoordinateDuplicate } from '../src/utils/geo.js';
import {
  saveDestination,
  getSavedDestinations,
  deleteSavedDestination,
  getCuratedDestinations,
  getDestinationById,
  addFavourite,
  getFavourites,
  SEED_DESTINATIONS
} from '../src/controllers/destinationController.js';
import { memoryStore } from '../src/config/db.js';

describe('RoamReady Worldwide Dynamic Location & Routing Engine Tests', () => {

  const locationService = new LocationService();
  const routeService = new RouteService();

  // Test 1: Coordinate parsing regex
  test('Coordinate Parser: accurately identifies and parses latitude, longitude pairs', () => {
    // Madikeri coordinates
    const p1 = locationService.parseCoordinates('12.4244, 75.7382');
    assert.ok(p1 !== null);
    assert.strictEqual(p1.latitude, 12.4244);
    assert.strictEqual(p1.longitude, 75.7382);

    // Negative coordinates (Sydney)
    const p2 = locationService.parseCoordinates('-33.8688, 151.2093');
    assert.ok(p2 !== null);
    assert.strictEqual(p2.latitude, -33.8688);
    assert.strictEqual(p2.longitude, 151.2093);

    // Coordinate with spaces
    const p3 = locationService.parseCoordinates('  35.6762  ,  139.6503  ');
    assert.ok(p3 !== null);
    assert.strictEqual(p3.latitude, 35.6762);
    assert.strictEqual(p3.longitude, 139.6503);

    // Invalid coordinates out of range
    const pInvalidLat = locationService.parseCoordinates('95.4244, 75.7382');
    assert.strictEqual(pInvalidLat, null);

    const pInvalidLon = locationService.parseCoordinates('12.4244, 195.7382');
    assert.strictEqual(pInvalidLon, null);

    // Non-coordinate text
    const pText = locationService.parseCoordinates('Tokyo, Japan');
    assert.strictEqual(pText, null);
  });

  // Test 2: Direct coordinate lookup handler
  test('Coordinate Search: synthesizes valid normalized destination for lat, lon inputs', async () => {
    const results = await locationService.search('12.4244, 75.7382');
    assert.ok(Array.isArray(results));
    assert.strictEqual(results.length, 1);

    const loc = results[0];
    assert.strictEqual(loc.isCoordinateInput, true);
    assert.strictEqual(loc.latitude, 12.4244);
    assert.strictEqual(loc.longitude, 75.7382);
    assert.ok(loc.name.length > 0);
    assert.ok(loc.displayName.length > 0);
    assert.strictEqual(typeof loc.category, 'string');
    assert.strictEqual(loc.source, 'provider');
  });

  // Test 3: Haversine distance and duplicate coordinate matching
  test('Coordinate Proximity: detects duplicate locations within 100 meters', () => {
    const lat1 = 12.4244;
    const lon1 = 75.7382;

    // Point 10 meters away
    const lat2 = 12.42448;
    const lon2 = 75.73825;
    assert.strictEqual(isCoordinateDuplicate(lat1, lon1, lat2, lon2, 0.1), true);

    // Point 5 kilometers away
    const lat3 = 12.4542;
    const lon3 = 75.7196;
    assert.strictEqual(isCoordinateDuplicate(lat1, lon1, lat3, lon3, 0.1), false);
  });

  // Test 4: Geocoding caching mechanism
  test('In-Memory Caching: respects rate limits and returns cached entries on repeat queries', async () => {
    const query = '12.4244, 75.7382';
    const firstCall = await locationService.search(query);
    const secondCall = await locationService.search(query);

    assert.strictEqual(firstCall[0].id, secondCall[0].id);
    assert.ok(locationService.cache.size >= 1);
  });

  // Test 5: Provider Status Report
  test('Provider Architecture: reports modular provider configuration and legal rate limits', () => {
    const status = locationService.getServiceStatus();
    assert.strictEqual(status.service, 'RoamReady Global Geocoding Engine');
    assert.ok(status.primaryProvider.provider);
    assert.ok(status.fallbackProvider.provider);
  });

  // Test 6: Route planning calculation (OSRM or Geodesic Vector fallback)
  test('Route Planning: computes distance, duration, and waypoint polyline between worldwide locations', async () => {
    // Tokyo (35.6762, 139.6503) to Yokohama (35.4437, 139.6380) approx 28-35 km
    const route = await routeService.planRoute({
      startLat: 35.6762,
      startLon: 139.6503,
      endLat: 35.4437,
      endLon: 139.6380,
      startName: 'Tokyo',
      endName: 'Yokohama'
    });

    assert.strictEqual(route.success, true);
    assert.ok(route.distanceKm > 20 && route.distanceKm < 50);
    assert.ok(route.durationMinutes > 15);
    assert.ok(Array.isArray(route.coordinates) && route.coordinates.length >= 2);
    assert.ok(route.offlineNavigationDisclaimer.length > 0);
  });

  // Test 7: Destination saving & duplicate detection
  test('Destination Saving: successfully saves dynamic destination and flags duplicates', async () => {
    let statusCode = 200;
    let responseData = null;

    const mockRes = {
      status(code) {
        statusCode = code;
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    // Save a new worldwide destination: Kedarnath
    const req1 = {
      body: {
        name: 'Kedarnath Temple',
        displayName: 'Kedarnath Temple, Rudraprayag, Uttarakhand, India',
        latitude: 30.7346,
        longitude: 79.0669,
        category: 'temples',
        country: 'India',
        state: 'Uttarakhand',
        externalId: 'osm_node_kedarnath_9999',
        provider: 'nominatim'
      }
    };

    await saveDestination(req1, mockRes, () => {});
    assert.strictEqual(statusCode, 201);
    assert.strictEqual(responseData.success, true);
    assert.strictEqual(responseData.isDuplicate, false);
    assert.strictEqual(responseData.destination.name, 'Kedarnath Temple');

    // Attempt to save the exact same destination again -> Must detect duplicate!
    await saveDestination(req1, mockRes, () => {});
    assert.strictEqual(statusCode, 200);
    assert.strictEqual(responseData.isDuplicate, true);
    assert.ok(responseData.message.includes('already'));

    // Attempt to save a duplicate by coordinate proximity (<100m) with a slightly different title
    const reqNear = {
      body: {
        name: 'Kedarnath Shrine View',
        latitude: 30.73465,
        longitude: 79.06692,
        category: 'viewpoints'
      }
    };
    await saveDestination(reqNear, mockRes, () => {});
    assert.strictEqual(responseData.isDuplicate, true);
  });

  // Test 8: Curated seed destinations preservation
  test('Curated Seed Data: preserves all 8 original seed tourist destinations intact', async () => {
    let responseData = null;
    const mockRes = {
      json(data) {
        responseData = data;
        return this;
      }
    };

    await getCuratedDestinations({}, mockRes, () => {});
    assert.strictEqual(responseData.success, true);
    assert.ok(responseData.count >= 8);

    const names = responseData.destinations.map(d => d.name);
    assert.ok(names.some(n => n.includes('Madikeri')));
    assert.ok(names.some(n => n.includes('Abbey Falls')));
    assert.ok(names.some(n => n.includes('Chikmagalur')));
    assert.ok(names.some(n => n.includes('Gokarna')));
    assert.ok(names.some(n => n.includes('Ooty')));
    assert.ok(names.some(n => n.includes('Wayanad')));
    assert.ok(names.some(n => n.includes('Jog Falls')));
    assert.ok(names.some(n => n.includes('Dudhsagar')));
  });

  // Test 9: Favourites management and deduplication
  test('Favourites Management: adds and lists user favourites with deduplication', async () => {
    let statusCode = 200;
    let responseData = null;
    const mockRes = {
      status(code) {
        statusCode = code;
        return this;
      },
      json(data) {
        responseData = data;
        return this;
      }
    };

    // Add favourite
    const favReq = {
      user: { id: 1 },
      body: {
        customPlaceName: 'Mandalpatti Peak Ridge',
        placeCategory: 'hills',
        latitude: 12.5028,
        longitude: 75.7297
      }
    };

    await addFavourite(favReq, mockRes, () => {});
    assert.strictEqual(statusCode, 201);
    assert.strictEqual(responseData.success, true);

    // List favourites
    await getFavourites({ user: { id: 1 } }, mockRes, () => {});
    assert.strictEqual(responseData.success, true);
    assert.ok(responseData.favourites.some(f => f.custom_place_name === 'Mandalpatti Peak Ridge'));
  });

});
