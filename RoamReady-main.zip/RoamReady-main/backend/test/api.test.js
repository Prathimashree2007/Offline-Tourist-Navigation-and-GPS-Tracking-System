import { test, describe } from 'node:test';
import assert from 'node:assert';

describe('RoamReady Backend Unit Tests', () => {
  test('Health check endpoint format verification', async () => {
    const res = {
      status: 'online',
      service: 'RoamReady REST API Backend',
      mysql_connected: false
    };
    assert.strictEqual(res.status, 'online');
    assert.strictEqual(typeof res.service, 'string');
  });

  test('Haversine distance calculation logic', () => {
    // Madikeri to Abbey Falls distance
    const lat1 = 12.4244, lon1 = 75.7382;
    const lat2 = 12.4542, lon2 = 75.7196;

    const toRad = deg => (deg * Math.PI) / 180;
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const d = 6371 * c;

    // Abbey falls is approx 3.8 to 4.2 km straight line from Madikeri center
    assert.ok(d > 3.0 && d < 5.0, `Calculated distance ${d}km is within expected range`);
  });
});
