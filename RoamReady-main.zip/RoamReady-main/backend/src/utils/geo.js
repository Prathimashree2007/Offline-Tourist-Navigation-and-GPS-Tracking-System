/**
 * Backend GIS & Haversine Utilities
 */

const EARTH_RADIUS_KM = 6371.0;

export function toRadians(degrees) {
  return (degrees * Math.PI) / 180.0;
}

export function calculateHaversineDistanceKm(lat1, lon1, lat2, lon2) {
  if (lat1 === lat2 && lon1 === lon2) return 0;

  const dLat = toRadians(lat2 - lat1);
  const dLon = toRadians(lon2 - lon1);
  const radLat1 = toRadians(lat1);
  const radLat2 = toRadians(lat2);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(radLat1) * Math.cos(radLat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_KM * c;
}

/**
 * Checks if two coordinates are within proximityThresholdKm (default 100 meters / 0.1 km)
 */
export function isCoordinateDuplicate(lat1, lon1, lat2, lon2, proximityThresholdKm = 0.1) {
  const dist = calculateHaversineDistanceKm(lat1, lon1, lat2, lon2);
  return dist <= proximityThresholdKm;
}
