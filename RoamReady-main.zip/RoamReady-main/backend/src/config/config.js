// Gracefully load dotenv if installed, otherwise fallback to process.env
try {
  const dotenv = await import('dotenv');
  if (dotenv && dotenv.default && typeof dotenv.default.config === 'function') {
    dotenv.default.config();
  }
} catch {
  // operating without local dotenv package
}

export const config = {
  port: process.env.PORT || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  jwtSecret: process.env.JWT_SECRET || 'roamready_jwt_fallback_secret_ise_2026',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    database: process.env.DB_NAME || 'roamready_db',
    connectionLimit: 10
  },
  geocoding: {
    provider: process.env.GEOCODING_PROVIDER || 'nominatim',
    userAgent: process.env.GEOCODING_USER_AGENT || 'RoamReady-Academic-Navigation-App/1.0 (ise.mini.project@roamready.local)',
    apiKey: process.env.GEOCODING_API_KEY || ''
  }
};
