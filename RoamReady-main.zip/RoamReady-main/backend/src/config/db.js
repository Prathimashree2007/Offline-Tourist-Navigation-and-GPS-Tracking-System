import { config } from './config.js';

let pool = null;
let isConnected = false;

// In-memory fallback stores if MySQL is offline or during offline demonstrations
export const memoryStore = {
  users: [
    {
      id: 1,
      name: 'Priya Sharma',
      email: 'priya@roamready.app',
      password_hash: '$2b$10$wE9l1hR.mKqyWsqsF7H5UuYk8tF96j7lF9P8Wc15iX7C8A9mS0F7m',
      preferred_distance_unit: 'km',
      created_at: new Date()
    }
  ],
  downloaded_maps: [],
  travel_history: [],
  favourites: [],
  saved_destinations: []
};

export async function initDatabase() {
  try {
    const mysql = (await import('mysql2/promise')).default;
    pool = mysql.createPool({
      host: config.db.host,
      port: config.db.port,
      user: config.db.user,
      password: config.db.password,
      database: config.db.database,
      waitForConnections: true,
      connectionLimit: config.db.connectionLimit,
      queueLimit: 0
    });

    const connection = await pool.getConnection();
    connection.release();
    isConnected = true;
    console.log(`[Database] Connected to MySQL successfully at ${config.db.host}:${config.db.port}/${config.db.database}`);
    return pool;
  } catch (err) {
    console.warn(`[Database] MySQL connection notice: ${err.message}`);
    console.warn('[Database] Operating with resilient internal datastore. To connect MySQL, ensure roamready_db exists.');
    isConnected = false;
    return null;
  }
}

export function isDbConnected() {
  return isConnected;
}

export function getPool() {
  return pool;
}
