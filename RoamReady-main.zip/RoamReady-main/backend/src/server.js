import express from 'express';
import cors from 'cors';
import { config } from './config/config.js';
import { initDatabase, isDbConnected } from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import destinationRoutes from './routes/destinationRoutes.js';
import locationRoutes from './routes/locationRoutes.js';
import tripRoutes from './routes/tripRoutes.js';
import mapRoutes from './routes/mapRoutes.js';
import { notFoundHandler, errorHandler } from './middleware/errorMiddleware.js';

const app = express();

// Standard middlewares
app.use(cors({
  origin: true, // Allow frontend during development and production
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// System Health & Diagnostics Endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    service: 'RoamReady REST API Backend',
    timestamp: new Date().toISOString(),
    mysql_connected: isDbConnected(),
    node_version: process.version
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/destinations', destinationRoutes);
app.use('/api/locations', locationRoutes);
app.use('/api/trips', tripRoutes);
app.use('/api/maps', mapRoutes);

// Error Handling
app.use(notFoundHandler);
app.use(errorHandler);

// Bootstrap Server
async function startServer() {
  await initDatabase();
  app.listen(config.port, () => {
    console.log(`====================================================`);
    console.log(`🌲 RoamReady REST API Server running on port ${config.port}`);
    console.log(`📍 Environment: ${config.nodeEnv}`);
    console.log(`⚡ Health check: http://localhost:${config.port}/api/health`);
    console.log(`====================================================`);
  });
}

startServer();

export default app;
