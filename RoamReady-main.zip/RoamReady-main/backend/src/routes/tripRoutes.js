import express from 'express';
import { syncTrip, getUserTrips, deleteTrip } from '../controllers/tripController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';

const router = express.Router();

router.use(authenticateToken);

router.post('/sync', syncTrip);
router.get('/', getUserTrips);
router.delete('/:id', deleteTrip);

export default router;
