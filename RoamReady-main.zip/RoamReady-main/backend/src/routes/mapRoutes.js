import express from 'express';
import { syncDownloadedMap, getUserDownloadedMaps } from '../controllers/mapController.js';
import { authenticateToken } from '../middleware/authMiddleware.js';

const router = express.Router();

router.use(authenticateToken);

router.post('/sync', syncDownloadedMap);
router.get('/', getUserDownloadedMaps);

export default router;
