import express from 'express';
import {
  searchLocations,
  getLocationDetails,
  reverseGeocodeLocation,
  planRoute,
  getLocationProviderInfo
} from '../controllers/locationController.js';

const router = express.Router();

// Worldwide dynamic search
router.get('/search', searchLocations);

// Reverse geocoding (lat, lon -> location)
router.get('/reverse', reverseGeocodeLocation);

// Route planning between two points
router.get('/route', planRoute);

// Service & provider status
router.get('/status', getLocationProviderInfo);

// Place details
router.get('/details/:id', getLocationDetails);

export default router;
