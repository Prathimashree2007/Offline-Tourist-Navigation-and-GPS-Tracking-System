import express from 'express';
import {
  searchDestinations,
  getCuratedDestinations,
  getDestinationById,
  saveDestination,
  getSavedDestinations,
  deleteSavedDestination,
  addFavourite,
  getFavourites,
  removeFavourite
} from '../controllers/destinationController.js';

const router = express.Router();

// Curated destinations list and search (Preserved for backwards compatibility)
router.get('/search', searchDestinations);
router.get('/curated', getCuratedDestinations);

// Saved worldwide destinations
router.get('/saved', getSavedDestinations);
router.post('/save', saveDestination);
router.post('/', saveDestination);
router.delete('/saved/:id', deleteSavedDestination);

// Favourites endpoints
router.post('/favourites', addFavourite);
router.get('/favourites', getFavourites);
router.delete('/favourites/:id', removeFavourite);

// Lookup destination by ID
router.get('/:id', getDestinationById);
router.delete('/:id', deleteSavedDestination);

export default router;
