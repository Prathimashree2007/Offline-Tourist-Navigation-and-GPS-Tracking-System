import { LocationProvider } from './LocationProvider.js';

/**
 * OpenStreetMap Nominatim Geocoding Provider
 * Complies with OSM Nominatim Usage Policy:
 * - Identifiable User-Agent and contact header
 * - Rate-limited requests (minimum 1 second between queries)
 * - Normalized output with rich category, state, country, and bounding box
 */
export class NominatimProvider extends LocationProvider {
  constructor(options = {}) {
    super('nominatim');
    this.baseUrl = options.baseUrl || 'https://nominatim.openstreetmap.org';
    this.userAgent = options.userAgent || 'RoamReady-Academic-Navigation-App/1.0 (ise.mini.project@roamready.local)';
    this.timeoutMs = options.timeoutMs || 8000;
    this.lastRequestTimestamp = 0;
  }

  /**
   * Enforces 1 req/sec pacing to comply with Nominatim Acceptable Use Policy
   */
  async _enforceRateLimit() {
    const now = Date.now();
    const elapsed = now - this.lastRequestTimestamp;
    if (elapsed < 1000) {
      await new Promise(resolve => setTimeout(resolve, 1000 - elapsed));
    }
    this.lastRequestTimestamp = Date.now();
  }

  /**
   * Maps raw OSM class/type into RoamReady travel categories
   */
  _mapCategory(osmClass, osmType) {
    const natural = (osmClass || '').toLowerCase();
    const type = (osmType || '').toLowerCase();

    if (type.includes('waterfall') || natural === 'waterfall') return 'waterfalls';
    if (type.includes('beach') || natural === 'beach') return 'beaches';
    if (type.includes('peak') || type.includes('mountain') || natural === 'volcano') return 'hills';
    if (type.includes('viewpoint') || type.includes('scenic')) return 'viewpoints';
    if (type.includes('temple') || type.includes('church') || type.includes('mosque') || type.includes('place_of_worship')) return 'temples';
    if (type.includes('castle') || type.includes('monument') || type.includes('ruins') || type.includes('fort') || type.includes('historical')) return 'historical';
    if (type.includes('lake') || type.includes('reservoir') || natural === 'water') return 'lakes';
    if (type.includes('park') || type.includes('garden') || natural === 'wood' || natural === 'forest') return 'forests';
    if (type.includes('hospital') || type.includes('clinic') || type.includes('pharmacy')) return 'emergency';
    if (type.includes('hotel') || type.includes('hostel') || type.includes('guest_house')) return 'hotel';
    if (type.includes('restaurant') || type.includes('cafe')) return 'restaurant';
    return 'other';
  }

  /**
   * Normalizes Nominatim raw JSON into standard RoamReady Location entity
   */
  _normalizeItem(item) {
    const lat = parseFloat(item.lat);
    const lon = parseFloat(item.lon);
    const addr = item.address || {};

    const name = item.name || 
                 addr.tourism || 
                 addr.leisure || 
                 addr.historic || 
                 addr.amenity || 
                 addr.natural || 
                 addr.city || 
                 addr.town || 
                 addr.village || 
                 (item.display_name ? item.display_name.split(',')[0].trim() : 'Unnamed Location');

    const state = addr.state || addr.state_district || addr.region || addr.province || '';
    const country = addr.country || '';
    const city = addr.city || addr.town || addr.village || addr.municipality || addr.county || '';

    let bbox = null;
    if (Array.isArray(item.boundingbox) && item.boundingbox.length === 4) {
      bbox = [
        parseFloat(item.boundingbox[0]), // minLat
        parseFloat(item.boundingbox[1]), // maxLat
        parseFloat(item.boundingbox[2]), // minLon
        parseFloat(item.boundingbox[3])  // maxLon
      ];
    }

    return {
      id: `osm_${item.osm_type || 'node'}_${item.osm_id || Math.round(lat * 10000)}`,
      externalId: String(item.osm_id || ''),
      osmType: item.osm_type || 'node',
      provider: 'nominatim',
      name,
      displayName: item.display_name || name,
      city,
      state,
      country,
      latitude: lat,
      longitude: lon,
      category: this._mapCategory(item.class, item.type),
      type: item.type || item.class || 'place',
      importance: item.importance || 0,
      boundingBox: bbox,
      isCurated: false,
      source: 'provider'
    };
  }

  async searchLocations(query, options = {}) {
    if (!query || typeof query !== 'string' || !query.trim()) {
      return [];
    }

    await this._enforceRateLimit();

    const limit = Math.min(Math.max(parseInt(options.limit, 10) || 10, 1), 25);
    const params = new URLSearchParams({
      q: query.trim(),
      format: 'jsonv2',
      addressdetails: '1',
      limit: String(limit)
    });

    if (options.countrycodes) {
      params.append('countrycodes', options.countrycodes);
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const url = `${this.baseUrl}/search?${params.toString()}`;
      const res = await fetch(url, {
        signal: controller.signal,
        headers: {
          'User-Agent': this.userAgent,
          'Accept-Language': 'en'
        }
      });

      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`Nominatim query failed with status ${res.status} (${res.statusText})`);
      }

      const data = await res.json();
      if (!Array.isArray(data)) return [];

      return data.map(item => this._normalizeItem(item));
    } catch (err) {
      clearTimeout(timeout);
      throw err;
    }
  }

  async getLocationDetails(id) {
    if (!id) return null;
    await this._enforceRateLimit();

    const cleanId = id.replace(/^osm_/, '');
    const parts = cleanId.split('_');
    const osmType = parts[0]?.charAt(0).toUpperCase() || 'N';
    const osmId = parts[1] || cleanId;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const url = `${this.baseUrl}/details?osmtype=${osmType}&osmid=${osmId}&format=json&addressdetails=1`;
      const res = await fetch(url, {
        signal: controller.signal,
        headers: {
          'User-Agent': this.userAgent,
          'Accept-Language': 'en'
        }
      });
      clearTimeout(timeout);

      if (!res.ok) return null;
      const data = await res.json();
      return this._normalizeItem(data);
    } catch {
      clearTimeout(timeout);
      return null;
    }
  }

  async reverseGeocode(latitude, longitude) {
    await this._enforceRateLimit();

    const params = new URLSearchParams({
      lat: String(latitude),
      lon: String(longitude),
      format: 'jsonv2',
      addressdetails: '1',
      zoom: '16'
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const url = `${this.baseUrl}/reverse?${params.toString()}`;
      const res = await fetch(url, {
        signal: controller.signal,
        headers: {
          'User-Agent': this.userAgent,
          'Accept-Language': 'en'
        }
      });
      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`Nominatim reverse geocode failed with status ${res.status}`);
      }

      const data = await res.json();
      if (!data || data.error) return null;

      return this._normalizeItem(data);
    } catch (err) {
      clearTimeout(timeout);
      throw err;
    }
  }

  getProviderInformation() {
    return {
      provider: 'nominatim',
      attribution: 'Data © OpenStreetMap contributors, ODbL 1.0. http://osm.org/copyright',
      baseUrl: this.baseUrl,
      rateLimitPolicy: 'Polite 1-second pacing enforced, identifiable academic User-Agent',
      isConfigured: true,
      requiresApiKey: false
    };
  }
}
