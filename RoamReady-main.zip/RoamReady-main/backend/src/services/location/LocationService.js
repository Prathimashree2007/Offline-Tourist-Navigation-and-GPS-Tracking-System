import { NominatimProvider } from './NominatimProvider.js';
import { PhotonProvider } from './PhotonProvider.js';

/**
 * Unified Location Service
 * Coordinates worldwide location queries with:
 * 1. Latitude / Longitude regex recognition
 * 2. In-memory TTL caching
 * 3. Primary provider with transparent secondary failover
 * 4. Coordinate normalization and validation
 */
export class LocationService {
  constructor(config = {}) {
    const primaryName = (config.provider || process.env.GEOCODING_PROVIDER || 'nominatim').toLowerCase();

    this.nominatim = new NominatimProvider({
      userAgent: process.env.GEOCODING_USER_AGENT || 'RoamReady-Academic-Navigation-App/1.0 (ise.mini.project@roamready.local)'
    });
    this.photon = new PhotonProvider();

    this.primaryProvider = primaryName === 'photon' ? this.photon : this.nominatim;
    this.fallbackProvider = primaryName === 'photon' ? this.nominatim : this.photon;

    // Cache responses for 10 minutes to respect external rate limits
    this.cache = new Map();
    this.cacheTtlMs = 10 * 60 * 1000;
  }

  /**
   * Tests whether an input string is a valid latitude, longitude coordinate pair.
   * Examples: "12.4244, 75.7382", "30.7346, 79.0669", " -33.8688 , 151.2093 "
   */
  parseCoordinates(query) {
    if (!query || typeof query !== 'string') return null;

    // Matches standard lat, lon decimal formats
    const coordRegex = /^\s*(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$/;
    const match = query.match(coordRegex);

    if (!match) return null;

    const lat = parseFloat(match[1]);
    const lon = parseFloat(match[2]);

    if (lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) {
      return { latitude: lat, longitude: lon };
    }
    return null;
  }

  _getCached(key) {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() - entry.timestamp > this.cacheTtlMs) {
      this.cache.delete(key);
      return null;
    }
    return entry.data;
  }

  _setCached(key, data) {
    // Keep cache size bounded
    if (this.cache.size > 200) {
      const oldestKey = this.cache.keys().next().value;
      this.cache.delete(oldestKey);
    }
    this.cache.set(key, { data, timestamp: Date.now() });
  }

  /**
   * Main location search interface
   */
  async search(query, options = {}) {
    const trimmed = (query || '').trim();
    if (!trimmed) return [];

    // 1. Check if the query is a direct Coordinate input
    const coords = this.parseCoordinates(trimmed);
    if (coords) {
      const cacheKey = `coord:${coords.latitude.toFixed(5)}:${coords.longitude.toFixed(5)}`;
      const cachedCoord = this._getCached(cacheKey);
      if (cachedCoord) return [cachedCoord];

      const coordResult = await this.handleCoordinateSearch(coords.latitude, coords.longitude);
      this._setCached(cacheKey, coordResult);
      return [coordResult];
    }

    // 2. Check in-memory cache
    const cacheKey = `search:${trimmed.toLowerCase()}:${options.limit || 10}:${options.category || 'all'}`;
    const cached = this._getCached(cacheKey);
    if (cached) return cached;

    // 3. Try primary provider
    try {
      let results = await this.primaryProvider.searchLocations(trimmed, options);

      // If category filter requested, filter results if applicable
      if (options.category && options.category !== 'all') {
        const filtered = results.filter(r => r.category === options.category);
        if (filtered.length > 0) results = filtered;
      }

      this._setCached(cacheKey, results);
      return results;
    } catch (primaryErr) {
      console.warn(`[LocationService] Primary provider (${this.primaryProvider.name}) failed: ${primaryErr.message}. Attempting fallback.`);

      // 4. Failover to secondary provider
      try {
        const fallbackResults = await this.fallbackProvider.searchLocations(trimmed, options);
        this._setCached(cacheKey, fallbackResults);
        return fallbackResults;
      } catch (fallbackErr) {
        console.error(`[LocationService] Secondary provider (${this.fallbackProvider.name}) also failed: ${fallbackErr.message}`);
        throw new Error(`Location search provider is temporarily unavailable: ${primaryErr.message}`);
      }
    }
  }

  /**
   * Handles direct coordinate searches by synthesizing a location and reverse geocoding
   */
  async handleCoordinateSearch(lat, lon) {
    let resolvedName = `Coordinates (${lat.toFixed(4)}, ${lon.toFixed(4)})`;
    let city = '';
    let state = '';
    let country = '';
    let displayName = resolvedName;
    let category = 'viewpoints';

    try {
      const reverse = await this.reverseGeocode(lat, lon);
      if (reverse) {
        resolvedName = reverse.name || resolvedName;
        displayName = reverse.displayName || displayName;
        city = reverse.city || '';
        state = reverse.state || '';
        country = reverse.country || '';
        category = reverse.category || category;
      }
    } catch {
      // Keep synthesized coordinate details
    }

    return {
      id: `coord_${lat.toFixed(5)}_${lon.toFixed(5)}`,
      externalId: `${lat.toFixed(5)},${lon.toFixed(5)}`,
      provider: 'coordinate_lookup',
      name: resolvedName,
      displayName,
      city,
      state,
      country,
      latitude: lat,
      longitude: lon,
      category,
      type: 'coordinate',
      importance: 1.0,
      boundingBox: [lat - 0.05, lat + 0.05, lon - 0.05, lon + 0.05],
      isCoordinateInput: true,
      isCurated: false,
      source: 'provider'
    };
  }

  /**
   * Reverse geocodes coordinates into a location entity
   */
  async reverseGeocode(latitude, longitude) {
    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);
    if (isNaN(lat) || isNaN(lon)) {
      throw new Error('Valid latitude and longitude are required');
    }

    const cacheKey = `rev:${lat.toFixed(4)}:${lon.toFixed(4)}`;
    const cached = this._getCached(cacheKey);
    if (cached) return cached;

    try {
      const res = await this.primaryProvider.reverseGeocode(lat, lon);
      if (res) this._setCached(cacheKey, res);
      return res;
    } catch (err) {
      try {
        const fallbackRes = await this.fallbackProvider.reverseGeocode(lat, lon);
        if (fallbackRes) this._setCached(cacheKey, fallbackRes);
        return fallbackRes;
      } catch {
        throw err;
      }
    }
  }

  /**
   * Retrieves place details by ID
   */
  async getDetails(id) {
    if (!id) return null;
    try {
      return await this.primaryProvider.getLocationDetails(id);
    } catch {
      return null;
    }
  }

  getServiceStatus() {
    return {
      service: 'RoamReady Global Geocoding Engine',
      primaryProvider: this.primaryProvider.getProviderInformation(),
      fallbackProvider: this.fallbackProvider.getProviderInformation(),
      cacheSize: this.cache.size
    };
  }
}

export const locationService = new LocationService();
