/**
 * Abstract Base Class for Location / Geocoding Providers
 * Enables swapping or chaining geocoding providers (Nominatim, Photon, Geoapify, etc.)
 * without rewriting business logic or frontend clients.
 */
export class LocationProvider {
  constructor(name) {
    if (new.target === LocationProvider) {
      throw new TypeError('Cannot construct LocationProvider instances directly');
    }
    this.name = name;
  }

  /**
   * Searches worldwide locations matching query.
   * @param {string} query Search keyword, address, POI, or place name
   * @param {Object} options Additional query parameters (limit, category, countrycodes)
   * @returns {Promise<Array<NormalizedLocation>>}
   */
  async searchLocations(query, options = {}) {
    throw new Error('searchLocations() must be implemented by subclass');
  }

  /**
   * Retrieves place details by external provider ID.
   * @param {string} id External place identifier
   * @returns {Promise<NormalizedLocation|null>}
   */
  async getLocationDetails(id) {
    throw new Error('getLocationDetails() must be implemented by subclass');
  }

  /**
   * Reverse geocodes coordinates to a normalized location.
   * @param {number} latitude
   * @param {number} longitude
   * @returns {Promise<NormalizedLocation|null>}
   */
  async reverseGeocode(latitude, longitude) {
    throw new Error('reverseGeocode() must be implemented by subclass');
  }

  /**
   * Returns provider metadata, operational status, and rate-limit compliance notes.
   */
  getProviderInformation() {
    return {
      provider: this.name,
      isConfigured: true,
      requiresApiKey: false
    };
  }
}
