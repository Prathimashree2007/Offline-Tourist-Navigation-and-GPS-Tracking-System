import { LocationProvider } from './LocationProvider.js';

/**
 * Komoot Photon Geocoding Provider
 * Fast, typo-tolerant OpenStreetMap geocoder.
 * Provides high-speed suggestions and natural place matching without API keys.
 */
export class PhotonProvider extends LocationProvider {
  constructor(options = {}) {
    super('photon');
    this.baseUrl = options.baseUrl || 'https://photon.komoot.io';
    this.timeoutMs = options.timeoutMs || 6000;
  }

  _mapCategory(osmKey, osmValue) {
    const key = (osmKey || '').toLowerCase();
    const val = (osmValue || '').toLowerCase();

    if (val.includes('waterfall') || key === 'waterfall') return 'waterfalls';
    if (val.includes('beach') || key === 'beach') return 'beaches';
    if (val.includes('peak') || val.includes('mountain') || val.includes('cliff') || val.includes('ridge')) return 'hills';
    if (val.includes('viewpoint')) return 'viewpoints';
    if (val.includes('temple') || val.includes('church') || val.includes('place_of_worship') || key === 'heritage') return 'temples';
    if (val.includes('monument') || val.includes('castle') || val.includes('ruins') || val.includes('historic')) return 'historical';
    if (val.includes('lake') || val.includes('water') || val.includes('river')) return 'lakes';
    if (val.includes('forest') || val.includes('wood') || val.includes('nature_reserve') || val.includes('park')) return 'forests';
    if (val.includes('hospital') || val.includes('clinic')) return 'emergency';
    if (val.includes('hotel') || val.includes('hostel')) return 'hotel';
    if (val.includes('restaurant') || val.includes('cafe')) return 'restaurant';
    return 'other';
  }

  _normalizeFeature(feature) {
    const props = feature.properties || {};
    const geom = feature.geometry || {};
    const coords = geom.coordinates || [0, 0];
    const lon = coords[0];
    const lat = coords[1];

    const name = props.name || props.street || props.city || props.country || 'Location';
    const city = props.city || props.town || props.village || props.county || '';
    const state = props.state || '';
    const country = props.country || '';

    // Build human-friendly breadcrumb display name
    const parts = [name];
    if (city && city !== name) parts.push(city);
    if (state && state !== name && state !== city) parts.push(state);
    if (country && country !== name) parts.push(country);
    const displayName = parts.join(', ');

    return {
      id: `photon_${props.osm_type || 'N'}_${props.osm_id || Math.round(lat * 10000)}`,
      externalId: String(props.osm_id || ''),
      osmType: props.osm_type || 'N',
      provider: 'photon',
      name,
      displayName,
      city,
      state,
      country,
      latitude: lat,
      longitude: lon,
      category: this._mapCategory(props.osm_key, props.osm_value),
      type: props.osm_value || props.type || 'place',
      importance: 0,
      boundingBox: props.extent || null,
      isCurated: false,
      source: 'provider'
    };
  }

  async searchLocations(query, options = {}) {
    if (!query || typeof query !== 'string' || !query.trim()) {
      return [];
    }

    const limit = Math.min(Math.max(parseInt(options.limit, 10) || 10, 1), 25);
    const params = new URLSearchParams({
      q: query.trim(),
      limit: String(limit)
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const url = `${this.baseUrl}/api/?${params.toString()}`;
      const res = await fetch(url, {
        signal: controller.signal,
        headers: { 'Accept': 'application/json' }
      });
      clearTimeout(timeout);

      if (!res.ok) {
        throw new Error(`Photon query returned status ${res.status}`);
      }

      const data = await res.json();
      if (!data || !Array.isArray(data.features)) return [];

      return data.features.map(f => this._normalizeFeature(f));
    } catch (err) {
      clearTimeout(timeout);
      throw err;
    }
  }

  async getLocationDetails(id) {
    return null;
  }

  async reverseGeocode(latitude, longitude) {
    const params = new URLSearchParams({
      lat: String(latitude),
      lon: String(longitude)
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const url = `${this.baseUrl}/reverse?${params.toString()}`;
      const res = await fetch(url, {
        signal: controller.signal,
        headers: { 'Accept': 'application/json' }
      });
      clearTimeout(timeout);

      if (!res.ok) return null;
      const data = await res.json();
      if (!data || !Array.isArray(data.features) || data.features.length === 0) return null;

      return this._normalizeFeature(data.features[0]);
    } catch {
      clearTimeout(timeout);
      return null;
    }
  }

  getProviderInformation() {
    return {
      provider: 'photon',
      attribution: 'Photon by Komoot, powered by OpenStreetMap contributors',
      baseUrl: this.baseUrl,
      rateLimitPolicy: 'High throughput, typo-tolerant search suggestions',
      isConfigured: true,
      requiresApiKey: false
    };
  }
}
