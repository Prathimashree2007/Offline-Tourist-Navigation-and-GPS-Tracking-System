/**
 * Worldwide Route Planning Service
 * Computes routes between any two worldwide coordinates:
 * - Uses OSRM (Open Source Routing Machine) public routing demo API when online
 * - Provides fallback spherical great-circle waypoint geometry with Haversine distance
 * - Calculates distance, estimated duration, and waypoint polyline
 */

const EARTH_RADIUS_KM = 6371.0;

function toRad(deg) {
  return (deg * Math.PI) / 180.0;
}

function calculateHaversineDistance(lat1, lon1, lat2, lon2) {
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return EARTH_RADIUS_KM * c;
}

export class RouteService {
  constructor(options = {}) {
    this.osrmBaseUrl = options.osrmBaseUrl || 'https://router.project-osrm.org';
    this.timeoutMs = options.timeoutMs || 8000;
  }

  /**
   * Generates interpolated great-circle waypoints between start and end coordinates
   */
  _generateDirectPolyline(startLat, startLon, endLat, endLon, numSegments = 20) {
    const coords = [];
    for (let i = 0; i <= numSegments; i++) {
      const f = i / numSegments;
      const lat = startLat + (endLat - startLat) * f;
      const lon = startLon + (endLon - startLon) * f;
      coords.push([lat, lon]);
    }
    return coords;
  }

  /**
   * Plans a route between start and destination coordinates.
   * @param {Object} params
   * @param {number} params.startLat Starting Latitude
   * @param {number} params.startLon Starting Longitude
   * @param {number} params.endLat Destination Latitude
   * @param {number} params.endLon Destination Longitude
   * @param {string} params.startName Starting Place Name
   * @param {string} params.endName Destination Place Name
   */
  async planRoute({ startLat, startLon, endLat, endLon, startName = 'Start', endName = 'Destination' }) {
    const sLat = parseFloat(startLat);
    const sLon = parseFloat(startLon);
    const eLat = parseFloat(endLat);
    const eLon = parseFloat(endLon);

    if (isNaN(sLat) || isNaN(sLon) || isNaN(eLat) || isNaN(eLon)) {
      throw new Error('Valid start and destination coordinates are required.');
    }

    const directDistanceKm = calculateHaversineDistance(sLat, sLon, eLat, eLon);

    // Try OSRM route API (driving profile)
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      // OSRM expects coordinates in {lon},{lat} order
      const url = `${this.osrmBaseUrl}/route/v1/driving/${sLon},${sLat};${eLon},${eLat}?overview=full&geometries=geojson&steps=true`;
      const res = await fetch(url, {
        signal: controller.signal,
        headers: { 'Accept': 'application/json' }
      });
      clearTimeout(timeout);

      if (res.ok) {
        const data = await res.json();
        if (data.code === 'Ok' && Array.isArray(data.routes) && data.routes.length > 0) {
          const route = data.routes[0];
          // OSRM geojson coordinates are [lon, lat], convert to Leaflet's [lat, lon]
          const coordinates = route.geometry.coordinates.map(c => [c[1], c[0]]);
          const distanceKm = Number((route.distance / 1000).toFixed(2));
          const durationSeconds = Math.round(route.duration);
          const durationMinutes = Math.round(durationSeconds / 60);

          return {
            success: true,
            provider: 'osrm',
            start: { name: startName, latitude: sLat, longitude: sLon },
            destination: { name: endName, latitude: eLat, longitude: eLon },
            distanceKm,
            durationSeconds,
            durationMinutes,
            formattedDuration: durationMinutes > 60
              ? `${Math.floor(durationMinutes / 60)}h ${durationMinutes % 60}m`
              : `${durationMinutes} mins`,
            coordinates,
            routingMethod: 'Road-Network Routing (OSRM Driving Engine)',
            requiresInternet: true,
            offlineNavigationDisclaimer: 'Online road routing calculated via OSRM. Pre-cache regional map tiles for continuous offline trail navigation.'
          };
        }
      }
    } catch (err) {
      clearTimeout(timeout);
      console.warn(`[RouteService] OSRM routing request failed (${err.message}). Using direct navigation projection.`);
    }

    // Fallback: Haversine geodesic projection
    const estimatedTravelMinutes = Math.max(5, Math.round((directDistanceKm / 40) * 60)); // assume 40 km/h average rural trail speed
    const fallbackCoords = this._generateDirectPolyline(sLat, sLon, eLat, eLon, 25);

    return {
      success: true,
      provider: 'geodesic_fallback',
      start: { name: startName, latitude: sLat, longitude: sLon },
      destination: { name: endName, latitude: eLat, longitude: eLon },
      distanceKm: Number(directDistanceKm.toFixed(2)),
      durationSeconds: estimatedTravelMinutes * 60,
      durationMinutes: estimatedTravelMinutes,
      formattedDuration: estimatedTravelMinutes > 60
        ? `${Math.floor(estimatedTravelMinutes / 60)}h ${estimatedTravelMinutes % 60}m`
        : `${estimatedTravelMinutes} mins`,
      coordinates: fallbackCoords,
      routingMethod: 'Direct Geodesic Great-Circle Trail Vector (Offline/Direct Mode)',
      requiresInternet: false,
      offlineNavigationDisclaimer: 'Road routing service unreachable. Displaying direct geodesic trail vector with approximate terrain travel time.'
    };
  }
}

export const routeService = new RouteService();
