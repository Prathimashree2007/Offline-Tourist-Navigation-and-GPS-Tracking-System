import { locationService } from '../services/location/LocationService.js';
import { routeService } from '../services/routing/RouteService.js';

/**
 * Location Search Controller
 * Handles worldwide dynamic geocoding, coordinate detection, details, and routing.
 */

export async function searchLocations(req, res, next) {
  try {
    const { q, category, limit } = req.query;

    if (!q || !q.trim()) {
      return res.status(400).json({
        success: false,
        message: 'Search query parameter "q" is required.'
      });
    }

    const results = await locationService.search(q, {
      category: category || 'all',
      limit: parseInt(limit, 10) || 10
    });

    return res.json({
      success: true,
      query: q.trim(),
      count: results.length,
      locations: results
    });
  } catch (err) {
    next(err);
  }
}

export async function getLocationDetails(req, res, next) {
  try {
    const { id } = req.params;
    const details = await locationService.getDetails(id);

    if (!details) {
      return res.status(404).json({
        success: false,
        message: 'Location details not found for provided identifier.'
      });
    }

    return res.json({
      success: true,
      location: details
    });
  } catch (err) {
    next(err);
  }
}

export async function reverseGeocodeLocation(req, res, next) {
  try {
    const { lat, lon } = req.query;

    if (lat === undefined || lon === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Both "lat" and "lon" query parameters are required.'
      });
    }

    const latitude = parseFloat(lat);
    const longitude = parseFloat(lon);

    if (isNaN(latitude) || isNaN(longitude) || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      return res.status(400).json({
        success: false,
        message: 'Invalid latitude or longitude coordinates.'
      });
    }

    const location = await locationService.reverseGeocode(latitude, longitude);

    if (!location) {
      return res.status(404).json({
        success: false,
        message: 'No address found for these coordinates.'
      });
    }

    return res.json({
      success: true,
      location
    });
  } catch (err) {
    next(err);
  }
}

export async function planRoute(req, res, next) {
  try {
    const { startLat, startLon, endLat, endLon, startName, endName } = req.query;

    if (startLat === undefined || startLon === undefined || endLat === undefined || endLon === undefined) {
      return res.status(400).json({
        success: false,
        message: 'startLat, startLon, endLat, and endLon are required query parameters.'
      });
    }

    const route = await routeService.planRoute({
      startLat,
      startLon,
      endLat,
      endLon,
      startName,
      endName
    });

    return res.json(route);
  } catch (err) {
    next(err);
  }
}

export function getLocationProviderInfo(req, res) {
  res.json(locationService.getServiceStatus());
}
