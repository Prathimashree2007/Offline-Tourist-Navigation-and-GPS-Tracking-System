import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { config } from '../config/config.js';
import { getPool, isDbConnected, memoryStore } from '../config/db.js';

export async function register(req, res, next) {
  try {
    const { name, email, password, preferred_distance_unit = 'km' } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, and password are required fields.'
      });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    if (isDbConnected()) {
      const pool = getPool();
      const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
      if (existing.length > 0) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email already exists.'
        });
      }

      const [result] = await pool.query(
        'INSERT INTO users (name, email, password_hash, preferred_distance_unit) VALUES (?, ?, ?, ?)',
        [name, email, passwordHash, preferred_distance_unit]
      );

      const userId = result.insertId;
      const token = jwt.sign({ id: userId, email, name }, config.jwtSecret, {
        expiresIn: config.jwtExpiresIn
      });

      return res.status(201).json({
        success: true,
        message: 'User registered successfully.',
        token,
        user: { id: userId, name, email, preferred_distance_unit }
      });
    } else {
      // Memory store fallback
      const exists = memoryStore.users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (exists) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email already exists.'
        });
      }

      const newUser = {
        id: memoryStore.users.length + 1,
        name,
        email,
        password_hash: passwordHash,
        preferred_distance_unit,
        created_at: new Date()
      };
      memoryStore.users.push(newUser);

      const token = jwt.sign({ id: newUser.id, email, name }, config.jwtSecret, {
        expiresIn: config.jwtExpiresIn
      });

      return res.status(201).json({
        success: true,
        message: 'User registered successfully (Local Session).',
        token,
        user: { id: newUser.id, name, email, preferred_distance_unit }
      });
    }
  } catch (err) {
    next(err);
  }
}

export async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required.'
      });
    }

    let user = null;

    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
      if (rows.length > 0) {
        user = rows[0];
      }
    } else {
      user = memoryStore.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    }

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password credentials.'
      });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password credentials.'
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      config.jwtSecret,
      { expiresIn: config.jwtExpiresIn }
    );

    return res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        preferred_distance_unit: user.preferred_distance_unit || 'km'
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function getProfile(req, res, next) {
  try {
    const userId = req.user.id;
    let user = null;

    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query(
        'SELECT id, name, email, preferred_distance_unit, created_at FROM users WHERE id = ?',
        [userId]
      );
      if (rows.length > 0) user = rows[0];
    } else {
      user = memoryStore.users.find(u => u.id === userId);
    }

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    return res.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        preferred_distance_unit: user.preferred_distance_unit || 'km',
        created_at: user.created_at
      }
    });
  } catch (err) {
    next(err);
  }
}
