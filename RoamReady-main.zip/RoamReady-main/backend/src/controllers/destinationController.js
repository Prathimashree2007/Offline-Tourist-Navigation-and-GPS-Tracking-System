import { getPool, isDbConnected, memoryStore } from '../config/db.js';
import { isCoordinateDuplicate, calculateHaversineDistanceKm } from '../utils/geo.js';

// Curated seed destinations dataset for the API (Preserved exactly as sample catalog)
export const SEED_DESTINATIONS = [
  {
    id: 1,
    name: 'Madikeri (Coorg)',
    state: 'Karnataka',
    country: 'India',
    latitude: 12.4244,
    longitude: 75.7382,
    category: 'hills',
    description: 'Lush highland hill station known for misty coffee plantations, Raja Seat sunset point, and Abbey Falls.',
    best_time_to_visit: 'October - March',
    difficulty_level: 'easy',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 2,
    name: 'Abbey Falls (Coorg)',
    state: 'Karnataka',
    country: 'India',
    latitude: 12.4542,
    longitude: 75.7196,
    category: 'waterfalls',
    description: 'Dramatic waterfall nestled inside private coffee estates and spice groves, roaring during post-monsoon.',
    best_time_to_visit: 'September - January',
    difficulty_level: 'moderate',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 3,
    name: 'Chikmagalur (Mullayanagiri)',
    state: 'Karnataka',
    country: 'India',
    latitude: 13.3912,
    longitude: 75.7214,
    category: 'hills',
    description: 'Highest peak in Karnataka offering rugged hiking trails, Baba Budangiri caves, and panoramic ridge views.',
    best_time_to_visit: 'September - February',
    difficulty_level: 'challenging',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 4,
    name: 'Gokarna Beach Trail',
    state: 'Karnataka',
    country: 'India',
    latitude: 14.5436,
    longitude: 74.3188,
    category: 'beaches',
    description: 'Famous 5-beach cliffside trail connecting Kudle, Om, Half Moon, and Paradise beaches.',
    best_time_to_visit: 'November - April',
    difficulty_level: 'moderate',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 5,
    name: 'Ooty (Nilgiris)',
    state: 'Tamil Nadu',
    country: 'India',
    latitude: 11.4102,
    longitude: 76.6950,
    category: 'hills',
    description: 'Queen of Hill Stations featuring Doddabetta Peak, Pykara Lake and Falls, and botanical gardens.',
    best_time_to_visit: 'September - March',
    difficulty_level: 'easy',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 6,
    name: 'Wayanad (Chembra Peak)',
    state: 'Kerala',
    country: 'India',
    latitude: 11.5129,
    longitude: 76.0827,
    category: 'hills',
    description: 'Heart-shaped lake on misty mountain heights with ancient Edakkal caves and Soochipara Falls nearby.',
    best_time_to_visit: 'October - May',
    difficulty_level: 'challenging',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 7,
    name: 'Jog Falls (Shimoga)',
    state: 'Karnataka',
    country: 'India',
    latitude: 14.2285,
    longitude: 74.8124,
    category: 'waterfalls',
    description: 'Second steepest plunge waterfall in India created by the Sharavathi river cascading down 830 feet.',
    best_time_to_visit: 'August - December',
    difficulty_level: 'easy',
    source: 'curated',
    provider: 'curated'
  },
  {
    id: 8,
    name: 'Dudhsagar Falls',
    state: 'Goa',
    country: 'India',
    latitude: 15.3144,
    longitude: 74.3143,
    category: 'waterfalls',
    description: 'Four-tiered sea of milk waterfall on Mandovi River surrounded by Bhagwan Mahaveer Sanctuary.',
    best_time_to_visit: 'October - February',
    difficulty_level: 'challenging',
    source: 'curated',
    provider: 'curated'
  }
];

/**
 * Curated destinations search (Preserved for backwards compatibility)
 * Clearly returns curated catalogue destinations only.
 */
export async function searchDestinations(req, res, next) {
  try {
    const { query, category } = req.query;

    if (isDbConnected()) {
      const pool = getPool();
      let sql = 'SELECT * FROM destinations WHERE 1=1';
      const params = [];

      if (query) {
        sql += ' AND (name LIKE ? OR state LIKE ? OR description LIKE ?)';
        const term = `%${query}%`;
        params.push(term, term, term);
      }
      if (category && category !== 'all') {
        sql += ' AND category = ?';
        params.push(category);
      }

      sql += ' ORDER BY name ASC LIMIT 25';
      const [rows] = await pool.query(sql, params);
      return res.json({ success: true, count: rows.length, destinations: rows, isCuratedOnly: true });
    } else {
      let results = [...SEED_DESTINATIONS];
      if (query) {
        const q = query.toLowerCase();
        results = results.filter(
          d => d.name.toLowerCase().includes(q) || d.state.toLowerCase().includes(q) || d.description.toLowerCase().includes(q)
        );
      }
      if (category && category !== 'all') {
        results = results.filter(d => d.category === category);
      }
      return res.json({ success: true, count: results.length, destinations: results, isCuratedOnly: true });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Returns curated sample destinations explicitly
 */
export async function getCuratedDestinations(req, res, next) {
  try {
    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query("SELECT * FROM destinations WHERE source = 'curated' OR source IS NULL ORDER BY id ASC");
      if (rows.length > 0) {
        return res.json({ success: true, count: rows.length, destinations: rows });
      }
    }
    return res.json({ success: true, count: SEED_DESTINATIONS.length, destinations: SEED_DESTINATIONS });
  } catch (err) {
    next(err);
  }
}

/**
 * Get destination by ID (curated, dynamic, or user saved)
 */
export async function getDestinationById(req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: 'Invalid destination ID.' });
    }

    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query('SELECT * FROM destinations WHERE id = ?', [id]);
      if (rows.length === 0) {
        return res.status(404).json({ success: false, message: 'Destination not found.' });
      }
      return res.json({ success: true, destination: rows[0] });
    } else {
      const found = SEED_DESTINATIONS.find(d => d.id === id) || 
                    (memoryStore.saved_destinations || []).find(d => d.id === id);
      if (!found) {
        return res.status(404).json({ success: false, message: 'Destination not found.' });
      }
      return res.json({ success: true, destination: found });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Saves a dynamic or user-selected worldwide destination with duplicate detection.
 * Prevents duplicates via external place ID or coordinate proximity (within 100 meters).
 */
export async function saveDestination(req, res, next) {
  try {
    const {
      name,
      displayName,
      state,
      country,
      latitude,
      longitude,
      category = 'other',
      description = '',
      externalId = null,
      provider = 'nominatim',
      source = 'user_saved'
    } = req.body;

    if (!name || latitude === undefined || longitude === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Name, latitude, and longitude are required fields.'
      });
    }

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);

    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
      return res.status(400).json({
        success: false,
        message: 'Invalid latitude or longitude coordinates.'
      });
    }

    // 1. DUPLICATE CHECK
    if (isDbConnected()) {
      const pool = getPool();

      // Check by external ID if present
      if (externalId) {
        const [byExt] = await pool.query(
          'SELECT * FROM destinations WHERE provider = ? AND external_place_id = ? LIMIT 1',
          [provider, String(externalId)]
        );
        if (byExt.length > 0) {
          return res.status(200).json({
            success: true,
            message: 'Destination is already saved in your database.',
            isDuplicate: true,
            destination: byExt[0]
          });
        }
      }

      // Check by coordinate proximity (< 100m)
      const [nearbyRows] = await pool.query(
        'SELECT * FROM destinations WHERE ABS(latitude - ?) < 0.01 AND ABS(longitude - ?) < 0.01',
        [lat, lon]
      );

      for (const row of nearbyRows) {
        if (isCoordinateDuplicate(lat, lon, parseFloat(row.latitude), parseFloat(row.longitude), 0.1)) {
          return res.status(200).json({
            success: true,
            message: `Destination already exists as "${row.name}".`,
            isDuplicate: true,
            destination: row
          });
        }
      }

      // 2. INSERT NEW RECORD
      const [insertResult] = await pool.query(
        `INSERT INTO destinations 
         (name, state, country, latitude, longitude, category, description, external_place_id, provider, display_name, source)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          name.trim(),
          state || '',
          country || 'Worldwide',
          lat,
          lon,
          category,
          description || `${name} (${displayName || ''})`,
          externalId ? String(externalId) : null,
          provider,
          displayName || name,
          source
        ]
      );

      const savedDestination = {
        id: insertResult.insertId,
        name: name.trim(),
        state: state || '',
        country: country || 'Worldwide',
        latitude: lat,
        longitude: lon,
        category,
        description: description || `${name} (${displayName || ''})`,
        external_place_id: externalId ? String(externalId) : null,
        provider,
        display_name: displayName || name,
        source
      };

      return res.status(201).json({
        success: true,
        message: 'Worldwide destination saved successfully.',
        isDuplicate: false,
        destination: savedDestination
      });
    } else {
      // Memory Store Fallback
      if (!memoryStore.saved_destinations) {
        memoryStore.saved_destinations = [];
      }

      // Check memory duplicates
      const allDestinations = [...SEED_DESTINATIONS, ...memoryStore.saved_destinations];
      const duplicate = allDestinations.find(d => {
        if (externalId && d.external_place_id === String(externalId) && d.provider === provider) {
          return true;
        }
        return isCoordinateDuplicate(lat, lon, d.latitude, d.longitude, 0.1);
      });

      if (duplicate) {
        return res.status(200).json({
          success: true,
          message: `Destination already exists as "${duplicate.name}".`,
          isDuplicate: true,
          destination: duplicate
        });
      }

      const newDest = {
        id: (memoryStore.saved_destinations.length + 100),
        name: name.trim(),
        state: state || '',
        country: country || 'Worldwide',
        latitude: lat,
        longitude: lon,
        category,
        description: description || `${name} (${displayName || ''})`,
        external_place_id: externalId ? String(externalId) : null,
        provider,
        display_name: displayName || name,
        source,
        created_at: new Date()
      };

      memoryStore.saved_destinations.push(newDest);

      return res.status(201).json({
        success: true,
        message: 'Worldwide destination saved to local session.',
        isDuplicate: false,
        destination: newDest
      });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Retrieves all saved/discovered destinations
 */
export async function getSavedDestinations(req, res, next) {
  try {
    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query(
        "SELECT * FROM destinations WHERE source IN ('user_saved', 'dynamic') ORDER BY id DESC"
      );
      return res.json({ success: true, count: rows.length, destinations: rows });
    } else {
      const saved = memoryStore.saved_destinations || [];
      return res.json({ success: true, count: saved.length, destinations: saved });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Deletes a saved destination by ID
 */
export async function deleteSavedDestination(req, res, next) {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: 'Invalid destination ID.' });
    }

    if (isDbConnected()) {
      const pool = getPool();
      // Protect curated destinations from accidental deletion
      const [check] = await pool.query('SELECT source FROM destinations WHERE id = ?', [id]);
      if (check.length > 0 && check[0].source === 'curated') {
        return res.status(403).json({ success: false, message: 'Curated destinations cannot be deleted.' });
      }

      const [result] = await pool.query('DELETE FROM destinations WHERE id = ?', [id]);
      if (result.affectedRows === 0) {
        return res.status(404).json({ success: false, message: 'Destination not found.' });
      }
      return res.json({ success: true, message: 'Destination deleted successfully.' });
    } else {
      if (memoryStore.saved_destinations) {
        const idx = memoryStore.saved_destinations.findIndex(d => d.id === id);
        if (idx !== -1) {
          memoryStore.saved_destinations.splice(idx, 1);
          return res.json({ success: true, message: 'Destination deleted from session.' });
        }
      }
      return res.status(404).json({ success: false, message: 'Destination not found.' });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Favourites: Add to favourites
 */
export async function addFavourite(req, res, next) {
  try {
    const userId = req.user?.id || 1;
    const { destinationId, customPlaceName, placeCategory, latitude, longitude } = req.body;

    if (latitude === undefined || longitude === undefined) {
      return res.status(400).json({ success: false, message: 'Coordinates are required.' });
    }

    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);

    if (isDbConnected()) {
      const pool = getPool();
      const [existing] = await pool.query(
        'SELECT id FROM favourites WHERE user_id = ? AND ABS(latitude - ?) < 0.0001 AND ABS(longitude - ?) < 0.0001',
        [userId, lat, lon]
      );
      if (existing.length > 0) {
        return res.json({ success: true, message: 'Location is already in favourites.', isDuplicate: true });
      }

      const [result] = await pool.query(
        `INSERT INTO favourites (user_id, destination_id, custom_place_name, place_category, latitude, longitude)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [userId, destinationId || null, customPlaceName || 'Favourite Spot', placeCategory || 'other', lat, lon]
      );

      return res.status(201).json({
        success: true,
        message: 'Added to favourites.',
        favouriteId: result.insertId
      });
    } else {
      if (!memoryStore.favourites) memoryStore.favourites = [];
      const duplicate = memoryStore.favourites.find(f => f.user_id === userId && Math.abs(f.latitude - lat) < 0.0001 && Math.abs(f.longitude - lon) < 0.0001);
      if (duplicate) {
        return res.json({ success: true, message: 'Location is already in favourites.', isDuplicate: true });
      }

      const fav = {
        id: memoryStore.favourites.length + 1,
        user_id: userId,
        destination_id: destinationId || null,
        custom_place_name: customPlaceName || 'Favourite Spot',
        place_category: placeCategory || 'other',
        latitude: lat,
        longitude: lon,
        created_at: new Date()
      };
      memoryStore.favourites.push(fav);
      return res.status(201).json({ success: true, message: 'Added to session favourites.', favouriteId: fav.id });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Favourites: List user favourites
 */
export async function getFavourites(req, res, next) {
  try {
    const userId = req.user?.id || 1;
    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query(
        `SELECT f.*, d.name AS destination_name, d.state, d.country, d.category 
         FROM favourites f 
         LEFT JOIN destinations d ON f.destination_id = d.id 
         WHERE f.user_id = ? ORDER BY f.created_at DESC`,
        [userId]
      );
      return res.json({ success: true, count: rows.length, favourites: rows });
    } else {
      const userFavs = (memoryStore.favourites || []).filter(f => f.user_id === userId);
      return res.json({ success: true, count: userFavs.length, favourites: userFavs });
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Favourites: Remove favourite
 */
export async function removeFavourite(req, res, next) {
  try {
    const userId = req.user?.id || 1;
    const favId = parseInt(req.params.id, 10);

    if (isDbConnected()) {
      const pool = getPool();
      await pool.query('DELETE FROM favourites WHERE id = ? AND user_id = ?', [favId, userId]);
      return res.json({ success: true, message: 'Favourite removed successfully.' });
    } else {
      if (memoryStore.favourites) {
        const idx = memoryStore.favourites.findIndex(f => f.id === favId && f.user_id === userId);
        if (idx !== -1) memoryStore.favourites.splice(idx, 1);
      }
      return res.json({ success: true, message: 'Favourite removed from session.' });
    }
  } catch (err) {
    next(err);
  }
}
