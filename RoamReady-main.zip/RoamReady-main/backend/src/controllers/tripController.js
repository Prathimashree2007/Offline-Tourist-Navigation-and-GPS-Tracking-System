import { getPool, isDbConnected, memoryStore } from '../config/db.js';

export async function syncTrip(req, res, next) {
  try {
    const userId = req.user.id;
    const {
      trip_name,
      destination_name,
      start_lat,
      start_lon,
      end_lat,
      end_lon,
      total_distance_km,
      total_duration_seconds,
      average_speed_kmh,
      started_at,
      ended_at,
      points = []
    } = req.body;

    if (!trip_name || start_lat === undefined || start_lon === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Trip name and starting coordinates are required.'
      });
    }

    if (isDbConnected()) {
      const pool = getPool();
      const connection = await pool.getConnection();
      try {
        await connection.beginTransaction();

        const [result] = await connection.query(
          `INSERT INTO travel_history 
           (user_id, trip_name, start_lat, start_lon, end_lat, end_lon, start_location_name, total_distance_km, total_duration_seconds, average_speed_kmh, point_count, started_at, ended_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            userId,
            trip_name,
            start_lat,
            start_lon,
            end_lat || start_lat,
            end_lon || start_lon,
            destination_name || 'Scenic Route',
            total_distance_km || 0,
            total_duration_seconds || 0,
            average_speed_kmh || 0,
            points.length,
            started_at || new Date(),
            ended_at || new Date()
          ]
        );

        const tripId = result.insertId;

        // Insert points if available
        if (points.length > 0) {
          const pointValues = points.map((p, idx) => [
            tripId,
            p.latitude,
            p.longitude,
            p.altitude || null,
            p.accuracy || 10,
            p.speed || null,
            p.timestamp || new Date(),
            idx
          ]);

          await connection.query(
            `INSERT INTO trip_points (trip_id, latitude, longitude, altitude, accuracy_meters, speed_mps, recorded_at, point_order)
             VALUES ?`,
            [pointValues]
          );
        }

        await connection.commit();
        return res.status(201).json({
          success: true,
          message: 'Trip synchronized successfully.',
          tripId
        });
      } catch (err) {
        await connection.rollback();
        throw err;
      } finally {
        connection.release();
      }
    } else {
      // Memory fallback
      const newTrip = {
        id: memoryStore.travel_history.length + 1,
        user_id: userId,
        trip_name,
        destination_name,
        start_lat,
        start_lon,
        end_lat: end_lat || start_lat,
        end_lon: end_lon || start_lon,
        total_distance_km,
        total_duration_seconds,
        average_speed_kmh,
        started_at,
        ended_at,
        point_count: points.length,
        points
      };
      memoryStore.travel_history.push(newTrip);

      return res.status(201).json({
        success: true,
        message: 'Trip saved to session history.',
        tripId: newTrip.id
      });
    }
  } catch (err) {
    next(err);
  }
}

export async function getUserTrips(req, res, next) {
  try {
    const userId = req.user.id;
    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query(
        'SELECT * FROM travel_history WHERE user_id = ? ORDER BY started_at DESC',
        [userId]
      );
      return res.json({ success: true, count: rows.length, trips: rows });
    } else {
      const userTrips = memoryStore.travel_history.filter(t => t.user_id === userId);
      return res.json({ success: true, count: userTrips.length, trips: userTrips });
    }
  } catch (err) {
    next(err);
  }
}

export async function deleteTrip(req, res, next) {
  try {
    const userId = req.user.id;
    const tripId = parseInt(req.params.id, 10);

    if (isDbConnected()) {
      const pool = getPool();
      await pool.query('DELETE FROM travel_history WHERE id = ? AND user_id = ?', [tripId, userId]);
      return res.json({ success: true, message: 'Trip deleted successfully.' });
    } else {
      const idx = memoryStore.travel_history.findIndex(t => t.id === tripId && t.user_id === userId);
      if (idx !== -1) {
        memoryStore.travel_history.splice(idx, 1);
      }
      return res.json({ success: true, message: 'Trip deleted from session.' });
    }
  } catch (err) {
    next(err);
  }
}
