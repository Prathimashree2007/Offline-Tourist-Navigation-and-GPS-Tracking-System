import { getPool, isDbConnected, memoryStore } from '../config/db.js';

export async function syncDownloadedMap(req, res, next) {
  try {
    const userId = req.user.id;
    const {
      region_name,
      destination_id,
      center_lat,
      center_lon,
      radius_km,
      tile_count,
      storage_bytes,
      min_zoom,
      max_zoom,
      poi_count
    } = req.body;

    if (!region_name || center_lat === undefined || center_lon === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Region name and coordinates are required.'
      });
    }

    if (isDbConnected()) {
      const pool = getPool();
      const [result] = await pool.query(
        `INSERT INTO downloaded_maps 
         (user_id, region_name, destination_id, center_lat, center_lon, radius_km, tile_count, storage_bytes, min_zoom, max_zoom, poi_count)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          userId,
          region_name,
          destination_id || null,
          center_lat,
          center_lon,
          radius_km || 10,
          tile_count || 0,
          storage_bytes || 0,
          min_zoom || 11,
          max_zoom || 15,
          poi_count || 0
        ]
      );

      return res.status(201).json({
        success: true,
        message: 'Downloaded map metadata saved to cloud.',
        mapId: result.insertId
      });
    } else {
      const newMap = {
        id: memoryStore.downloaded_maps.length + 1,
        user_id: userId,
        region_name,
        center_lat,
        center_lon,
        radius_km,
        tile_count,
        storage_bytes,
        poi_count,
        downloaded_at: new Date()
      };
      memoryStore.downloaded_maps.push(newMap);

      return res.status(201).json({
        success: true,
        message: 'Downloaded map metadata saved to session.',
        mapId: newMap.id
      });
    }
  } catch (err) {
    next(err);
  }
}

export async function getUserDownloadedMaps(req, res, next) {
  try {
    const userId = req.user.id;
    if (isDbConnected()) {
      const pool = getPool();
      const [rows] = await pool.query(
        'SELECT * FROM downloaded_maps WHERE user_id = ? ORDER BY downloaded_at DESC',
        [userId]
      );
      return res.json({ success: true, count: rows.length, maps: rows });
    } else {
      const userMaps = memoryStore.downloaded_maps.filter(m => m.user_id === userId);
      return res.json({ success: true, count: userMaps.length, maps: userMaps });
    }
  } catch (err) {
    next(err);
  }
}
