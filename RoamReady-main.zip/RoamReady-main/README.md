
# RoamReady — Offline Tourist Navigation & GPS Trail Companion

> **"Explore freely. Navigate anywhere."**  
> An engineering mini-project developed by a 4-member team from the **Department of Information Science & Engineering**.

---

## 🌲 Overview
Tourists frequently visit remote waterfalls, dense hills, forests, rural heritage villages, and secluded beaches where mobile internet coverage is unreliable or completely absent. 

**RoamReady** solves this problem through an **offline-first hybrid architecture**:
1. **Pre-trip Planning (Online)**: Tourists search destinations and download a bounded map tile pyramid (5 km, 10 km, 25 km, or 50 km) along with curated Points of Interest (POIs) and emergency clinic contacts directly into persistent browser storage (`IndexedDB`).
2. **Wilderness Navigation (Offline)**: Works 100% disconnected. Leaflet loads cached tiles from IndexedDB via a custom `OfflineTileLayer`. The native Geolocation API tracks high-accuracy GPS coordinates without cellular data. Nearby spots are queried locally and sorted using the **Haversine formula**.
3. **GPS Trail Recorder**: Continuous waypoint logging with noise filtering, pause/resume, live polyline rendering, and trip statistics (distance, duration, average speed).
4. **Local & Cloud Persistence**: Trips and maps are stored locally in IndexedDB and can be synced with a **Node.js/Express REST API** and **MySQL** database when connectivity returns.

---

## 🛠️ Technology Stack
- **Frontend**: React 18, Vite, Tailwind CSS, Lucide React icons, Framer Motion
- **Maps**: Leaflet with custom IndexedDB Offline Tile Layer & Slippy Map tile pyramids
- **GPS**: Native Browser Geolocation API (`watchPosition`, high accuracy)
- **Offline Storage**: IndexedDB (via `idb`), Service Worker (`CacheStorage`), PWA Web App Manifest
- **Backend**: Node.js, Express.js REST API, JWT Authentication, Bcrypt password hashing
- **Database**: MySQL 8.0 (with automatic resilient in-memory fallback for offline demonstrations)

---

## 🚀 Quick Start

### 1. Start Backend Server
```bash
cd backend
npm install
npm start
```
*Health Check*: `http://localhost:5000/api/health`

### 2. Start Frontend Application
```bash
cd frontend
npm install
npm run dev
```
*Frontend URL*: `http://localhost:5173`

---

## 📂 Project Directory Structure
```
roamready/
├── backend/
│   ├── src/
│   │   ├── config/          # DB connection & environment
│   │   ├── controllers/     # Auth, Destination, Trip, Map controllers
│   │   ├── middleware/      # JWT auth & error handlers
│   │   ├── routes/          # Express REST API routes
│   │   └── server.js        # Express application bootstrap
│   ├── test/                # Backend unit tests
│   ├── package.json
│   └── .env
├── frontend/
│   ├── public/              # Manifest, Service Worker, SVG icons
│   ├── src/
│   │   ├── components/      # Navbar, BottomNav, OfflineBanner, Modals
│   │   ├── context/         # AuthContext, ThemeContext
│   │   ├── data/            # Curated Destinations & POIs
│   │   ├── pages/           # All 17 complete interactive pages
│   │   ├── utils/           # Geo math, IndexedDB storage, GPS tracker
│   │   ├── App.jsx          # Route configuration
│   │   ├── main.jsx
│   │   └── index.css        # Tailwind styling & Leaflet controls
│   ├── package.json
│   ├── vite.config.js
│   └── tailwind.config.js
└── docs/
    ├── ARCHITECTURE.md      # Detailed system architecture
    ├── DATABASE_SCHEMA.sql  # MySQL table definitions
    ├── SEED_DATA.sql        # Curated destinations seed data
    ├── API_DOCUMENTATION.md # REST endpoints reference
    └── INSTALLATION_GUIDE.md# Setup and viva evaluation guide
```

---

## 🎓 Academic Viva Highlights
- **Haversine Distance**: Straight-line great-circle calculation without remote API calls.
- **Tile Bounding Mathematics**: Projections between WGS84 (Lat/Lon) and Web Mercator (EPSG:3857) Slippy Map tiles $(X, Y, Z)$.
- **Legal Compliance**: Downloads bounded regions only with discrete radii; no illegal bulk scraping.
- **True Offline Rendering**: Real tiles loaded from IndexedDB blobs; clear boundary warning if user pans outside cached area.
- **Classroom Demo Mode**: Built-in GPS simulator for indoor seminar hall evaluation.

