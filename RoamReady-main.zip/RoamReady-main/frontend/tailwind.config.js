/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        forest: {
          50: '#f0fdf4',
          100: '#dcfce7',
          200: '#bbf7d0',
          300: '#86efac',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
          800: '#166534',
          900: '#14532d',
          950: '#0d3b1e',
        },
        roam: {
          green: '#1E3A2F',       // Primary deep forest green
          lightgreen: '#2A5243',  // Hover / Accent green
          teal: '#0E5C58',        // Secondary deep teal
          mint: '#52B788',        // Fresh trail accent
          sand: '#F7F5EE',        // Warm background sand
          card: '#FFFFFF',        // Card background
          stone: '#E8E3D7',       // Sand border / divider
          terracotta: '#D96B43',  // Warning / Danger / POI highlight
          amber: '#EAB308',       // Caution / Star / Warning
          night: '#101B17',       // Dark mode deep background
          nightcard: '#182822',   // Dark mode card
          nightborder: '#273C34'  // Dark mode border
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(16, 27, 23, 0.08)',
        'float': '0 10px 30px -5px rgba(16, 27, 23, 0.15)',
        'glow': '0 0 25px -5px rgba(82, 183, 136, 0.4)',
      }
    },
  },
  plugins: [],
}
