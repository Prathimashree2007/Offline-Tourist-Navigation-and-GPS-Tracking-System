import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { X, MapPin, DownloadCloud, Navigation } from 'lucide-react';

export default function MapPreviewModal({ isOpen, onClose, destination, onPlanDownload, onPlanRoute }) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);

  useEffect(() => {
    if (!isOpen || !destination || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [destination.latitude, destination.longitude],
        zoom: 13
      });

      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    map.setView([destination.latitude, destination.longitude], 13);

    // Marker
    const markerIcon = L.divIcon({
      className: 'preview-pin',
      html: `
        <div style="background-color: #1E3A2F; color: white; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.3); border: 2.5px solid white;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        </div>
      `,
      iconSize: [34, 34],
      iconAnchor: [17, 34]
    });

    const marker = L.marker([destination.latitude, destination.longitude], { icon: markerIcon })
      .bindPopup(`<strong>${destination.name}</strong><br/>${destination.displayName || ''}`)
      .addTo(map);

    // 10 km download radius preview circle
    const circle = L.circle([destination.latitude, destination.longitude], {
      radius: 10000,
      color: '#16a34a',
      fillColor: '#22c55e',
      fillOpacity: 0.15,
      weight: 2,
      dashArray: '6, 6'
    }).addTo(map);

    map.fitBounds(circle.getBounds(), { padding: [20, 20] });

    return () => {
      // Clean up layer on destination change
      if (map) {
        map.removeLayer(marker);
        map.removeLayer(circle);
      }
    };
  }, [isOpen, destination]);

  if (!isOpen || !destination) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl max-w-2xl w-full overflow-hidden shadow-float border border-roam-stone/80 dark:border-roam-nightborder flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint">
                {destination.category || 'destination'}
              </span>
              <span className="text-xs text-slate-400">
                {destination.latitude.toFixed(4)}, {destination.longitude.toFixed(4)}
              </span>
            </div>
            <h3 className="font-extrabold text-lg text-slate-900 dark:text-white mt-0.5">
              {destination.name}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
              {destination.displayName}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Map Container */}
        <div ref={mapContainerRef} className="h-80 w-full" />

        {/* Footer Actions */}
        <div className="p-4 bg-roam-sand/40 dark:bg-roam-night border-t border-roam-stone/60 dark:border-roam-nightborder flex flex-wrap items-center justify-between gap-3">
          <span className="text-xs text-slate-500">
            Dashed green ring shows sample 10 km offline caching footprint.
          </span>
          <div className="flex items-center gap-2">
            {onPlanRoute && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onPlanRoute(destination);
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-roam-stone dark:border-roam-nightborder text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-roam-nightcard"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Plan Route</span>
              </button>
            )}

            {onPlanDownload && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onPlanDownload(destination);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90"
              >
                <DownloadCloud className="w-3.5 h-3.5" />
                <span>Plan Download</span>
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
