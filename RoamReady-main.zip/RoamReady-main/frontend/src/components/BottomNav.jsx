import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Compass, Map, Navigation, MapPin, HardDrive } from 'lucide-react';

export default function BottomNav() {
  const location = useLocation();
  const isActive = (path) => location.pathname === path;

  const tabs = [
    { to: '/dashboard', label: 'Explore', icon: Compass },
    { to: '/map', label: 'Offline Map', icon: Map },
    { to: '/nearby', label: 'Nearby', icon: MapPin },
    { to: '/tracking', label: 'Tracker', icon: Navigation },
    { to: '/downloads', label: 'My Maps', icon: HardDrive },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-roam-night/95 backdrop-blur-md border-t border-roam-stone/60 dark:border-roam-nightborder px-2 py-1 shadow-float">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = isActive(tab.to);
          return (
            <Link
              key={tab.to}
              to={tab.to}
              className={`flex flex-col items-center justify-center py-1.5 px-3 rounded-xl transition-all ${
                active
                  ? 'text-roam-green dark:text-roam-mint font-bold scale-105'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <div className={`p-1 rounded-lg ${active ? 'bg-roam-green/10 dark:bg-roam-mint/15' : ''}`}>
                <Icon className="w-5 h-5" />
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
