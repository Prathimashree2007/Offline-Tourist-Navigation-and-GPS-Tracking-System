import React, { useMemo, useState } from 'react';
import { X, MapPin, Navigation, Phone, Copy, AlertTriangle, MessageSquare, Trash2 } from 'lucide-react';
import { calculateHaversineDistance, formatDistance } from '../utils/geo';
import { bearingDegrees, compassPoint } from '../utils/routing';

// India emergency numbers (tap to call; calling works with any signal, even without data)
const EMERGENCY_NUMBERS = [
  { label: 'All emergencies', number: '112' },
  { label: 'Ambulance', number: '108' },
  { label: 'Police', number: '100' },
  { label: 'Fire', number: '101' },
  { label: 'Tourist helpline', number: '1363' }
];

/**
 * Bottom sheet for the Offline Map with two tabs:
 *  - "Nearby": closest places sorted by distance, with direction and a route button
 *  - "SOS": current coordinates, share by SMS, emergency numbers, nearest emergency places
 * Everything runs from data already stored on the device.
 */
const PIN_TYPES = ['hotel', 'parking', 'viewpoint', 'food', 'other'];

export default function MapAssistPanel({ tab, onTabChange, onClose, pois, currentGps, regionCenter, distanceUnit, onRoute, pins = [], onSavePin, onDeletePin }) {
  const [category, setCategory] = useState('all');
  const [pinName, setPinName] = useState('');
  const [pinType, setPinType] = useState('hotel');
  const [copied, setCopied] = useState(false);

  const origin = currentGps || regionCenter;
  const usingGps = !!currentGps;

  const places = useMemo(() => {
    return pois
      .map((p) => {
        const km = calculateHaversineDistance(origin[0], origin[1], p.latitude, p.longitude, 'km');
        const bearing = bearingDegrees(origin[0], origin[1], p.latitude, p.longitude);
        return { ...p, km, compass: compassPoint(bearing) };
      })
      .sort((a, b) => a.km - b.km);
  }, [pois, origin[0], origin[1]]);

  const categories = useMemo(() => ['all', ...new Set(pois.map((p) => p.category).filter(Boolean))], [pois]);
  const nearby = places.filter((p) => category === 'all' || p.category === category).slice(0, 8);
  const emergencyPlaces = places.filter((p) => p.category === 'emergency').slice(0, 4);

  const coordText = `${origin[0].toFixed(5)}, ${origin[1].toFixed(5)}`;
  const smsBody = encodeURIComponent(
    `I need help. My location: ${coordText} https://maps.google.com/?q=${origin[0].toFixed(5)},${origin[1].toFixed(5)}`
  );

  const copyCoords = async () => {
    try {
      await navigator.clipboard.writeText(coordText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      window.prompt('Copy your coordinates:', coordText);
    }
  };

  const tabBtn = (id, label) => (
    <button
      onClick={() => onTabChange(id)}
      className={`flex-1 py-2 rounded-xl text-xs font-bold transition-colors ${
        tab === id ? 'bg-roam-green text-white' : 'bg-roam-stone/40 dark:bg-roam-nightborder text-slate-600 dark:text-slate-300'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="absolute bottom-20 left-3 right-3 sm:left-6 sm:right-auto sm:w-96 z-40 max-h-[60vh] overflow-y-auto bg-white dark:bg-roam-nightcard rounded-2xl border border-roam-stone dark:border-roam-nightborder shadow-float p-4">
      <div className="flex items-center gap-2 mb-3">
        {tabBtn('nearby', 'Nearby')}
        {tabBtn('pins', 'My pins')}
        {tabBtn('sos', 'SOS')}
        <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600" aria-label="Close">
          <X className="w-4 h-4" />
        </button>
      </div>

      {tab === 'nearby' && (
        <>
          <p className="text-[11px] text-slate-500 mb-2">
            {usingGps ? 'Distances from your GPS position.' : 'GPS not available yet, showing distances from the destination.'}
          </p>
          <div className="flex gap-1.5 overflow-x-auto pb-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1 rounded-full text-[11px] font-bold capitalize whitespace-nowrap ${
                  category === c ? 'bg-roam-green text-white' : 'bg-roam-stone/40 dark:bg-roam-nightborder text-slate-600 dark:text-slate-300'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="space-y-2">
            {nearby.length === 0 && <p className="text-xs text-slate-500">No places in this category.</p>}
            {nearby.map((p) => (
              <div key={p.id || p.name} className="flex items-center gap-3 p-2.5 rounded-xl border border-roam-stone/60 dark:border-roam-nightborder">
                <MapPin className="w-4 h-4 text-roam-green flex-shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{p.name}</p>
                  <p className="text-[11px] text-slate-500 capitalize">
                    {p.category} • {formatDistance(p.km, distanceUnit)} • {p.compass}
                  </p>
                </div>
                <button
                  onClick={() => onRoute(p.name, p.latitude, p.longitude)}
                  className="px-3 py-1.5 rounded-lg bg-roam-green text-white text-[11px] font-bold flex items-center gap-1"
                >
                  <Navigation className="w-3 h-3" /> Route
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === 'pins' && (
        <>
          <p className="text-[11px] text-slate-500 mb-2">
            Save your hotel, parking spot or a viewpoint at {usingGps ? 'your GPS position' : 'the destination (no GPS fix yet)'}. Pins stay on this device and work offline.
          </p>
          <input
            value={pinName}
            onChange={(e) => setPinName(e.target.value)}
            placeholder="Pin name, e.g. My hotel"
            maxLength={40}
            className="w-full px-3 py-2 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-transparent text-sm text-slate-900 dark:text-white"
          />
          <div className="flex gap-1.5 overflow-x-auto py-2">
            {PIN_TYPES.map((t) => (
              <button
                key={t}
                onClick={() => setPinType(t)}
                className={`px-3 py-1 rounded-full text-[11px] font-bold capitalize whitespace-nowrap ${
                  pinType === t ? 'bg-roam-green text-white' : 'bg-roam-stone/40 dark:bg-roam-nightborder text-slate-600 dark:text-slate-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <button
            disabled={!pinName.trim()}
            onClick={() => {
              onSavePin({ name: pinName, type: pinType, latitude: origin[0], longitude: origin[1] });
              setPinName('');
            }}
            className="w-full py-2 rounded-xl bg-roam-green text-white text-xs font-bold disabled:opacity-50"
          >
            Save pin here
          </button>

          <div className="mt-3 space-y-2">
            {pins.length === 0 && <p className="text-xs text-slate-500">No pins yet.</p>}
            {pins.map((p) => (
              <div key={p.id} className="flex items-center gap-3 p-2.5 rounded-xl border border-roam-stone/60 dark:border-roam-nightborder">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{p.name}</p>
                  <p className="text-[11px] text-slate-500 capitalize">
                    {p.type} • {formatDistance(calculateHaversineDistance(origin[0], origin[1], p.latitude, p.longitude, 'km'), distanceUnit)}
                  </p>
                </div>
                <button onClick={() => onRoute(p.name, p.latitude, p.longitude)} className="px-3 py-1.5 rounded-lg bg-roam-green text-white text-[11px] font-bold flex items-center gap-1">
                  <Navigation className="w-3 h-3" /> Route
                </button>
                <button onClick={() => onDeletePin(p.id)} className="p-1.5 text-slate-400 hover:text-red-600" aria-label="Delete pin">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === 'sos' && (
        <>
          <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900">
            <p className="text-[11px] font-bold uppercase tracking-wider text-red-600 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" /> {usingGps ? 'Your location' : 'Last known area (no GPS fix)'}
            </p>
            <p className="mt-1 font-mono text-sm font-bold text-slate-900 dark:text-white">{coordText}</p>
            <div className="mt-2 flex gap-2">
              <button onClick={copyCoords} className="flex-1 py-2 rounded-lg bg-white dark:bg-roam-nightborder text-xs font-bold flex items-center justify-center gap-1.5 border border-red-200 dark:border-red-900">
                <Copy className="w-3.5 h-3.5" /> {copied ? 'Copied' : 'Copy'}
              </button>
              <a href={`sms:?&body=${smsBody}`} className="flex-1 py-2 rounded-lg bg-red-600 text-white text-xs font-bold flex items-center justify-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" /> Send by SMS
              </a>
            </div>
            <p className="mt-2 text-[10px] text-slate-500">SMS and calls often work where mobile data does not.</p>
          </div>

          <p className="mt-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">Call (India)</p>
          <div className="grid grid-cols-2 gap-2">
            {EMERGENCY_NUMBERS.map((e) => (
              <a key={e.number} href={`tel:${e.number}`} className="p-2.5 rounded-xl border border-roam-stone/60 dark:border-roam-nightborder flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-600" />
                <span className="text-xs">
                  <strong className="block text-sm text-slate-900 dark:text-white">{e.number}</strong>
                  <span className="text-slate-500">{e.label}</span>
                </span>
              </a>
            ))}
          </div>

          {emergencyPlaces.length > 0 && (
            <>
              <p className="mt-3 mb-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400">Nearest emergency places</p>
              <div className="space-y-2">
                {emergencyPlaces.map((p) => (
                  <div key={p.id || p.name} className="flex items-center gap-3 p-2.5 rounded-xl border border-roam-stone/60 dark:border-roam-nightborder">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{p.name}</p>
                      <p className="text-[11px] text-slate-500">{formatDistance(p.km, distanceUnit)} • {p.compass}</p>
                    </div>
                    <button onClick={() => onRoute(p.name, p.latitude, p.longitude)} className="px-3 py-1.5 rounded-lg bg-roam-green text-white text-[11px] font-bold flex items-center gap-1">
                      <Navigation className="w-3 h-3" /> Route
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
