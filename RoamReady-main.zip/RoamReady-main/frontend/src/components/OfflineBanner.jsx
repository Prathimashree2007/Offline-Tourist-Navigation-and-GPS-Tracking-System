import React, { useState, useEffect } from 'react';
import { WifiOff, AlertTriangle, X, Database } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getStorageStats } from '../utils/storage';

export default function OfflineBanner() {
  const { isOnline } = useAuth();
  const [dismissed, setDismissed] = useState(false);
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (!isOnline) {
      setDismissed(false);
      getStorageStats().then(setStats).catch(() => {});
    }
  }, [isOnline]);

  if (isOnline || dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-amber-600 to-amber-700 text-white px-4 py-2.5 shadow-md transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between text-xs sm:text-sm">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="p-1 bg-white/20 rounded-lg">
            <WifiOff className="w-4 h-4 animate-bounce" />
          </div>
          <div>
            <span className="font-bold">Offline Mode Active.</span>{' '}
            <span className="opacity-90">
              No internet detected. All previously downloaded regions, POIs, and GPS recording remain 100% functional.
            </span>
            {stats && stats.mapCount > 0 && (
              <span className="hidden md:inline-block ml-2 px-2 py-0.5 bg-black/20 rounded-md font-medium text-xs">
                <Database className="w-3 h-3 inline mr-1" />
                {stats.mapCount} offline region{stats.mapCount > 1 ? 's' : ''} available ({stats.totalTileMB} MB cached)
              </span>
            )}
          </div>
        </div>

        <button
          onClick={() => setDismissed(true)}
          className="p-1 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          aria-label="Dismiss banner"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
