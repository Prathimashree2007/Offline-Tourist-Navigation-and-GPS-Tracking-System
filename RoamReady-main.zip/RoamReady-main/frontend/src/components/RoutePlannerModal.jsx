import React, { useState, useEffect, useRef } from 'react';
import L from 'leaflet';
import { 
  X, 
  Navigation, 
  MapPin, 
  Compass, 
  Clock, 
  ArrowRight, 
  RotateCcw, 
  AlertCircle, 
  CheckCircle2, 
  Layers, 
  Wifi, 
  WifiOff 
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { formatDistance } from '../utils/geo';
import { saveRoute } from '../utils/storage';

export default function RoutePlannerModal({ isOpen, onClose, initialDestination, currentGps }) {
  const { distanceUnit } = useTheme();

  const [startQuery, setStartQuery] = useState('Current GPS Location');
  const [startCoords, setStartCoords] = useState(currentGps || [12.4244, 75.7382]);
  const [destQuery, setDestQuery] = useState(initialDestination?.name || '');
  const [destCoords, setDestCoords] = useState(
    initialDestination ? [initialDestination.latitude, initialDestination.longitude] : null
  );

  const [startSuggestions, setStartSuggestions] = useState([]);
  const [destSuggestions, setDestSuggestions] = useState([]);
  const [loadingStart, setLoadingStart] = useState(false);
  const [loadingDest, setLoadingDest] = useState(false);

  const [routeResult, setRouteResult] = useState(null);
  const [loadingRoute, setLoadingRoute] = useState(false);
  const [routeError, setRouteError] = useState(null);

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const polylineLayerRef = useRef(null);
  const markersGroupRef = useRef(null);

  // Sync initial destination when opened
  useEffect(() => {
    if (initialDestination) {
      setDestQuery(initialDestination.displayName || initialDestination.name);
      setDestCoords([initialDestination.latitude, initialDestination.longitude]);
    }
  }, [initialDestination]);

  useEffect(() => {
    if (currentGps) {
      setStartCoords(currentGps);
    }
  }, [currentGps]);

  // Handle autocomplete search for starting location
  const handleSearchStart = async (val) => {
    setStartQuery(val);
    if (!val || val.length < 2 || val === 'Current GPS Location') {
      setStartSuggestions([]);
      return;
    }
    setLoadingStart(true);
    try {
      const res = await fetch(`http://localhost:5000/api/locations/search?q=${encodeURIComponent(val)}&limit=5`);
      const data = await res.json();
      if (data.success) {
        setStartSuggestions(data.locations || []);
      }
    } catch {
      setStartSuggestions([]);
    } finally {
      setLoadingStart(false);
    }
  };

  // Handle autocomplete search for destination
  const handleSearchDest = async (val) => {
    setDestQuery(val);
    if (!val || val.length < 2) {
      setDestSuggestions([]);
      return;
    }
    setLoadingDest(true);
    try {
      const res = await fetch(`http://localhost:5000/api/locations/search?q=${encodeURIComponent(val)}&limit=5`);
      const data = await res.json();
      if (data.success) {
        setDestSuggestions(data.locations || []);
      }
    } catch {
      setDestSuggestions([]);
    } finally {
      setLoadingDest(false);
    }
  };

  const handleCalculateRoute = async () => {
    if (!startCoords || !destCoords) {
      setRouteError('Please select both a valid starting point and a destination.');
      return;
    }

    setLoadingRoute(true);
    setRouteError(null);

    try {
      const params = new URLSearchParams({
        startLat: String(startCoords[0]),
        startLon: String(startCoords[1]),
        endLat: String(destCoords[0]),
        endLon: String(destCoords[1]),
        startName: startQuery,
        endName: destQuery
      });

      const res = await fetch(`http://localhost:5000/api/locations/route?${params.toString()}`);
      const data = await res.json();

      if (data.success) {
        setRouteResult(data);
        // Keep real road routes for offline use (not the straight-line fallback)
        if (data.provider === 'osrm') {
          saveRoute({
            from: startCoords,
            to: destCoords,
            coordinates: data.coordinates,
            distanceKm: data.distanceKm,
            durationMin: data.durationMinutes
          }).catch(() => {});
        }
      } else {
        setRouteError(data.message || 'Unable to compute route.');
      }
    } catch (err) {
      setRouteError(`Routing service error: ${err.message}. Network connection may be unavailable.`);
    } finally {
      setLoadingRoute(false);
    }
  };

  // Render Leaflet Map preview when routeResult changes
  useEffect(() => {
    if (!isOpen || !routeResult || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [routeResult.start.latitude, routeResult.start.longitude],
        zoom: 12
      });

      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);

      polylineLayerRef.current = L.polyline([], { color: '#16a34a', weight: 4 }).addTo(map);
      markersGroupRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    markersGroupRef.current.clearLayers();

    // Start marker (green)
    const startIcon = L.divIcon({
      className: 'start-route-pin',
      html: `
        <div style="background-color: #15803d; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2.5px solid white; box-shadow: 0 4px 8px rgba(0,0,0,0.3);">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><polygon points="12 8 8 12 12 16 12 8"></polygon></svg>
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 28]
    });

    // Destination marker (red)
    const destIcon = L.divIcon({
      className: 'dest-route-pin',
      html: `
        <div style="background-color: #dc2626; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 2.5px solid white; box-shadow: 0 4px 8px rgba(0,0,0,0.3);">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 28]
    });

    L.marker([routeResult.start.latitude, routeResult.start.longitude], { icon: startIcon })
      .bindPopup(`<strong>Starting Point:</strong><br/>${routeResult.start.name}`)
      .addTo(markersGroupRef.current);

    L.marker([routeResult.destination.latitude, routeResult.destination.longitude], { icon: destIcon })
      .bindPopup(`<strong>Destination:</strong><br/>${routeResult.destination.name}`)
      .addTo(markersGroupRef.current);

    // Draw route polyline
    polylineLayerRef.current.setLatLngs(routeResult.coordinates);
    map.fitBounds(polylineLayerRef.current.getBounds(), { padding: [30, 30] });

  }, [isOpen, routeResult]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto shadow-float border border-roam-stone/80 dark:border-roam-nightborder p-6 space-y-6">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-roam-stone/60 dark:border-roam-nightborder pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-roam-green/10 dark:bg-roam-mint/20 text-roam-green dark:text-roam-mint">
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
                Worldwide Route Planning
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Plan road & trail trajectories between any two locations worldwide.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Inputs */}
        <div className="space-y-4">
          
          {/* Start Location Input */}
          <div className="relative">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Starting Location
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={startQuery}
                onChange={(e) => handleSearchStart(e.target.value)}
                placeholder="Search starting city, coordinates, or GPS..."
                className="w-full pl-10 pr-24 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-white dark:bg-roam-night text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green"
              />
              <button
                type="button"
                onClick={() => {
                  if (currentGps) {
                    setStartCoords(currentGps);
                    setStartQuery('Current GPS Location');
                  }
                }}
                className="absolute right-2 top-2 px-2.5 py-1 rounded-lg bg-roam-green/10 dark:bg-roam-mint/20 text-roam-green dark:text-roam-mint text-[11px] font-bold"
              >
                Use GPS
              </button>
            </div>

            {/* Start Suggestions Dropdown */}
            {startSuggestions.length > 0 && (
              <div className="absolute z-20 top-full left-0 right-0 mt-1 bg-white dark:bg-roam-night border border-roam-stone dark:border-roam-nightborder rounded-xl shadow-lg max-h-48 overflow-y-auto">
                {startSuggestions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => {
                      setStartQuery(s.displayName || s.name);
                      setStartCoords([s.latitude, s.longitude]);
                      setStartSuggestions([]);
                    }}
                    className="w-full p-2.5 text-left text-xs hover:bg-roam-sand/50 dark:hover:bg-roam-nightcard border-b border-roam-stone/40 last:border-none"
                  >
                    <div className="font-bold text-slate-800 dark:text-slate-100">{s.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{s.displayName}</div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Destination Location Input */}
          <div className="relative">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Destination Location
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-rose-600 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={destQuery}
                onChange={(e) => handleSearchDest(e.target.value)}
                placeholder="Search worldwide destination..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-white dark:bg-roam-night text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green"
              />
            </div>

            {/* Destination Suggestions Dropdown */}
            {destSuggestions.length > 0 && (
              <div className="absolute z-20 top-full left-0 right-0 mt-1 bg-white dark:bg-roam-night border border-roam-stone dark:border-roam-nightborder rounded-xl shadow-lg max-h-48 overflow-y-auto">
                {destSuggestions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => {
                      setDestQuery(s.displayName || s.name);
                      setDestCoords([s.latitude, s.longitude]);
                      setDestSuggestions([]);
                    }}
                    className="w-full p-2.5 text-left text-xs hover:bg-roam-sand/50 dark:hover:bg-roam-nightcard border-b border-roam-stone/40 last:border-none"
                  >
                    <div className="font-bold text-slate-800 dark:text-slate-100">{s.name}</div>
                    <div className="text-[10px] text-slate-400 truncate">{s.displayName}</div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Calculate Route Button */}
          <button
            type="button"
            onClick={handleCalculateRoute}
            disabled={loadingRoute}
            className="w-full py-3 rounded-2xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:text-roam-night font-bold text-sm shadow-sm transition-all flex items-center justify-center gap-2"
          >
            {loadingRoute ? (
              <span className="flex items-center gap-2">
                <RotateCcw className="w-4 h-4 animate-spin" /> Calculating route...
              </span>
            ) : (
              <>
                <Navigation className="w-4 h-4" />
                <span>Calculate Worldwide Route</span>
              </>
            )}
          </button>
        </div>

        {/* Error message */}
        {routeError && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{routeError}</span>
          </div>
        )}

        {/* Route Results & Map Preview */}
        {routeResult && (
          <div className="space-y-4 pt-2">
            
            {/* Metric Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="p-3 rounded-2xl bg-roam-sand/50 dark:bg-roam-night border border-roam-stone/70 dark:border-roam-nightborder text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Distance</span>
                <span className="text-lg font-black text-slate-900 dark:text-white">
                  {formatDistance(routeResult.distanceKm, distanceUnit)}
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-roam-sand/50 dark:bg-roam-night border border-roam-stone/70 dark:border-roam-nightborder text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Est. Duration</span>
                <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                  {routeResult.formattedDuration}
                </span>
              </div>

              <div className="col-span-2 sm:col-span-1 p-3 rounded-2xl bg-roam-sand/50 dark:bg-roam-night border border-roam-stone/70 dark:border-roam-nightborder text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Routing Engine</span>
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 truncate block mt-0.5">
                  {routeResult.provider === 'osrm' ? 'OSRM Driving' : 'Geodesic Vector'}
                </span>
              </div>
            </div>

            {/* Interactive Leaflet Map Route Preview */}
            <div className="rounded-2xl overflow-hidden border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
              <div ref={mapContainerRef} className="h-64 w-full" />
            </div>

            {/* Offline Navigation Disclaimer */}
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-[11px] text-amber-800 dark:text-amber-300">
              <strong>Offline Routing Architecture Notice:</strong> {routeResult.offlineNavigationDisclaimer}
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
