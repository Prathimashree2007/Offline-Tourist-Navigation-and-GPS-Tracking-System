import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Compass, 
  Map, 
  Navigation, 
  Search, 
  Footprints, 
  HardDrive, 
  Sun, 
  Moon, 
  Wifi, 
  WifiOff, 
  User, 
  Menu, 
  X,
  Info,
  LogOut,
  MapPin
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

export default function Navbar() {
  const { user, isAuthenticated, isOnline, logout } = useAuth();
  const { isDarkMode, toggleDarkMode } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { to: '/dashboard', label: 'Explore', icon: Compass },
    { to: '/search', label: 'Search', icon: Search },
    { to: '/map', label: 'Offline Map', icon: Map },
    { to: '/nearby', label: 'Nearby POIs', icon: MapPin },
    { to: '/tracking', label: 'GPS Tracker', icon: Navigation },
    { to: '/history', label: 'Trips', icon: Footprints },
    { to: '/downloads', label: 'My Maps', icon: HardDrive },
    { to: '/about', label: 'About', icon: Info },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-roam-night/95 backdrop-blur-md border-b border-roam-stone/60 dark:border-roam-nightborder transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-roam-green to-roam-teal flex items-center justify-center text-white shadow-soft group-hover:scale-105 transition-transform">
              <Compass className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-roam-green dark:text-roam-mint">
                Roam<span className="text-roam-terracotta">Ready</span>
              </span>
              <span className="hidden sm:block text-[10px] text-slate-500 dark:text-slate-400 font-medium tracking-wide">
                Offline GPS Companion
              </span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                    active
                      ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm'
                      : 'text-slate-600 hover:text-roam-green dark:text-slate-300 dark:hover:text-roam-mint hover:bg-roam-sand dark:hover:bg-roam-nightcard'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{link.label}</span>
                </Link>
              );
            })}
          </nav>

          {/* Right Action Bar: Status Pill, Theme Toggle, Profile */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Real-time Online / Offline status badge */}
            <div 
              title={isOnline ? 'Online: Cloud APIs active' : 'Offline Mode: Local IndexedDB active'}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border transition-colors ${
                isOnline
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800'
                  : 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-950/50 dark:text-amber-300 dark:border-amber-700 animate-pulse'
              }`}
            >
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span className="hidden xs:inline">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>Offline</span>
                </>
              )}
            </div>

            {/* Dark Mode Toggle */}
            <button
              onClick={toggleDarkMode}
              aria-label="Toggle Dark Mode"
              className="p-2 rounded-xl text-slate-600 hover:text-roam-green hover:bg-roam-sand dark:text-slate-300 dark:hover:text-roam-mint dark:hover:bg-roam-nightcard transition-colors"
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Profile / Auth Button */}
            {isAuthenticated ? (
              <div className="flex items-center gap-2">
                <Link
                  to="/profile"
                  className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-xl border border-roam-stone dark:border-roam-nightborder hover:bg-roam-sand dark:hover:bg-roam-nightcard text-sm font-medium transition-colors"
                >
                  <div className="w-7 h-7 rounded-full bg-roam-green/20 dark:bg-roam-mint/20 text-roam-green dark:text-roam-mint flex items-center justify-center font-bold text-xs">
                    {user?.name ? user.name[0].toUpperCase() : 'U'}
                  </div>
                  <span className="hidden sm:inline font-semibold">{user?.name?.split(' ')[0]}</span>
                </Link>
                <button
                  onClick={logout}
                  title="Sign Out"
                  className="p-2 text-slate-400 hover:text-rose-500 rounded-lg transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <Link
                  to="/login"
                  className="px-3 py-1.5 text-xs sm:text-sm font-semibold text-roam-green dark:text-roam-mint hover:underline"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="px-3.5 py-1.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs sm:text-sm font-bold shadow-sm hover:opacity-90 transition-opacity"
                >
                  Sign Up
                </Link>
              </div>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-roam-sand dark:hover:bg-roam-nightcard"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-roam-stone dark:border-roam-nightborder bg-white dark:bg-roam-night px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const active = isActive(link.to);
            return (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-colors ${
                  active
                    ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-roam-sand dark:hover:bg-roam-nightcard'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{link.label}</span>
              </Link>
            );
          })}
          <div className="pt-2 border-t border-slate-100 dark:border-roam-nightborder">
            <Link
              to="/settings"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300"
            >
              <span>App Settings & Preferences</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
