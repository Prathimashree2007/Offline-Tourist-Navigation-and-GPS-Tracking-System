import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import L from 'leaflet';
import { 
  Compass, 
  MapPin, 
  Navigation, 
  Wifi, 
  WifiOff, 
  AlertTriangle, 
  Layers, 
  Crosshair, 
  Maximize2, 
  ShieldAlert, 
  PhoneCall, 
  CheckCircle2,
  HardDrive,
  Info
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { getAllDownloadedMaps, getDownloadedMap, getTouristPlaces } from '../utils/storage';
import { createOfflineTileLayer } from '../utils/offlineTileLayer';
import { calculateHaversineDistance, formatDistance, isPointInRadius } from '../utils/geo';
import { DESTINATIONS_CATALOG } from '../data/mockDestinations';
import { getRoute, bearingDegrees, compassPoint } from '../utils/routing';
import { getAllPins, savePin, deletePin } from '../utils/storage';
import MapAssistPanel from '../components/MapAssistPanel';

export default function OfflineMap() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const queryRegionId = searchParams.get('regionId');
  const queryLat = searchParams.get('lat') ? parseFloat(searchParams.get('lat')) : null;
  const queryLon = searchParams.get('lon') ? parseFloat(searchParams.get('lon')) : null;
  const queryName = searchParams.get('name') || 'Selected Location';

  const { isOnline } = useAuth();
  const { distanceUnit } = useTheme();

  const [downloadedRegions, setDownloadedRegions] = useState([]);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [pois, setPois] = useState([]);
  const [currentGps, setCurrentGps] = useState(null);
  const [gpsAccuracy, setGpsAccuracy] = useState(null);
  const [gpsSearching, setGpsSearching] = useState(true);
  const [gpsPermissionDenied, setGpsPermissionDenied] = useState(false);
  const [outsideCoverageWarning, setOutsideCoverageWarning] = useState(false);
  const [forceOfflineSimulation, setForceOfflineSimulation] = useState(false);
  const [activePoiPopup, setActivePoiPopup] = useState(null);

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const tileLayerRef = useRef(null);
  const gpsMarkerRef = useRef(null);
  const boundaryCircleRef = useRef(null);
  const poiLayerGroupRef = useRef(null);
  const routeLayerRef = useRef(null);
  const [activeRoute, setActiveRoute] = useState(null); // { name, source, distanceKm, durationMin, ... }
  const [routeLoading, setRouteLoading] = useState(false);
  const [panelTab, setPanelTab] = useState(null); // null | 'nearby' | 'pins' | 'sos'
  const [pins, setPins] = useState([]);
  const pinLayerRef = useRef(null);
  const showRouteRef = useRef(null);

  // Load downloaded regions from IndexedDB
  useEffect(() => {
    async function loadMaps() {
      let maps = await getAllDownloadedMaps();
      // If no regions are downloaded yet, offer pre-bundled Coorg region for instant demo
      if (maps.length === 0) {
        const demoDest = DESTINATIONS_CATALOG[0];
        const initialRegion = {
          id: `region_${demoDest.id}_10km`,
          regionName: `${demoDest.name} (10 km Demo Region)`,
          destinationId: demoDest.id,
          centerLat: demoDest.latitude,
          centerLon: demoDest.longitude,
          radiusKm: 10,
          tileCount: 96,
          storageMB: '3.50',
          poiCount: demoDest.pois.length,
          downloadedAt: new Date().toISOString()
        };
        maps = [initialRegion];
      }

      setDownloadedRegions(maps);

      if (queryLat !== null && queryLon !== null && !isNaN(queryLat) && !isNaN(queryLon)) {
        const customRegion = {
          id: `preview_${Math.round(queryLat * 10000)}_${Math.round(queryLon * 10000)}`,
          regionName: `${queryName} (Preview)`,
          centerLat: queryLat,
          centerLon: queryLon,
          radiusKm: 10,
          tileCount: 0,
          storageMB: '0.00',
          poiCount: 1,
          downloadedAt: new Date().toISOString()
        };
        setSelectedRegion(customRegion);
        setPois([{
          id: `poi_center`,
          name: queryName,
          category: 'viewpoints',
          latitude: queryLat,
          longitude: queryLon,
          description: `Location coordinates: ${queryLat.toFixed(4)}, ${queryLon.toFixed(4)}`,
          offlineAvailable: true
        }]);
      } else {
        const target = queryRegionId 
          ? maps.find(m => m.id === queryRegionId) || maps[0]
          : maps[0];

        setSelectedRegion(target);
      }
    }
    loadMaps();
  }, [queryRegionId, queryLat, queryLon, queryName]);

  // Load POIs for selected region
  useEffect(() => {
    if (!selectedRegion) return;
    async function fetchPois() {
      let loadedPois = await getTouristPlaces(selectedRegion.id);
      if (!loadedPois || loadedPois.length === 0) {
        const matchingCatalog = DESTINATIONS_CATALOG.find(d => d.id === selectedRegion.destinationId);
        loadedPois = matchingCatalog ? matchingCatalog.pois : DESTINATIONS_CATALOG[0].pois;
      }
      setPois(loadedPois);
    }
    fetchPois();
  }, [selectedRegion]);

  // GPS Geolocation Watch
  useEffect(() => {
    if (!('geolocation' in navigator)) {
      setGpsSearching(false);
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setGpsSearching(false);
        setGpsPermissionDenied(false);
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        const acc = Math.round(pos.coords.accuracy);

        setCurrentGps([lat, lon]);
        setGpsAccuracy(acc);

        // Check coverage boundary
        if (selectedRegion) {
          const inside = isPointInRadius(
            selectedRegion.centerLat,
            selectedRegion.centerLon,
            lat,
            lon,
            selectedRegion.radiusKm
          );
          setOutsideCoverageWarning(!inside);
        }
      },
      (err) => {
        setGpsSearching(false);
        if (err.code === 1) {
          setGpsPermissionDenied(true);
        }
        // Fallback GPS coordinates near center of selected region for seamless demonstration
        if (selectedRegion && !currentGps) {
          const fallbackLat = selectedRegion.centerLat + 0.005;
          const fallbackLon = selectedRegion.centerLon + 0.004;
          setCurrentGps([fallbackLat, fallbackLon]);
          setGpsAccuracy(8);
        }
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 2000 }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, [selectedRegion]);

  // Initialize and update Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current || !selectedRegion) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [selectedRegion.centerLat, selectedRegion.centerLon],
        zoom: 13,
        zoomControl: false // Custom controls
      });

      L.control.zoom({ position: 'bottomright' }).addTo(map);

      poiLayerGroupRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Remove existing tile layer and recreate with OfflineTileLayer
    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }

    const offlineLayer = createOfflineTileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      regionId: selectedRegion.id,
      isOfflineOnly: !isOnline || forceOfflineSimulation,
      maxZoom: 17,
      minZoom: 10,
      attribution: '&copy; OpenStreetMap | Offline RoamReady Engine',
      onCoverageWarning: () => {
        setOutsideCoverageWarning(true);
      }
    });

    offlineLayer.addTo(map);
    tileLayerRef.current = offlineLayer;

    // Draw Downloaded Coverage Boundary Circle
    if (boundaryCircleRef.current) {
      map.removeLayer(boundaryCircleRef.current);
    }

    const boundary = L.circle([selectedRegion.centerLat, selectedRegion.centerLon], {
      radius: selectedRegion.radiusKm * 1000,
      color: '#15803d',
      fillColor: '#22c55e',
      fillOpacity: 0.12,
      weight: 2.5,
      dashArray: '8, 8'
    }).addTo(map);

    boundaryCircleRef.current = boundary;

    // Move map view to region center
    map.setView([selectedRegion.centerLat, selectedRegion.centerLon], 13);

  }, [selectedRegion, isOnline, forceOfflineSimulation]);

  // Render POI markers and GPS marker
  useEffect(() => {
    if (!mapInstanceRef.current || !selectedRegion) return;
    const map = mapInstanceRef.current;

    // Clear previous POIs
    if (poiLayerGroupRef.current) {
      poiLayerGroupRef.current.clearLayers();
    }

    // Category Color & Icon Map
    const getCategoryStyles = (category) => {
      switch (category) {
        case 'waterfalls': return { bg: '#0284c7', border: '#ffffff', label: 'Waterfalls' };
        case 'viewpoints': return { bg: '#eab308', border: '#ffffff', label: 'Viewpoint' };
        case 'hills': return { bg: '#15803d', border: '#ffffff', label: 'Peak/Hill' };
        case 'beaches': return { bg: '#0d9488', border: '#ffffff', label: 'Beach' };
        case 'emergency': return { bg: '#e11d48', border: '#ffffff', label: 'Hospital/ER' };
        default: return { bg: '#64748b', border: '#ffffff', label: 'Attraction' };
      }
    };

    // Plot POIs
    pois.forEach((poi) => {
      const styles = getCategoryStyles(poi.category);
      const icon = L.divIcon({
        className: 'custom-poi-marker',
        html: `
          <div style="background-color: ${styles.bg}; color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.3); border: 2.5px solid ${styles.border}; cursor: pointer; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.15)'" onmouseout="this.style.transform='scale(1)'">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          </div>
        `,
        iconSize: [30, 30],
        iconAnchor: [15, 30]
      });

      const distKm = currentGps 
        ? calculateHaversineDistance(currentGps[0], currentGps[1], poi.latitude, poi.longitude, 'km')
        : null;

      const marker = L.marker([poi.latitude, poi.longitude], { icon });
      marker.on('click', () => {
        setActivePoiPopup({
          ...poi,
          approxDistance: formatDistance(distKm, distanceUnit)
        });
      });

      poiLayerGroupRef.current.addLayer(marker);
    });

    // Plot Destination Center Pin
    const destIcon = L.divIcon({
      className: 'dest-center-marker',
      html: `
        <div style="background-color: #1E3A2F; color: #52B788; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 14px rgba(0,0,0,0.4); border: 3px solid white;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>
        </div>
      `,
      iconSize: [36, 36],
      iconAnchor: [18, 36]
    });

    const destMarker = L.marker([selectedRegion.centerLat, selectedRegion.centerLon], { icon: destIcon })
      .bindPopup(`<strong>${selectedRegion.regionName}</strong><br/>Region Download Center`);
    poiLayerGroupRef.current.addLayer(destMarker);

    // Render GPS Current Location Marker with Radar Pulse
    if (currentGps) {
      if (gpsMarkerRef.current) {
        map.removeLayer(gpsMarkerRef.current);
      }

      const gpsIcon = L.divIcon({
        className: 'gps-pulse-container',
        html: `
          <div style="position: relative; width: 16px; height: 16px;">
            <div class="gps-pulse-ring"></div>
            <div class="gps-pulse-dot"></div>
          </div>
        `,
        iconSize: [16, 16],
        iconAnchor: [8, 8]
      });

      const gpsMarker = L.marker(currentGps, { icon: gpsIcon, zIndexOffset: 1000 })
        .addTo(map)
        .bindPopup(`<strong>Your Current GPS Location</strong><br/>Accuracy: ±${gpsAccuracy || 5} m`);

      gpsMarkerRef.current = gpsMarker;
    }

  }, [pois, currentGps, selectedRegion, gpsAccuracy, distanceUnit]);

  // Show road route (live / saved offline / straight-line fallback) from the tourist to a place
  const handleShowRoute = async (name, lat, lon) => {
    if (!mapInstanceRef.current || !selectedRegion) return;
    const map = mapInstanceRef.current;
    const from = currentGps || [selectedRegion.centerLat, selectedRegion.centerLon];
    const to = [lat, lon];

    setRouteLoading(true);
    try {
      const route = await getRoute({
        from,
        to,
        regionId: selectedRegion.id,
        online: isOnline && !forceOfflineSimulation
      });

      if (routeLayerRef.current) {
        map.removeLayer(routeLayerRef.current);
      }
      const isLine = route.source === 'straight-line';
      const group = L.featureGroup();
      L.polyline(route.coordinates, {
        color: isLine ? '#f59e0b' : '#16a34a',
        weight: 5,
        opacity: 0.9,
        dashArray: isLine ? '10, 10' : null
      }).addTo(group);
      // dashed off-road parts: your GPS position -> nearest road, and road -> the place
      (route.connectors || []).forEach((seg) =>
        L.polyline(seg, { color: '#f59e0b', weight: 4, opacity: 0.9, dashArray: '8, 8' }).addTo(group)
      );
      routeLayerRef.current = group.addTo(map);
      map.fitBounds(group.getBounds(), { padding: [60, 60] });

      const bearing = Math.round(bearingDegrees(from[0], from[1], lat, lon));
      setActiveRoute({ name, ...route, bearing, compass: compassPoint(bearing) });
    } finally {
      setRouteLoading(false);
    }
  };

  showRouteRef.current = handleShowRoute;

  const refreshPins = async () => setPins(await getAllPins());
  useEffect(() => { refreshPins(); }, []);

  // Draw the tourist's own pins on the map
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;
    if (pinLayerRef.current) map.removeLayer(pinLayerRef.current);
    pinLayerRef.current = L.layerGroup().addTo(map);
    pins.forEach((pin) => {
      const icon = L.divIcon({
        className: '',
        html: `<div style="background:#2563eb;color:#fff;border:2px solid #fff;border-radius:8px;padding:2px 6px;font-size:11px;font-weight:700;white-space:nowrap;box-shadow:0 2px 6px rgba(0,0,0,.3)">${String(pin.name).replace(/[<>&]/g, '')}</div>`,
        iconAnchor: [10, 10]
      });
      L.marker([pin.latitude, pin.longitude], { icon })
        .on('click', () => showRouteRef.current?.(pin.name, pin.latitude, pin.longitude))
        .addTo(pinLayerRef.current);
    });
  }, [pins, selectedRegion]);

  const handleSavePin = async (pin) => {
    await savePin({ ...pin, regionId: selectedRegion?.id || null });
    refreshPins();
  };

  const handleDeletePin = async (id) => {
    await deletePin(id);
    refreshPins();
  };

  const handleClearRoute = () => {
    if (routeLayerRef.current && mapInstanceRef.current) {
      mapInstanceRef.current.removeLayer(routeLayerRef.current);
      routeLayerRef.current = null;
    }
    setActiveRoute(null);
  };

  // Recenter to GPS location
  const handleRecenterGps = () => {
    if (currentGps && mapInstanceRef.current) {
      mapInstanceRef.current.flyTo(currentGps, 15);
    }
  };

  // Recenter to Region Coverage
  const handleRecenterRegion = () => {
    if (boundaryCircleRef.current && mapInstanceRef.current) {
      mapInstanceRef.current.fitBounds(boundaryCircleRef.current.getBounds(), { padding: [30, 30] });
    }
  };

  return (
    <div className="relative h-[calc(100vh-4rem)] w-full flex flex-col overflow-hidden bg-roam-night">
      
      {/* Top Floating Control Bar */}
      <div className="absolute top-4 left-4 right-4 z-30 pointer-events-none flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        
        {/* Region Selector Card */}
        <div className="pointer-events-auto bg-white/95 dark:bg-roam-nightcard/95 backdrop-blur-md px-4 py-2 rounded-2xl border border-roam-stone dark:border-roam-nightborder shadow-float flex items-center gap-3">
          <HardDrive className="w-4 h-4 text-roam-green dark:text-roam-mint" />
          <div>
            <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
              Active Offline Region
            </label>
            <select
              value={selectedRegion?.id || ''}
              onChange={(e) => {
                const found = downloadedRegions.find(r => r.id === e.target.value);
                if (found) setSelectedRegion(found);
              }}
              className="bg-transparent text-xs font-extrabold text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer"
            >
              {downloadedRegions.map((region) => (
                <option key={region.id} value={region.id} className="dark:bg-roam-night">
                  {region.regionName} ({region.radiusKm} km)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* GPS & Network Diagnostics Pills */}
        <div className="pointer-events-auto flex items-center gap-2">
          
          {/* GPS Accuracy Pill */}
          <div className="bg-white/95 dark:bg-roam-nightcard/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-roam-stone dark:border-roam-nightborder shadow-soft flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>
              {gpsSearching ? 'Acquiring GPS...' : `GPS: ±${gpsAccuracy || 5}m`}
            </span>
          </div>

          {/* Offline Simulation Toggle Button for Viva Presentation */}
          <button
            onClick={() => setForceOfflineSimulation(!forceOfflineSimulation)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors shadow-soft flex items-center gap-1.5 ${
              forceOfflineSimulation
                ? 'bg-rose-600 text-white border-rose-700'
                : 'bg-white/95 dark:bg-roam-nightcard/95 text-slate-700 dark:text-slate-200 border-roam-stone dark:border-roam-nightborder'
            }`}
            title="Click to simulate zero internet connectivity during viva presentation"
          >
            {forceOfflineSimulation ? <WifiOff className="w-3.5 h-3.5" /> : <Wifi className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">
              {forceOfflineSimulation ? 'Offline Sim Active' : 'Simulate Offline'}
            </span>
          </button>

        </div>
      </div>

      {/* Coverage Boundary Warning Alert */}
      {outsideCoverageWarning && (
        <div className="absolute top-20 left-4 right-4 z-30 pointer-events-auto max-w-lg mx-auto bg-amber-600/95 text-white px-4 py-2.5 rounded-2xl shadow-float backdrop-blur-md border border-amber-400 flex items-center justify-between text-xs font-medium animate-slide-down">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 animate-bounce" />
            <span>
              <strong>Outside Downloaded Coverage:</strong> You have moved outside the cached {selectedRegion?.radiusKm} km radius. Map tiles beyond this boundary are unavailable offline.
            </span>
          </div>
          <button
            onClick={handleRecenterRegion}
            className="ml-3 px-2.5 py-1 rounded-lg bg-black/20 hover:bg-black/30 font-bold text-[11px] flex-shrink-0"
          >
            Fit Coverage
          </button>
        </div>
      )}

      {/* Full-screen Leaflet Map Container */}
      <div ref={mapContainerRef} className="flex-1 w-full h-full z-10" />

      {/* Floating Recenter & Action Controls (Bottom Right) */}
      <div className="absolute bottom-8 right-4 z-30 flex flex-col gap-2">
        <button
          onClick={handleRecenterGps}
          title="Recenter to current GPS location"
          className="w-12 h-12 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-roam-green dark:text-roam-mint shadow-float flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
        >
          <Crosshair className="w-5 h-5" />
        </button>

        <button
          onClick={() => setPanelTab(panelTab === 'nearby' ? null : 'nearby')}
          title="Nearby places"
          className="w-12 h-12 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-roam-green dark:text-roam-mint shadow-float flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
        >
          <MapPin className="w-5 h-5" />
        </button>

        <button
          onClick={() => setPanelTab(panelTab === 'sos' ? null : 'sos')}
          title="SOS and emergency"
          className="w-12 h-12 rounded-2xl bg-red-600 text-white border border-red-700 shadow-float flex items-center justify-center font-extrabold text-xs hover:scale-105 active:scale-95 transition-all"
        >
          SOS
        </button>

        <button
          onClick={() => handleShowRoute(selectedRegion?.regionName || 'Destination', selectedRegion.centerLat, selectedRegion.centerLon)}
          title="Show route to destination"
          className="w-12 h-12 rounded-2xl bg-roam-green text-white border border-roam-stone dark:border-roam-nightborder shadow-float flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
        >
          <Navigation className="w-5 h-5" />
        </button>

        <button
          onClick={handleRecenterRegion}
          title="Fit Downloaded Boundary Circle"
          className="w-12 h-12 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-slate-700 dark:text-slate-200 shadow-float flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
        >
          <Compass className="w-5 h-5" />
        </button>
      </div>

      {panelTab && selectedRegion && (
        <MapAssistPanel
          tab={panelTab}
          onTabChange={setPanelTab}
          onClose={() => setPanelTab(null)}
          pois={pois}
          currentGps={currentGps}
          regionCenter={[selectedRegion.centerLat, selectedRegion.centerLon]}
          distanceUnit={distanceUnit}
          pins={pins}
          onSavePin={handleSavePin}
          onDeletePin={handleDeletePin}
          onRoute={(name, lat, lon) => {
            setPanelTab(null);
            handleShowRoute(name, lat, lon);
          }}
        />
      )}

      {/* Route summary */}
      {activeRoute && (
        <div className="absolute top-36 left-4 right-4 sm:left-6 sm:max-w-md z-30 bg-white/95 dark:bg-roam-nightcard/95 backdrop-blur-md p-4 rounded-2xl border border-roam-stone dark:border-roam-nightborder shadow-float">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Route to</p>
              <p className="font-extrabold text-sm text-slate-900 dark:text-white">{activeRoute.name}</p>
            </div>
            <button onClick={handleClearRoute} className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1">✕</button>
          </div>
          <p className="mt-1 text-xs font-bold text-emerald-600 dark:text-emerald-400">
            {formatDistance(activeRoute.distanceKm, distanceUnit)} • about {activeRoute.durationMin} min
          </p>
          {activeRoute.steps?.length > 0 && (
            <details className="mt-2">
              <summary className="text-[11px] font-bold text-roam-green cursor-pointer">Directions ({activeRoute.steps.length} steps)</summary>
              <ol className="mt-1.5 max-h-40 overflow-y-auto space-y-1 text-[11px] text-slate-600 dark:text-slate-300 list-decimal pl-4">
                {activeRoute.steps.filter((st) => st.instruction).map((st, i) => (
                  <li key={i} className="capitalize">{st.instruction} <span className="text-slate-400">({st.distanceKm} km)</span></li>
                ))}
              </ol>
            </details>
          )}
          {activeRoute.startGapKm > 0.1 && (
            <p className="mt-1 text-[11px] font-bold text-amber-600">
              The nearest road is about {formatDistance(activeRoute.startGapKm, distanceUnit)} from your position. The dashed orange line is the off-road part.
            </p>
          )}
          <p className="mt-1 text-[11px] text-slate-500">
            {activeRoute.source === 'live' && 'Live road route (saved for offline use).'}
            {activeRoute.source === 'saved' && 'Road route saved on this device.'}
            {activeRoute.source === 'saved-nearby' && 'Saved road route (joined from your nearby position).'}
            {activeRoute.source === 'straight-line' &&
              `No road route saved for this place. Head ${activeRoute.compass} (${activeRoute.bearing}°) in a straight line.`}
          </p>
        </div>
      )}

      {/* Selected POI Bottom Sheet / Card */}
      {activePoiPopup && (
        <div className="absolute bottom-6 left-4 right-4 sm:left-6 sm:max-w-md z-30 bg-white/95 dark:bg-roam-nightcard/95 backdrop-blur-md p-5 rounded-3xl border border-roam-stone dark:border-roam-nightborder shadow-float animate-slide-up">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-roam-terracotta">
                  {activePoiPopup.category}
                </span>
                <span className="text-slate-400 text-xs">•</span>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  Approx. {activePoiPopup.approxDistance} away
                </span>
              </div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white mt-0.5">
                {activePoiPopup.name}
              </h3>
            </div>
            <button
              onClick={() => setActivePoiPopup(null)}
              className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1"
            >
              ✕
            </button>
          </div>

          <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            {activePoiPopup.description}
          </p>

          {activePoiPopup.emergencyContact && (
            <div className="mt-2.5 p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2 font-semibold">
              <PhoneCall className="w-3.5 h-3.5" />
              <span>{activePoiPopup.emergencyContact}</span>
            </div>
          )}

          <button
            onClick={() => handleShowRoute(activePoiPopup.name, activePoiPopup.latitude, activePoiPopup.longitude)}
            disabled={routeLoading}
            className="mt-3 w-full py-2 rounded-xl bg-roam-green text-white text-xs font-bold flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-60"
          >
            <Navigation className="w-4 h-4" />
            {routeLoading ? 'Finding route...' : 'Show route to this place'}
          </button>

          <div className="mt-4 pt-3 border-t border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between text-[11px] text-slate-500">
            <span>Coordinates: {activePoiPopup.latitude.toFixed(4)}, {activePoiPopup.longitude.toFixed(4)}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">Cached 100% Offline</span>
          </div>
        </div>
      )}

    </div>
  );
}
