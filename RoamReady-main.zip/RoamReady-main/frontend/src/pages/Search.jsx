import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Search as SearchIcon, 
  MapPin, 
  Filter, 
  DownloadCloud, 
  Info, 
  Compass, 
  Clock, 
  X,
  RotateCcw,
  AlertCircle,
  CheckCircle2,
  Bookmark,
  Star,
  Navigation,
  ExternalLink,
  Map as MapIcon,
  Globe,
  Sliders,
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import { CATEGORIES_LIST, DESTINATIONS_CATALOG } from '../data/mockDestinations';
import { saveLocalDestination, toggleFavourite, isFavourite } from '../utils/storage';
import { useAuth } from '../context/AuthContext';
import RoutePlannerModal from '../components/RoutePlannerModal';
import MapPreviewModal from '../components/MapPreviewModal';

const RECENT_SEARCHES_KEY = 'roamready_recent_searches_v2';

export default function Search() {
  const navigate = useNavigate();
  const { isOnline } = useAuth();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeTab, setActiveTab] = useState('global'); // 'global' | 'curated' | 'saved'

  // Dynamic Search State
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [isCoordinateQuery, setIsCoordinateQuery] = useState(false);

  // Selected Destination State
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [savedStatus, setSavedStatus] = useState({}); // id -> { saved: boolean, message: string }
  const [favStatus, setFavStatus] = useState({}); // id -> boolean

  // Modals
  const [previewLocation, setPreviewLocation] = useState(null);
  const [isRouteModalOpen, setIsRouteModalOpen] = useState(false);
  const [routeTargetLocation, setRouteTargetLocation] = useState(null);

  // Recent Searches
  const [recentSearches, setRecentSearches] = useState(() => {
    try {
      const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
      return saved ? JSON.parse(saved) : ['Tokyo', 'Eiffel Tower', 'Kedarnath', '12.4244, 75.7382', 'Coorg'];
    } catch {
      return ['Tokyo', 'Kedarnath', 'Coorg'];
    }
  });

  const abortControllerRef = useRef(null);
  const debounceTimerRef = useRef(null);

  // Coordinate Regex Detector
  const checkIsCoordinate = (str) => {
    const coordRegex = /^\s*(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)\s*$/;
    return coordRegex.test(str.trim());
  };

  // Perform dynamic search
  const performSearch = async (query, category = 'all') => {
    const trimmed = query.trim();
    if (!trimmed) {
      setSearchResults([]);
      setIsLoading(false);
      setSearchError(null);
      setHasSearched(false);
      setIsCoordinateQuery(false);
      return;
    }

    setIsCoordinateQuery(checkIsCoordinate(trimmed));
    setIsLoading(true);
    setSearchError(null);
    setHasSearched(true);

    // Cancel prior pending request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();

    try {
      const params = new URLSearchParams({
        q: trimmed,
        limit: '15'
      });
      if (category && category !== 'all') {
        params.append('category', category);
      }

      const res = await fetch(`http://localhost:5000/api/locations/search?${params.toString()}`, {
        signal: abortControllerRef.current.signal
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      if (data.success && Array.isArray(data.locations)) {
        setSearchResults(data.locations);

        // Save to recent searches
        saveRecentSearch(trimmed);
      } else {
        setSearchResults([]);
      }
    } catch (err) {
      if (err.name === 'AbortError') return;
      console.warn('Location search error:', err.message);
      setSearchError(
        !navigator.onLine
          ? 'Network is offline. Cannot query worldwide geocoding provider right now. You can view previously saved or curated destinations.'
          : 'Unable to reach location search provider. Please check your connection or retry.'
      );
      setSearchResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  const saveRecentSearch = (term) => {
    setRecentSearches(prev => {
      const filtered = prev.filter(item => item.toLowerCase() !== term.toLowerCase());
      const updated = [term, ...filtered].slice(0, 8);
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleClearRecent = () => {
    setRecentSearches([]);
    localStorage.removeItem(RECENT_SEARCHES_KEY);
  };

  // Debounced input handler
  const handleInputChange = (e) => {
    const val = e.target.value;
    setSearchTerm(val);

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    if (!val.trim()) {
      setSearchResults([]);
      setIsLoading(false);
      setHasSearched(false);
      return;
    }

    debounceTimerRef.current = setTimeout(() => {
      performSearch(val, selectedCategory);
    }, 380);
  };

  const handleRecentClick = (term) => {
    setSearchTerm(term);
    performSearch(term, selectedCategory);
  };

  const handleCategoryChange = (catId) => {
    setSelectedCategory(catId);
    if (searchTerm.trim()) {
      performSearch(searchTerm, catId);
    }
  };

  // Save destination to backend and IndexedDB
  const handleSaveDestination = async (loc) => {
    try {
      // 1. Save in IndexedDB locally
      await saveLocalDestination({
        id: loc.id,
        name: loc.name,
        displayName: loc.displayName,
        state: loc.state,
        country: loc.country,
        latitude: loc.latitude,
        longitude: loc.longitude,
        category: loc.category,
        provider: loc.provider,
        source: 'user_saved'
      });

      // 2. Sync with backend API
      if (isOnline) {
        const res = await fetch('http://localhost:5000/api/destinations', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: loc.name,
            displayName: loc.displayName,
            state: loc.state,
            country: loc.country,
            latitude: loc.latitude,
            longitude: loc.longitude,
            category: loc.category,
            externalId: loc.externalId,
            provider: loc.provider,
            source: 'user_saved'
          })
        });
        const data = await res.json();
        setSavedStatus(prev => ({
          ...prev,
          [loc.id]: { saved: true, message: data.message || 'Saved successfully' }
        }));
      } else {
        setSavedStatus(prev => ({
          ...prev,
          [loc.id]: { saved: true, message: 'Saved to offline IndexedDB storage.' }
        }));
      }
    } catch {
      setSavedStatus(prev => ({
        ...prev,
        [loc.id]: { saved: true, message: 'Saved locally for offline access.' }
      }));
    }
  };

  // Toggle Favourite
  const handleToggleFavourite = async (loc) => {
    const isNowFav = await toggleFavourite({
      id: loc.id,
      name: loc.name,
      displayName: loc.displayName,
      latitude: loc.latitude,
      longitude: loc.longitude,
      category: loc.category
    });

    setFavStatus(prev => ({ ...prev, [loc.id]: isNowFav }));
  };

  // Navigate to Map Planning with dynamic coordinates
  const handlePlanDownload = (loc) => {
    const params = new URLSearchParams({
      lat: String(loc.latitude),
      lon: String(loc.longitude),
      name: loc.name,
      category: loc.category || 'other',
      state: loc.state || '',
      country: loc.country || '',
      desc: loc.displayName || ''
    });
    navigate(`/planning?${params.toString()}`);
  };

  // Open Route Planning Modal
  const handleOpenRoute = (loc) => {
    setRouteTargetLocation(loc);
    setIsRouteModalOpen(true);
  };

  // Curated Catalog Filtering
  const filteredCurated = useMemo(() => {
    return DESTINATIONS_CATALOG.filter((dest) => {
      const matchesQuery = 
        !searchTerm.trim() ||
        dest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dest.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
        dest.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCat = selectedCategory === 'all' || dest.category === selectedCategory;
      return matchesQuery && matchesCat;
    });
  }, [searchTerm, selectedCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint text-xs font-bold uppercase tracking-wider mb-2">
            <Globe className="w-3.5 h-3.5" />
            Global Geocoding & Worldwide Discovery
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Worldwide Destination Search
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-2xl">
            Search for any city, mountain peak, remote waterfall, village, trekking location, or coordinate pair anywhere in the world.
          </p>
        </div>

        {/* Global vs Curated View Mode Toggle */}
        <div className="flex items-center p-1 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder shadow-soft">
          <button
            onClick={() => setActiveTab('global')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'global'
                ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Worldwide Search</span>
          </button>

          <button
            onClick={() => setActiveTab('curated')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'curated'
                ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Popular Curated</span>
          </button>
        </div>
      </div>

      {/* Main Search Input Bar */}
      <div className="relative max-w-3xl">
        <div className="relative">
          <SearchIcon className="w-5 h-5 text-slate-400 absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={handleInputChange}
            placeholder="Search worldwide (e.g. Tokyo, Eiffel Tower, Kedarnath, remote waterfall, or 12.4244, 75.7382)..."
            className="w-full pl-12 pr-28 py-3.5 rounded-2xl border border-roam-stone dark:border-roam-nightborder bg-white dark:bg-roam-nightcard text-sm text-slate-800 dark:text-slate-100 placeholder:text-slate-400 shadow-soft focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
          />
          <div className="absolute right-3 top-2.5 flex items-center gap-1.5">
            {isLoading && (
              <RotateCcw className="w-4 h-4 text-roam-green dark:text-roam-mint animate-spin mr-1" />
            )}
            {searchTerm && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSearchResults([]);
                  setHasSearched(false);
                }}
                className="px-2.5 py-1 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 font-bold"
              >
                Clear
              </button>
            )}
            <button
              onClick={() => performSearch(searchTerm, selectedCategory)}
              className="px-3.5 py-1.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90 transition-opacity"
            >
              Search
            </button>
          </div>
        </div>

        {/* Coordinate Search Banner Indicator */}
        {isCoordinateQuery && (
          <div className="mt-2 px-3.5 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2 animate-slide-down">
            <MapPin className="w-4 h-4 flex-shrink-0" />
            <span>
              <strong>GPS Coordinate Query Detected:</strong> Resolving location and reverse geocoding directly to the map.
            </span>
          </div>
        )}
      </div>

      {/* Recent Search Chips */}
      {recentSearches.length > 0 && !searchTerm && (
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <span className="flex items-center gap-1 text-slate-400 font-medium">
            <Clock className="w-3.5 h-3.5" /> Recent Queries:
          </span>
          {recentSearches.map((term) => (
            <button
              key={term}
              onClick={() => handleRecentClick(term)}
              className="px-3 py-1 rounded-full bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder text-slate-600 dark:text-slate-300 hover:border-roam-green dark:hover:border-roam-mint transition-colors"
            >
              {term}
            </button>
          ))}
          <button
            onClick={handleClearRecent}
            className="text-[11px] text-slate-400 hover:text-slate-600 underline ml-2"
          >
            Clear History
          </button>
        </div>
      )}

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {CATEGORIES_LIST.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => handleCategoryChange(cat.id)}
              className={`flex-shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                isSelected
                  ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm scale-105'
                  : 'bg-white dark:bg-roam-nightcard text-slate-600 dark:text-slate-300 border border-roam-stone/70 dark:border-roam-nightborder hover:bg-roam-sand dark:hover:bg-roam-night'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Selected Location Highlight Card (When user clicks a result) */}
      {selectedLocation && (
        <div className="p-6 rounded-3xl bg-gradient-to-r from-roam-green/10 via-emerald-500/10 to-teal-500/10 border-2 border-roam-green/50 dark:border-roam-mint/50 shadow-soft animate-slide-down">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 rounded-md bg-roam-green text-white text-[10px] font-bold uppercase tracking-wider">
                  Active Selected Destination
                </span>
                <span className="text-xs font-bold text-slate-500">
                  {selectedLocation.latitude.toFixed(4)}, {selectedLocation.longitude.toFixed(4)}
                </span>
              </div>
              <h2 className="text-xl font-black text-slate-900 dark:text-white">
                {selectedLocation.name}
              </h2>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                {selectedLocation.displayName}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setPreviewLocation(selectedLocation)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-roam-nightcard border border-roam-stone text-xs font-bold text-slate-700 dark:text-slate-200 shadow-sm hover:border-roam-green"
              >
                <MapIcon className="w-3.5 h-3.5 text-roam-green" />
                <span>View Map Preview</span>
              </button>

              <button
                onClick={() => handleSaveDestination(selectedLocation)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-roam-nightcard border border-roam-stone text-xs font-bold text-slate-700 dark:text-slate-200 shadow-sm hover:border-roam-green"
              >
                <Bookmark className="w-3.5 h-3.5 text-roam-terracotta" />
                <span>{savedStatus[selectedLocation.id]?.saved ? 'Saved ✓' : 'Save Destination'}</span>
              </button>

              <button
                onClick={() => handleOpenRoute(selectedLocation)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-roam-nightcard border border-roam-stone text-xs font-bold text-slate-700 dark:text-slate-200 shadow-sm hover:border-roam-green"
              >
                <Navigation className="w-3.5 h-3.5 text-blue-600" />
                <span>Plan Route</span>
              </button>

              <button
                onClick={() => handlePlanDownload(selectedLocation)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-95"
              >
                <DownloadCloud className="w-4 h-4" />
                <span>Plan Offline Map Download</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ERROR STATE */}
      {searchError && (
        <div className="p-6 rounded-3xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-sm text-rose-900 dark:text-rose-200">
                Location Search Notice
              </h3>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">
                {searchError}
              </p>
            </div>
          </div>
          <button
            onClick={() => performSearch(searchTerm, selectedCategory)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold shadow-sm hover:bg-rose-700"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Retry Search</span>
          </button>
        </div>
      )}

      {/* MAIN VIEW: GLOBAL SEARCH RESULTS */}
      {activeTab === 'global' && (
        <div className="space-y-4">
          
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-roam-stone/60 dark:border-roam-nightborder">
            <span>
              {hasSearched ? (
                <>Found <strong>{searchResults.length}</strong> dynamic worldwide result{searchResults.length !== 1 ? 's' : ''}</>
              ) : (
                'Type any location name or coordinates to query live worldwide geocoding data'
              )}
            </span>
            <span className="flex items-center gap-1">
              <Globe className="w-3.5 h-3.5 text-roam-green dark:text-roam-mint" />
              Powered by OpenStreetMap & Nominatim
            </span>
          </div>

          {/* EMPTY RESULTS STATE */}
          {hasSearched && !isLoading && searchResults.length === 0 && !searchError && (
            <div className="p-12 text-center bg-white dark:bg-roam-nightcard rounded-3xl border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
              <Compass className="w-12 h-12 text-slate-400 mx-auto mb-3 animate-spin-slow" />
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                No worldwide locations found for "{searchTerm}"
              </h3>
              <p className="mt-1 text-xs text-slate-500 max-w-md mx-auto">
                Try checking the spelling, entering a broader town or state name, or entering exact GPS coordinates like "12.4244, 75.7382".
              </p>
            </div>
          )}

          {/* RESULTS GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {searchResults.map((loc) => (
              <div
                key={loc.id}
                onClick={() => setSelectedLocation(loc)}
                className={`bg-white dark:bg-roam-nightcard rounded-3xl p-5 border shadow-soft flex flex-col justify-between cursor-pointer transition-all hover:shadow-float ${
                  selectedLocation?.id === loc.id
                    ? 'border-roam-green dark:border-roam-mint ring-2 ring-roam-green/20'
                    : 'border-roam-stone/80 dark:border-roam-nightborder hover:border-roam-green/50'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint text-[10px] font-bold uppercase tracking-wider">
                      {loc.category || 'Location'}
                    </span>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleToggleFavourite(loc);
                      }}
                      className="p-1 text-slate-400 hover:text-amber-500"
                    >
                      <Star className={`w-4 h-4 ${favStatus[loc.id] ? 'fill-amber-400 text-amber-400' : ''}`} />
                    </button>
                  </div>

                  <h3 className="font-extrabold text-base text-slate-900 dark:text-white mt-2 leading-snug">
                    {loc.name}
                  </h3>

                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                    {loc.displayName}
                  </div>

                  <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
                    <span>GPS: {loc.latitude.toFixed(4)}, {loc.longitude.toFixed(4)}</span>
                    <span className="capitalize">{loc.provider || 'OSM'}</span>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setPreviewLocation(loc);
                    }}
                    className="flex items-center gap-1 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-roam-green"
                  >
                    <MapIcon className="w-3.5 h-3.5" />
                    <span>Preview</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSaveDestination(loc);
                      }}
                      className="p-2 rounded-xl border border-roam-stone dark:border-roam-nightborder text-slate-600 dark:text-slate-300 hover:border-roam-green"
                      title="Save destination"
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePlanDownload(loc);
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90"
                    >
                      <DownloadCloud className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* POPULAR CURATED DESTINATIONS (Sample Seed Data) */}
      {(activeTab === 'curated' || (!hasSearched && searchResults.length === 0)) && (
        <div className="space-y-4 pt-4 border-t border-roam-stone/80 dark:border-roam-nightborder">
          
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
                  Popular Curated Destinations
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-roam-sand dark:bg-roam-night text-slate-600 dark:text-slate-400 border border-roam-stone/80 dark:border-roam-nightborder">
                  Sample Seed Data
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Western Ghats & Coastal hiking trails bundled with rich offline POI datasets.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCurated.map((dest) => (
              <div
                key={dest.id}
                className="bg-white dark:bg-roam-nightcard rounded-3xl overflow-hidden border border-roam-stone/80 dark:border-roam-nightborder shadow-soft flex flex-col justify-between group hover:shadow-float transition-all"
              >
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={dest.bannerImage}
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider">
                    {dest.category}
                  </div>
                  <div className="absolute bottom-3 right-3 px-2 py-0.5 rounded-md bg-white/90 dark:bg-roam-night/90 text-[10px] font-bold text-slate-700 dark:text-slate-200">
                    {dest.latitude.toFixed(4)}, {dest.longitude.toFixed(4)}
                  </div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-base text-slate-900 dark:text-white">
                      {dest.name}
                    </h3>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      {dest.state}, {dest.country} • Best: {dest.bestSeason}
                    </div>
                    <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                      {dest.description}
                    </p>
                  </div>

                  <div className="mt-5 pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between gap-2">
                    <Link
                      to={`/destination/${dest.id}`}
                      className="flex items-center gap-1 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-roam-green dark:hover:text-roam-mint"
                    >
                      <Info className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </Link>

                    <Link
                      to={`/planning?id=${dest.id}`}
                      className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90 transition-opacity"
                    >
                      <DownloadCloud className="w-3.5 h-3.5" />
                      <span>Plan Download</span>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* Map Preview Modal */}
      {previewLocation && (
        <MapPreviewModal
          isOpen={!!previewLocation}
          onClose={() => setPreviewLocation(null)}
          destination={previewLocation}
          onPlanDownload={(loc) => handlePlanDownload(loc)}
          onPlanRoute={(loc) => handleOpenRoute(loc)}
        />
      )}

      {/* Route Planner Modal */}
      {isRouteModalOpen && (
        <RoutePlannerModal
          isOpen={isRouteModalOpen}
          onClose={() => setIsRouteModalOpen(false)}
          initialDestination={routeTargetLocation}
        />
      )}

    </div>
  );
}
