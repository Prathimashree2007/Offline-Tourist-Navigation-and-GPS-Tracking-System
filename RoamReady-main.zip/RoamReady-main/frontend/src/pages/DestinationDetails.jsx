import React, { useMemo } from 'react';
import { useParams, useSearchParams, Link, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  MapPin, 
  Compass, 
  Calendar, 
  ShieldAlert, 
  DownloadCloud, 
  CheckCircle2, 
  Map, 
  PhoneCall,
  Sparkles
} from 'lucide-react';
import { DESTINATIONS_CATALOG } from '../data/mockDestinations';

export default function DestinationDetails() {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const queryLat = searchParams.get('lat');
  const queryLon = searchParams.get('lon');
  const queryName = searchParams.get('name');
  const queryCategory = searchParams.get('category');
  const queryState = searchParams.get('state');
  const queryCountry = searchParams.get('country');
  const queryDesc = searchParams.get('desc');

  const destination = useMemo(() => {
    if (queryLat !== null && queryLon !== null) {
      const lat = parseFloat(queryLat);
      const lon = parseFloat(queryLon);
      const name = queryName || 'Worldwide Location';
      return {
        id: id && !id.startsWith('coorg') ? id : `loc_${Math.round(lat * 10000)}_${Math.round(lon * 10000)}`,
        name,
        regionName: queryState || queryCountry || name,
        state: queryState || '',
        country: queryCountry || 'Worldwide',
        latitude: lat,
        longitude: lon,
        category: queryCategory || 'other',
        difficulty: 'moderate',
        bestSeason: 'Year-round',
        bannerImage: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1000&q=80',
        description: queryDesc || `Geographic region surrounding ${name}. Selected via worldwide dynamic search.`,
        pois: [
          {
            id: `poi_center_${Math.round(lat * 10000)}_${Math.round(lon * 10000)}`,
            name: `${name} (Center Point)`,
            category: queryCategory || 'viewpoints',
            latitude: lat,
            longitude: lon,
            description: `Primary focal landmark for ${name}`,
            offlineAvailable: true
          }
        ]
      };
    }
    return DESTINATIONS_CATALOG.find((d) => d.id === id) || DESTINATIONS_CATALOG[0];
  }, [id, queryLat, queryLon, queryName, queryCategory, queryState, queryCountry, queryDesc]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-20">
      
      {/* Back button */}
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-roam-green dark:hover:text-roam-mint transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to search</span>
      </button>

      {/* Hero Banner */}
      <div className="relative rounded-3xl overflow-hidden shadow-float">
        <img
          src={destination.bannerImage}
          alt={destination.name}
          className="w-full h-72 sm:h-96 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6 sm:p-10 text-white">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 rounded-full bg-roam-mint text-roam-night text-xs font-bold uppercase tracking-wider">
              {destination.category}
            </span>
            <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold">
              {destination.difficulty} trail difficulty
            </span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-black tracking-tight">{destination.name}</h1>
          <p className="text-xs sm:text-sm text-white/90 mt-1 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-roam-terracotta" />
            <span>{destination.state}, {destination.country}</span>
            <span>•</span>
            <span>GPS: {destination.latitude.toFixed(4)}° N, {destination.longitude.toFixed(4)}° E</span>
          </p>
        </div>
      </div>

      {/* Main Grid: Details & POIs */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Description & Included Sights */}
        <div className="lg:col-span-2 space-y-8">
          
          <div className="bg-white dark:bg-roam-nightcard p-6 sm:p-8 rounded-3xl border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-3">
              About Destination
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {destination.description}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-roam-stone/60 dark:border-roam-nightborder text-xs">
              <div>
                <span className="text-slate-400 block font-medium">Recommended Season</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 mt-0.5 block">{destination.bestSeason}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Region Zone</span>
                <span className="font-bold text-slate-800 dark:text-slate-200 mt-0.5 block">{destination.regionName}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Offline POI Count</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400 mt-0.5 block">{destination.pois.length} Sights</span>
              </div>
            </div>
          </div>

          {/* Bundled POIs List */}
          <div className="bg-white dark:bg-roam-nightcard p-6 sm:p-8 rounded-3xl border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  Bundled Offline Tourist Sights
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  These locations are automatically downloaded to IndexedDB with the map region.
                </p>
              </div>
              <span className="text-xs font-bold text-roam-green dark:text-roam-mint">
                {destination.pois.length} spots
              </span>
            </div>

            <div className="space-y-3">
              {destination.pois.map((poi) => (
                <div
                  key={poi.id}
                  className="p-4 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/70 dark:border-roam-nightborder flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-roam-green transition-colors"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold uppercase tracking-wider text-roam-terracotta">
                        {poi.category}
                      </span>
                      <span className="text-slate-400 text-xs">•</span>
                      <span className="text-xs text-slate-500 font-medium">
                        {poi.latitude.toFixed(4)}, {poi.longitude.toFixed(4)}
                      </span>
                    </div>
                    <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100 mt-0.5">
                      {poi.name}
                    </h3>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                      {poi.description}
                    </p>
                    {poi.emergencyContact && (
                      <div className="mt-1 text-[11px] text-rose-600 dark:text-rose-400 flex items-center gap-1 font-semibold">
                        <PhoneCall className="w-3 h-3" />
                        <span>{poi.emergencyContact}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex-shrink-0">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 text-[11px] font-bold">
                      <CheckCircle2 className="w-3 h-3" />
                      Offline Cached
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Download Card & Quick Actions */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-roam-nightcard p-6 rounded-3xl border border-roam-stone/80 dark:border-roam-nightborder shadow-soft sticky top-24">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              Ready to Download Map?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
              Download this entire geographical region so you can navigate, view your GPS location, and explore nearby spots even with zero cellular signal.
            </p>

            <Link
              to={`/planning?id=${destination.id}&lat=${destination.latitude}&lon=${destination.longitude}&name=${encodeURIComponent(destination.name)}&category=${destination.category}&state=${encodeURIComponent(destination.state || '')}&country=${encodeURIComponent(destination.country || '')}`}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:hover:bg-emerald-400 dark:text-roam-night font-bold text-sm shadow-md transition-all hover:scale-[1.01]"
            >
              <DownloadCloud className="w-4 h-4" />
              <span>Select Download Radius</span>
            </Link>

            <div className="mt-4 pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-center justify-between">
                <span>Radius Choices:</span>
                <span className="font-bold text-slate-700 dark:text-slate-200">5, 10, 25, 50 km</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Tile Pyramids:</span>
                <span className="font-bold text-slate-700 dark:text-slate-200">Zoom 11 – 15</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Offline Storage:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">IndexedDB</span>
              </div>
            </div>

            <div className="mt-6 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-[11px] text-amber-700 dark:text-amber-300">
              <strong>Tip for Remote Treks:</strong> Download using Wi-Fi at your hotel or base camp before entering the forest/mountain trails.
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
