import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Compass, Mail, Lock, ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await login(email, password);
      if (res.success) {
        navigate('/dashboard');
      } else {
        setError(res.message || 'Invalid credentials.');
      }
    } catch {
      setError('An error occurred during login. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoFill = () => {
    setEmail('priya@roamready.app');
    setPassword('password123');
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full bg-white dark:bg-roam-nightcard rounded-3xl p-8 shadow-float border border-roam-stone/80 dark:border-roam-nightborder transition-colors">
        
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-roam-green to-roam-teal text-white flex items-center justify-center mx-auto mb-3 shadow-soft">
            <Compass className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">Welcome Back</h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Access your downloaded regions and recorded GPS tracks
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs font-semibold">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="explorer@roamready.app"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:hover:bg-emerald-400 dark:text-roam-night font-bold text-sm shadow-md transition-all hover:scale-[1.01]"
            >
              <span>{loading ? 'Authenticating...' : 'Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* Demo Account Quick-Fill Button for Evaluators */}
        <div className="mt-4">
          <button
            type="button"
            onClick={handleDemoFill}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-roam-sand dark:bg-roam-night border border-dashed border-roam-green/40 dark:border-roam-mint/40 text-roam-green dark:text-roam-mint text-xs font-bold hover:bg-roam-green/5 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Fill Demo Tourist Account (Priya Sharma)</span>
          </button>
        </div>

        <div className="mt-6 text-center text-xs text-slate-500 dark:text-slate-400">
          Don't have an account?{' '}
          <Link to="/register" className="font-bold text-roam-green dark:text-roam-mint hover:underline">
            Register for free
          </Link>
        </div>

      </div>
    </div>
  );
}
