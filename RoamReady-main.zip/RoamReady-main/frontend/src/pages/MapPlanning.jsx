import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import L from 'leaflet';
import { 
  Compass, 
  MapPin, 
  DownloadCloud, 
  Database, 
  Layers, 
  Clock, 
  HardDrive, 
  CheckCircle2, 
  AlertCircle,
  ArrowRight
} from 'lucide-react';
import { DESTINATIONS_CATALOG } from '../data/mockDestinations';
import { estimateStorageSize } from '../utils/geo';
import { getStorageStats } from '../utils/storage';

export default function MapPlanning() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const destId = searchParams.get('id') || 'coorg-madikeri';
  const queryLat = searchParams.get('lat');
  const queryLon = searchParams.get('lon');
  const queryName = searchParams.get('name');
  const queryCategory = searchParams.get('category');
  const queryState = searchParams.get('state');
  const queryCountry = searchParams.get('country');

  const destination = useMemo(() => {
    if (queryLat !== null && queryLon !== null) {
      const lat = parseFloat(queryLat);
      const lon = parseFloat(queryLon);
      const name = queryName || 'Worldwide Location';
      return {
        id: destId && !destId.startsWith('coorg') ? destId : `loc_${Math.round(lat * 10000)}_${Math.round(lon * 10000)}`,
        name,
        regionName: queryState || queryCountry || name,
        state: queryState || '',
        country: queryCountry || 'Worldwide',
        latitude: lat,
        longitude: lon,
        category: queryCategory || 'other',
        difficulty: 'moderate',
        bestSeason: 'Year-round',
        bannerImage: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1000&q=80',
        description: `Geographic region surrounding ${name}. Selected via dynamic worldwide location search.`,
        pois: [
          {
            id: `poi_${Math.round(lat * 10000)}_${Math.round(lon * 10000)}`,
            name: `${name} (Center Point)`,
            category: queryCategory || 'viewpoints',
            latitude: lat,
            longitude: lon,
            description: `Primary focal landmark for ${name}`,
            offlineAvailable: true
          }
        ]
      };
    }
    return DESTINATIONS_CATALOG.find((d) => d.id === destId) || DESTINATIONS_CATALOG[0];
  }, [destId, queryLat, queryLon, queryName, queryCategory, queryState, queryCountry]);

  const [radiusKm, setRadiusKm] = useState(10);
  const [isCustomRadius, setIsCustomRadius] = useState(false);
  const [storageAudit, setStorageAudit] = useState(null);

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const circleLayerRef = useRef(null);

  const estimates = estimateStorageSize(radiusKm);
  const areaSqKm = Math.round(Math.PI * radiusKm * radiusKm);

  useEffect(() => {
    getStorageStats().then(setStorageAudit).catch(() => {});
  }, []);

  // Initialize interactive Leaflet planning preview map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [destination.latitude, destination.longitude],
        zoom: 12,
        zoomControl: true
      });

      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: '&copy; OpenStreetMap contributors'
      }).addTo(map);

      // Center marker
      const markerIcon = L.divIcon({
        className: 'custom-dest-pin',
        html: `
          <div style="background-color: #1E3A2F; color: white; width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.3); border: 2.5px solid white;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
          </div>
        `,
        iconSize: [34, 34],
        iconAnchor: [17, 34]
      });

      L.marker([destination.latitude, destination.longitude], { icon: markerIcon })
        .addTo(map)
        .bindPopup(`<strong>${destination.name}</strong><br/>Download Center Point`);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    map.setView([destination.latitude, destination.longitude]);

    // Redraw radius coverage circle
    if (circleLayerRef.current) {
      map.removeLayer(circleLayerRef.current);
    }

    const circle = L.circle([destination.latitude, destination.longitude], {
      radius: radiusKm * 1000,
      color: '#16a34a',
      fillColor: '#22c55e',
      fillOpacity: 0.18,
      weight: 2,
      dashArray: '6, 6'
    }).addTo(map);

    circleLayerRef.current = circle;
    map.fitBounds(circle.getBounds(), { padding: [25, 25] });

    return () => {
      // Clean up on component unmount
    };
  }, [destination, radiusKm]);

  const handleStartDownload = () => {
    navigate('/progress', {
      state: {
        destination,
        radiusKm,
        estimates
      }
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-20">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Map Download Planning
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Configure geographic boundary radius and inspect storage footprint before downloading.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Interactive Map Preview */}
        <div className="lg:col-span-7 bg-white dark:bg-roam-nightcard rounded-3xl overflow-hidden border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
          <div className="p-4 bg-roam-sand/60 dark:bg-roam-night border-b border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-roam-green dark:text-roam-mint" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Coverage Boundary Preview ({radiusKm} km radius)
              </span>
            </div>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400">
              ~{areaSqKm} km² Area
            </span>
          </div>

          <div ref={mapContainerRef} className="h-80 sm:h-[420px] w-full" />

          <div className="p-4 bg-white dark:bg-roam-nightcard text-xs text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>Dashed circle indicates exact cached geographic boundary.</span>
            <span>Center: {destination.latitude.toFixed(4)}, {destination.longitude.toFixed(4)}</span>
          </div>
        </div>

        {/* Right Column: Radius Options & Storage Estimates */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Radius Selector Card */}
          <div className="bg-white dark:bg-roam-nightcard p-6 rounded-3xl border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 mb-4">
              Select Download Radius
            </h3>

            {/* Standard Radius Preset Buttons */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              {[5, 10, 25, 50].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => {
                    setRadiusKm(preset);
                    setIsCustomRadius(false);
                  }}
                  className={`py-3 px-4 rounded-2xl text-left border transition-all ${
                    radiusKm === preset && !isCustomRadius
                      ? 'border-roam-green dark:border-roam-mint bg-roam-green/10 dark:bg-roam-mint/15 shadow-sm'
                      : 'border-roam-stone dark:border-roam-nightborder hover:bg-roam-sand dark:hover:bg-roam-night'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-base text-slate-900 dark:text-white">
                      {preset} km
                    </span>
                    {preset === 50 && (
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-amber-400">
                        Max
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block mt-0.5">
                    {preset <= 10 ? 'Local Trails' : 'Broad Highland Area'}
                  </span>
                </button>
              ))}
            </div>

            {/* Custom Radius Slider Toggle */}
            <div className="pt-2 border-t border-roam-stone/60 dark:border-roam-nightborder">
              <div className="flex items-center justify-between text-xs font-semibold mb-2">
                <span className="text-slate-600 dark:text-slate-300">Custom Radius (Max 50 km)</span>
                <span className="text-roam-green dark:text-roam-mint font-bold">{radiusKm} km</span>
              </div>
              <input
                type="range"
                min="3"
                max="50"
                step="1"
                value={radiusKm}
                onChange={(e) => {
                  setRadiusKm(parseInt(e.target.value, 10));
                  setIsCustomRadius(true);
                }}
                className="w-full h-2 bg-roam-stone dark:bg-roam-nightborder rounded-lg appearance-none cursor-pointer accent-roam-green dark:accent-roam-mint"
              />
            </div>
          </div>

          {/* Technical Specifications & Estimates */}
          <div className="bg-white dark:bg-roam-nightcard p-6 rounded-3xl border border-roam-stone/80 dark:border-roam-nightborder shadow-soft space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Download Specifications
            </h3>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-slate-400" />
                Map Detail / Zoom Levels
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                Zoom {estimates.minZoom} to {estimates.maxZoom}
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-slate-400" />
                Estimated Tile Count
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                ~{estimates.estimatedTiles} tiles
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-slate-400" />
                Estimated Storage Size
              </span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">
                ~{estimates.approxStorageMB} MB
              </span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                Est. Download Duration
              </span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                ~{estimates.downloadTimeSec} seconds
              </span>
            </div>

            <div className="flex items-center justify-between text-xs pt-2 border-t border-roam-stone/60 dark:border-roam-nightborder">
              <span className="text-slate-500 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                Bundled Tourist Sights
              </span>
              <span className="font-bold text-roam-green dark:text-roam-mint">
                {destination.pois.length} Sights Included
              </span>
            </div>

            {/* Storage Available Quota */}
            {storageAudit && (
              <div className="mt-3 pt-3 border-t border-roam-stone/60 dark:border-roam-nightborder text-[11px] text-slate-400">
                Device storage available: <strong className="text-slate-600 dark:text-slate-300">{storageAudit.quotaMB} MB</strong> (Currently used: {storageAudit.totalTileMB} MB)
              </div>
            )}
          </div>

          {/* Download Action Button */}
          <button
            type="button"
            onClick={handleStartDownload}
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:hover:bg-emerald-400 dark:text-roam-night font-bold text-base shadow-float hover:scale-[1.01] transition-all"
          >
            <DownloadCloud className="w-5 h-5" />
            <span>Download Offline Region</span>
            <ArrowRight className="w-4 h-4" />
          </button>

        </div>

      </div>

    </div>
  );
}
