import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  HardDrive, 
  Map, 
  Trash2, 
  RotateCw, 
  DownloadCloud, 
  CheckCircle2, 
  Layers, 
  AlertTriangle,
  Compass,
  ArrowRight,
  Database
} from 'lucide-react';
import { getAllDownloadedMaps, deleteDownloadedMap, deleteAllDownloadedMaps, getStorageStats } from '../utils/storage';
import ConfirmationModal from '../components/ConfirmationModal';
import { useAuth } from '../context/AuthContext';

export default function MapManagement() {
  const navigate = useNavigate();
  const { isOnline } = useAuth();

  const [maps, setMaps] = useState([]);
  const [stats, setStats] = useState(null);
  const [deleteTargetId, setDeleteTargetId] = useState(null);
  const [isDeleteAllOpen, setIsDeleteAllOpen] = useState(false);
  const [updatingRegionId, setUpdatingRegionId] = useState(null);

  const loadMapsAndStats = async () => {
    try {
      const allMaps = await getAllDownloadedMaps();
      setMaps(allMaps);
      const storageStats = await getStorageStats();
      setStats(storageStats);
    } catch (err) {
      console.warn('Error loading downloaded maps:', err);
    }
  };

  useEffect(() => {
    loadMapsAndStats();
  }, []);

  const handleDeleteOne = async () => {
    if (deleteTargetId) {
      await deleteDownloadedMap(deleteTargetId);
      setDeleteTargetId(null);
      loadMapsAndStats();
    }
  };

  const handleDeleteAll = async () => {
    await deleteAllDownloadedMaps();
    setIsDeleteAllOpen(false);
    loadMapsAndStats();
  };

  const handleUpdate = async (region) => {
    if (!isOnline) {
      alert('Updating map data requires an active internet connection.');
      return;
    }
    setUpdatingRegionId(region.id);
    setTimeout(() => {
      setUpdatingRegionId(null);
      loadMapsAndStats();
    }, 1800);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Downloaded Maps Management
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Inspect, manage, and free offline storage for cached geographical regions and POIs.
          </p>
        </div>

        {maps.length > 0 && (
          <button
            type="button"
            onClick={() => setIsDeleteAllOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition-colors shadow-sm self-start sm:self-auto"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete All Maps</span>
          </button>
        )}
      </div>

      {/* Storage Audit Overview Card */}
      {stats && (
        <div className="p-6 rounded-3xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-roam-green dark:text-roam-mint" />
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                IndexedDB Storage Footprint
              </h2>
            </div>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              {stats.totalTileMB} MB Cached
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
            <div className="p-3 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
              <span className="text-xs text-slate-400 font-medium block">Total Regions</span>
              <span className="text-xl font-black text-slate-800 dark:text-slate-100 mt-0.5 block">{stats.mapCount}</span>
            </div>

            <div className="p-3 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
              <span className="text-xs text-slate-400 font-medium block">Tile Blobs</span>
              <span className="text-xl font-black text-slate-800 dark:text-slate-100 mt-0.5 block">{stats.tileCount}</span>
            </div>

            <div className="p-3 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
              <span className="text-xs text-slate-400 font-medium block">Cached POIs</span>
              <span className="text-xl font-black text-slate-800 dark:text-slate-100 mt-0.5 block">{stats.poiCount}</span>
            </div>

            <div className="p-3 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
              <span className="text-xs text-slate-400 font-medium block">Available Quota</span>
              <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 mt-0.5 block">{stats.quotaMB} MB</span>
            </div>
          </div>
        </div>
      )}

      {/* Downloaded Regions List */}
      {maps.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-roam-nightcard rounded-3xl border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <HardDrive className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">No offline map regions downloaded</h3>
          <p className="mt-1 text-xs text-slate-500">
            Search a destination and choose a 5–50 km radius to save map tiles for offline use.
          </p>
          <Link
            to="/search"
            className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night font-bold text-xs shadow-md"
          >
            <span>Browse Destinations</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {maps.map((mapItem) => {
            const dateStr = new Date(mapItem.downloadedAt).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric'
            });

            return (
              <div
                key={mapItem.id}
                className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft hover:shadow-float transition-all flex flex-col md:flex-row md:items-center justify-between gap-5"
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint text-[11px] font-bold">
                      {mapItem.radiusKm} km Radius
                    </span>
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-500 font-medium">
                      Downloaded on {dateStr}
                    </span>
                  </div>

                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                    {mapItem.regionName}
                  </h3>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400 pt-1">
                    <span>
                      Storage: <strong className="text-emerald-600 dark:text-emerald-400">{mapItem.storageMB || '2.40'} MB</strong>
                    </span>
                    <span>
                      Tiles: <strong className="text-slate-700 dark:text-slate-200">{mapItem.tileCount}</strong>
                    </span>
                    <span>
                      Sights: <strong className="text-slate-700 dark:text-slate-200">{mapItem.poiCount || 6} POIs</strong>
                    </span>
                    <span>
                      Center: {mapItem.centerLat?.toFixed(4)}, {mapItem.centerLon?.toFixed(4)}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2.5 pt-3 md:pt-0 border-t md:border-t-0 border-roam-stone/60 dark:border-roam-nightborder">
                  <Link
                    to={`/map?regionId=${mapItem.id}`}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90 transition-opacity"
                  >
                    <Map className="w-3.5 h-3.5" />
                    <span>Open Map</span>
                  </Link>

                  <button
                    type="button"
                    onClick={() => handleUpdate(mapItem)}
                    disabled={updatingRegionId === mapItem.id}
                    title="Update POIs & tiles when online"
                    className="p-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder text-slate-600 dark:text-slate-300 hover:bg-roam-sand dark:hover:bg-roam-night transition-colors"
                  >
                    <RotateCw className={`w-4 h-4 ${updatingRegionId === mapItem.id ? 'animate-spin text-roam-green' : ''}`} />
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteTargetId(mapItem.id)}
                    className="p-2.5 rounded-xl text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Delete downloaded map region"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Confirmation Modal for Single Map Delete */}
      <ConfirmationModal
        isOpen={!!deleteTargetId}
        title="Delete Downloaded Map Region?"
        message="Are you sure you want to delete this map region? All associated vector/raster tile blobs and cached POIs will be permanently deleted from IndexedDB."
        confirmText="Delete Region"
        onConfirm={handleDeleteOne}
        onClose={() => setDeleteTargetId(null)}
      />

      {/* Confirmation Modal for Delete All */}
      <ConfirmationModal
        isOpen={isDeleteAllOpen}
        title="Delete All Downloaded Maps?"
        message="Are you sure you want to delete ALL downloaded map regions? All offline map access will be removed until re-downloaded."
        confirmText="Delete All"
        onConfirm={handleDeleteAll}
        onClose={() => setIsDeleteAllOpen(false)}
      />

    </div>
  );
}
