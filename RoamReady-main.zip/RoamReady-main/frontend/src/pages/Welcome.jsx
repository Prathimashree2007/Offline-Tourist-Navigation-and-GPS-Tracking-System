import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Compass, 
  Map, 
  Navigation, 
  MapPin, 
  WifiOff, 
  ShieldCheck, 
  DownloadCloud, 
  Footprints, 
  ArrowRight,
  CheckCircle2,
  Users
} from 'lucide-react';

export default function Welcome() {
  return (
    <div className="min-h-screen bg-roam-sand dark:bg-roam-night transition-colors pb-16">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
        <div className="absolute inset-0 opacity-10 dark:opacity-5 pointer-events-none bg-[radial-gradient(#1E3A2F_1px,transparent_1px)] [background-size:20px_20px]" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-3xl mx-auto">
            
            {/* Academic Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-roam-green/10 dark:bg-roam-mint/15 border border-roam-green/20 dark:border-roam-mint/30 text-roam-green dark:text-roam-mint text-xs font-bold tracking-wide uppercase mb-6 shadow-sm">
              <Users className="w-4 h-4" />
              ISE Mini-Project • 4-Member Team Engineering Showcase
            </div>

            <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15]">
              Explore freely. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-roam-green via-roam-teal to-roam-mint dark:from-roam-mint dark:to-emerald-400">
                Navigate anywhere.
              </span>
            </h1>

            <p className="mt-6 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
              Remote waterfalls, dense forest ridges, secluded beaches and highland trails often have zero mobile signal.
              <strong className="text-roam-green dark:text-roam-mint font-semibold"> RoamReady </strong> 
              pre-caches bounded geographical map regions, offline tourist POIs, and records continuous GPS trails completely offline.
            </p>

            {/* Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/dashboard"
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:hover:bg-emerald-400 dark:text-roam-night font-bold text-base shadow-float hover:scale-[1.02] transition-all"
              >
                <span>Launch Explorer Dashboard</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
              
              <Link
                to="/map"
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-7 py-3.5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-slate-800 dark:text-slate-100 hover:bg-roam-sand dark:hover:bg-roam-night font-bold text-base shadow-soft transition-all"
              >
                <Map className="w-5 h-5 text-roam-green dark:text-roam-mint" />
                <span>Open Offline Map</span>
              </Link>
            </div>

            {/* Core Metrics Quick Strip */}
            <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8 border-t border-roam-stone dark:border-roam-nightborder">
              <div className="p-3 bg-white/70 dark:bg-roam-nightcard/60 rounded-xl border border-roam-stone/50 dark:border-roam-nightborder">
                <div className="text-2xl font-black text-roam-green dark:text-roam-mint">50 km</div>
                <div className="text-xs text-slate-500 font-medium">Max Offline Radius</div>
              </div>
              <div className="p-3 bg-white/70 dark:bg-roam-nightcard/60 rounded-xl border border-roam-stone/50 dark:border-roam-nightborder">
                <div className="text-2xl font-black text-roam-teal dark:text-teal-400">0 KB</div>
                <div className="text-xs text-slate-500 font-medium">Data Needed On Trail</div>
              </div>
              <div className="p-3 bg-white/70 dark:bg-roam-nightcard/60 rounded-xl border border-roam-stone/50 dark:border-roam-nightborder">
                <div className="text-2xl font-black text-roam-terracotta">Haversine</div>
                <div className="text-xs text-slate-500 font-medium">Accurate Distance Math</div>
              </div>
              <div className="p-3 bg-white/70 dark:bg-roam-nightcard/60 rounded-xl border border-roam-stone/50 dark:border-roam-nightborder">
                <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">100%</div>
                <div className="text-xs text-slate-500 font-medium">Legal Offline Tiles</div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Feature Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Engineered For Wilderness Reliability
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-400">
            A comprehensive, modular offline navigation architecture built for academic excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          
          {/* Card 1 */}
          <div className="p-7 rounded-3xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder shadow-soft hover:shadow-float transition-all">
            <div className="w-12 h-12 rounded-2xl bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint flex items-center justify-center mb-5">
              <DownloadCloud className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Bounded Map Downloads</h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Select any destination and choose a 5 km, 10 km, 25 km, or 50 km coverage radius. Tiles are saved into persistent IndexedDB storage without illegal bulk scraping.
            </p>
            <ul className="mt-4 space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                Adaptive zoom pyramids (11 to 15)
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                Accurate storage & tile count estimates
              </li>
            </ul>
          </div>

          {/* Card 2 */}
          <div className="p-7 rounded-3xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder shadow-soft hover:shadow-float transition-all">
            <div className="w-12 h-12 rounded-2xl bg-roam-teal/10 text-roam-teal dark:bg-teal-500/20 dark:text-teal-400 flex items-center justify-center mb-5">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Offline POI Discovery</h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Discover nearby waterfalls, viewpoints, peaks, beaches, and emergency clinics offline. Categorized and sorted by real-time straight-line Haversine distance.
            </p>
            <ul className="mt-4 space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                Filtered by category (waterfalls, hills, viewpoints)
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                Offline emergency & hospital phone contacts
              </li>
            </ul>
          </div>

          {/* Card 3 */}
          <div className="p-7 rounded-3xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder shadow-soft hover:shadow-float transition-all">
            <div className="w-12 h-12 rounded-2xl bg-roam-terracotta/10 text-roam-terracotta dark:bg-orange-500/20 dark:text-orange-400 flex items-center justify-center mb-5">
              <Footprints className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">GPS Trail Recording</h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              Continuous high-accuracy GPS tracking with noise filtering, pause/resume, live polyline rendering, and automatic trip summary calculation.
            </p>
            <ul className="mt-4 space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                Distance, duration & average speed statistics
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                Classroom Demo Mode for indoor lab viva
              </li>
            </ul>
          </div>

        </div>
      </section>

      {/* Pre-packaged Tour Demo Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="p-8 rounded-3xl bg-gradient-to-r from-roam-green via-roam-lightgreen to-roam-teal text-white shadow-xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl">
            <span className="px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider">
              Ready for Academic Evaluation
            </span>
            <h3 className="text-2xl sm:text-3xl font-extrabold mt-3">
              Pre-Bundled Western Ghats & Coastal Regions
            </h3>
            <p className="mt-2 text-white/90 text-sm leading-relaxed">
              For seamless college demonstration even inside Wi-Fi shielded seminar halls, explore pre-bundled datasets for Coorg (Abbey Falls & Raja Seat), Chikmagalur (Mullayanagiri Peak), Gokarna Beach Trail, Ooty Nilgiris, and Wayanad.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                to="/search"
                className="px-5 py-2.5 rounded-xl bg-white text-roam-green font-bold text-sm hover:bg-roam-sand transition-colors shadow-sm"
              >
                Browse Curated Destinations
              </Link>
              <Link
                to="/tracking"
                className="px-5 py-2.5 rounded-xl bg-black/30 hover:bg-black/40 text-white font-semibold text-sm transition-colors border border-white/20"
              >
                Test GPS Trail Simulator
              </Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
