import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import L from 'leaflet';
import { 
  ArrowLeft, 
  MapPin, 
  Clock, 
  TrendingUp, 
  Gauge, 
  Footprints, 
  Download, 
  Trash2, 
  Calendar,
  Share2,
  CheckCircle2
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { getTripById, deleteTrip } from '../utils/storage';
import { formatDistance } from '../utils/geo';
import ConfirmationModal from '../components/ConfirmationModal';

export default function TripDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { distanceUnit } = useTheme();

  const [trip, setTrip] = useState(null);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [exportedNotice, setExportedNotice] = useState(false);

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);

  useEffect(() => {
    async function load() {
      const data = await getTripById(id);
      if (data) {
        setTrip(data);
      } else {
        navigate('/history');
      }
    }
    load();
  }, [id, navigate]);

  // Render Full Route on Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current || !trip || !trip.points || trip.points.length === 0) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [trip.startLat, trip.startLon],
        zoom: 14,
        zoomControl: true
      });

      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    const latLngs = trip.points.map(p => [p.latitude, p.longitude]);

    // Draw route polyline
    const polyline = L.polyline(latLngs, {
      color: '#15803d',
      weight: 5,
      opacity: 0.9,
      lineCap: 'round',
      lineJoin: 'round'
    }).addTo(map);

    // Start Pin (Green)
    const startIcon = L.divIcon({
      className: 'start-pin',
      html: `
        <div style="background-color: #16a34a; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; border: 2.5px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
          A
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });
    L.marker([trip.startLat, trip.startLon], { icon: startIcon })
      .addTo(map)
      .bindPopup('<strong>Start Point</strong>');

    // End Pin (Red)
    const endIcon = L.divIcon({
      className: 'end-pin',
      html: `
        <div style="background-color: #e11d48; color: white; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; border: 2.5px solid white; box-shadow: 0 4px 10px rgba(0,0,0,0.3);">
          B
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });
    L.marker([trip.endLat, trip.endLon], { icon: endIcon })
      .addTo(map)
      .bindPopup('<strong>Finish Point</strong>');

    map.fitBounds(polyline.getBounds(), { padding: [40, 40] });

  }, [trip]);

  const handleDelete = async () => {
    if (trip) {
      await deleteTrip(trip.id);
      navigate('/history');
    }
  };

  // GPX is the standard track format for Google Earth, Garmin, AllTrails, etc.
  const handleExportGpx = () => {
    if (!trip || !trip.points) return;
    const esc = (t) => String(t).replace(/[<>&"']/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));
    const pts = trip.points
      .map((p) => {
        const time = p.timestamp ? `<time>${new Date(p.timestamp).toISOString()}</time>` : '';
        return `      <trkpt lat="${p.latitude}" lon="${p.longitude}"><ele>${p.altitude || 0}</ele>${time}</trkpt>`;
      })
      .join('\n');
    const gpx = `<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="RoamReady" xmlns="http://www.topografix.com/GPX/1/1">
  <trk>
    <name>${esc(trip.name)}</name>
    <trkseg>
${pts}
    </trkseg>
  </trk>
</gpx>`;
    const blob = new Blob([gpx], { type: 'application/gpx+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${trip.name.toLowerCase().replace(/\s+/g, '_')}_trail.gpx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setExportedNotice(true);
    setTimeout(() => setExportedNotice(false), 4000);
  };

  const handleExportGeoJson = () => {
    if (!trip || !trip.points) return;
    const geojson = {
      type: 'FeatureCollection',
      features: [
        {
          type: 'Feature',
          properties: {
            name: trip.name,
            distanceKm: trip.distanceKm,
            durationSeconds: trip.durationSeconds,
            startedAt: trip.startedAt,
            endedAt: trip.endedAt
          },
          geometry: {
            type: 'LineString',
            coordinates: trip.points.map(p => [p.longitude, p.latitude, p.altitude || 0])
          }
        }
      ]
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(geojson, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${trip.name.toLowerCase().replace(/\s+/g, '_')}_trail.geojson`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    setExportedNotice(true);
    setTimeout(() => setExportedNotice(false), 4000);
  };

  if (!trip) return null;

  const dateFormatted = new Date(trip.startedAt).toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const minutes = Math.max(1, Math.round(trip.durationSeconds / 60));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 pb-24">
      
      {/* Top Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/history')}
          className="inline-flex items-center gap-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:text-roam-green dark:hover:text-roam-mint transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Travel History</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportGeoJson}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-roam-sand dark:hover:bg-roam-night shadow-soft"
          >
            <Download className="w-3.5 h-3.5 text-roam-green dark:text-roam-mint" />
            <span>Export GeoJSON</span>
          </button>

          <button
            type="button"
            onClick={handleExportGpx}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-roam-sand dark:hover:bg-roam-night shadow-soft"
          >
            <Download className="w-3.5 h-3.5 text-roam-green dark:text-roam-mint" />
            <span>Export GPX</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDeleteOpen(true)}
            className="p-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-transparent hover:border-rose-200"
            title="Delete this journey"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {exportedNotice && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2 animate-slide-down">
          <CheckCircle2 className="w-4 h-4" />
          <span>Trail exported successfully as standard GIS GeoJSON format!</span>
        </div>
      )}

      {/* Trip Header Banner */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 sm:p-8 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
        <div className="flex items-center gap-2 mb-2">
          <span className="px-3 py-1 rounded-full bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint text-xs font-bold">
            {dateFormatted}
          </span>
          {trip.isDemo && (
            <span className="px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-600 text-xs font-bold">
              Classroom Demo
            </span>
          )}
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white">
          {trip.name}
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          Destination: {trip.destinationName || 'Scenic Trek'}
        </p>

        {/* Core Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-roam-stone/60 dark:border-roam-nightborder">
          <div>
            <span className="text-xs text-slate-400 font-medium block">Total Distance</span>
            <span className="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-0.5 block">
              {formatDistance(trip.distanceKm, distanceUnit)}
            </span>
          </div>

          <div>
            <span className="text-xs text-slate-400 font-medium block">Duration</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-0.5 block">
              {minutes} mins
            </span>
          </div>

          <div>
            <span className="text-xs text-slate-400 font-medium block">Average Speed</span>
            <span className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-0.5 block">
              {trip.avgSpeedKmh || 4.8} km/h
            </span>
          </div>

          <div>
            <span className="text-xs text-slate-400 font-medium block">Track Waypoints</span>
            <span className="text-xl sm:text-2xl font-black text-roam-terracotta mt-0.5 block">
              {trip.pointCount || trip.points?.length || 0}
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Map Visualizer */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl overflow-hidden border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
        <div className="p-4 bg-roam-sand/60 dark:bg-roam-night border-b border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
          <span>Traveled Route Map</span>
          <span className="text-slate-400 font-normal">
            Start A ({trip.startLat?.toFixed(4)}, {trip.startLon?.toFixed(4)}) → Finish B ({trip.endLat?.toFixed(4)}, {trip.endLon?.toFixed(4)})
          </span>
        </div>

        <div ref={mapContainerRef} className="h-80 sm:h-[450px] w-full" />
      </div>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={isDeleteOpen}
        title="Delete Trip Permanently?"
        message="Are you sure you want to remove this journey record and all its GPS track waypoints from IndexedDB?"
        confirmText="Delete Trip"
        onConfirm={handleDelete}
        onClose={() => setIsDeleteOpen(false)}
      />

    </div>
  );
}
