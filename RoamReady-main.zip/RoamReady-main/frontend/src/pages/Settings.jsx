import React, { useState } from 'react';
import { 
  Sun, 
  Moon, 
  Globe, 
  Compass, 
  Database, 
  Trash2, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle 
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import ConfirmationModal from '../components/ConfirmationModal';

export default function Settings() {
  const { isDarkMode, toggleDarkMode, distanceUnit, setDistanceUnit } = useTheme();

  const [gpsAccuracyThreshold, setGpsAccuracyThreshold] = useState(25);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  const handleResetStorage = () => {
    localStorage.clear();
    indexedDB.deleteDatabase('roamready_local_db');
    setResetSuccess(true);
    setTimeout(() => {
      window.location.reload();
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 pb-24">
      
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          Application Settings & Preferences
        </h1>
        <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          Customize display units, GPS sensitivity filters, and offline storage options.
        </p>
      </div>

      {resetSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2 animate-slide-down">
          <CheckCircle2 className="w-4 h-4" />
          <span>Local storage cleared. Reloading application shell...</span>
        </div>
      )}

      {/* Preferences Card */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 sm:p-8 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft space-y-6">
        
        {/* Dark Mode */}
        <div className="flex items-center justify-between pb-6 border-b border-roam-stone/60 dark:border-roam-nightborder">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Visual Appearance
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Switch between Light Mode and Dark Forest Mode
            </p>
          </div>

          <button
            onClick={toggleDarkMode}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-roam-sand dark:bg-roam-night border border-roam-stone dark:border-roam-nightborder text-xs font-bold text-slate-800 dark:text-slate-200 hover:scale-105 transition-transform"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            <span>{isDarkMode ? 'Dark Mode' : 'Light Mode'}</span>
          </button>
        </div>

        {/* Distance Unit */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-roam-stone/60 dark:border-roam-nightborder">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Distance Units
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Affects Haversine distance calculations and trip statistics
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setDistanceUnit('km')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                distanceUnit === 'km'
                  ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm'
                  : 'bg-roam-sand dark:bg-roam-night text-slate-600 dark:text-slate-300'
              }`}
            >
              Kilometers (km)
            </button>
            <button
              onClick={() => setDistanceUnit('miles')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                distanceUnit === 'miles'
                  ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm'
                  : 'bg-roam-sand dark:bg-roam-night text-slate-600 dark:text-slate-300'
              }`}
            >
              Miles (mi)
            </button>
          </div>
        </div>

        {/* GPS Accuracy Noise Filter Slider */}
        <div className="pb-6 border-b border-roam-stone/60 dark:border-roam-nightborder">
          <div className="flex items-center justify-between mb-2">
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                GPS Accuracy Threshold Filter
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Discard GPS waypoints with location uncertainty greater than this value
              </p>
            </div>
            <span className="font-black text-xs text-roam-green dark:text-roam-mint">
              ±{gpsAccuracyThreshold} meters
            </span>
          </div>

          <input
            type="range"
            min="5"
            max="60"
            step="5"
            value={gpsAccuracyThreshold}
            onChange={(e) => setGpsAccuracyThreshold(parseInt(e.target.value, 10))}
            className="w-full h-2 bg-roam-stone dark:bg-roam-nightborder rounded-lg appearance-none cursor-pointer accent-roam-green dark:accent-roam-mint"
          />
        </div>

        {/* Service Worker PWA Status */}
        <div className="flex items-center justify-between pb-6 border-b border-roam-stone/60 dark:border-roam-nightborder">
          <div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Service Worker & Offline Shell
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Caches static app shell, icons, fonts, and styles for true offline launch
            </p>
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-xs font-bold">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Registered (sw.js)
          </span>
        </div>

        {/* Danger Zone: Storage Reset */}
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-base text-rose-600 dark:text-rose-400">
              Clear All Local Data & Reset
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Deletes all local IndexedDB tables, cached map tiles, and session tokens
            </p>
          </div>

          <button
            onClick={() => setResetConfirmOpen(true)}
            className="px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition-colors"
          >
            Reset App Data
          </button>
        </div>

      </div>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={resetConfirmOpen}
        title="Reset All Local App Storage?"
        message="This will completely wipe your local IndexedDB database (downloaded map tiles, POIs, travel history) and reset settings. Proceed?"
        confirmText="Confirm Reset"
        onConfirm={handleResetStorage}
        onClose={() => setResetConfirmOpen(false)}
      />

    </div>
  );
}
