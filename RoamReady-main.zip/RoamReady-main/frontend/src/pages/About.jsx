import React from 'react';
import { 
  Compass, 
  Users, 
  BookOpen, 
  Cpu, 
  Database, 
  MapPin, 
  ShieldCheck, 
  Award, 
  Layers, 
  CheckCircle2,
  FileText
} from 'lucide-react';

export default function About() {
  const teamMembers = [
    { name: 'Student 1 (Team Lead)', role: 'Full-Stack Architecture & Offline Engine', branch: 'Information Science & Engineering' },
    { name: 'Student 2', role: 'GIS Engineering, Leaflet & Tile Pyramids', branch: 'Information Science & Engineering' },
    { name: 'Student 3', role: 'GPS Trail Tracker & Haversine Math', branch: 'Information Science & Engineering' },
    { name: 'Student 4', role: 'UI/UX Design, REST API & MySQL Integration', branch: 'Information Science & Engineering' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 pb-24">
      
      {/* Project Academic Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-roam-green/10 dark:bg-roam-mint/15 border border-roam-green/20 dark:border-roam-mint/30 text-roam-green dark:text-roam-mint text-xs font-bold uppercase tracking-wider shadow-sm">
          <Award className="w-4 h-4" />
          Academic Mini-Project Evaluation Specification
        </div>

        <h1 className="text-3xl sm:text-5xl font-black text-slate-900 dark:text-white tracking-tight">
          RoamReady
        </h1>
        <p className="text-base sm:text-lg text-roam-teal dark:text-roam-mint font-semibold">
          Offline Tourist Navigation & GPS Trail Companion
        </p>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-2xl mx-auto">
          Department of Information Science and Engineering • Developed by a 4-Member Student Team
        </p>
      </div>

      {/* Team Credits Grid */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 sm:p-8 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
        <div className="flex items-center gap-2 mb-6">
          <Users className="w-5 h-5 text-roam-green dark:text-roam-mint" />
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
            Project Development Team (4 ISE Students)
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {teamMembers.map((member, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-roam-sand/50 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder"
            >
              <div className="text-xs font-bold text-roam-green dark:text-roam-mint">
                Member 0{idx + 1}
              </div>
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-white mt-0.5">
                {member.name}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-medium mt-1">
                {member.role}
              </p>
              <span className="text-[11px] text-slate-400 block mt-1">
                {member.branch}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Methodology & Mathematical Foundations */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 sm:p-8 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft space-y-6">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-roam-teal dark:text-roam-mint" />
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
            Technical Methodology & Mathematical Principles
          </h2>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          <div>
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1">
              1. Haversine Great-Circle Distance Algorithm
            </h3>
            <p>
              To accurately compute straight-line proximity between the user’s live GPS fix $(\phi_1, \lambda_1)$ and offline tourist attractions $(\phi_2, \lambda_2)$ on a spherical Earth of radius $R = 6,371 \text{ km}$:
            </p>
            <div className="my-2 p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-xs overflow-x-auto">
              a = sin²(Δφ/2) + cos(φ1) · cos(φ2) · sin²(Δλ/2)<br/>
              c = 2 · atan2(√a, √(1−a))<br/>
              distance = R · c
            </div>
            <p className="text-slate-500 text-xs">
              This calculation executes completely in-memory on the client without invoking remote APIs.
            </p>
          </div>

          <div className="pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1">
              2. Slippy Map Tile Pyramid Bounding Math
            </h3>
            <p>
              Given a central destination coordinate and selected radius (5 km, 10 km, 25 km, or 50 km), the system projects the geographic bounding box into OpenStreetMap Web Mercator (EPSG:3857) tile coordinates $(X, Y)$ across discrete zoom levels (11 to 15):
            </p>
            <div className="my-2 p-3 rounded-xl bg-slate-900 text-emerald-400 font-mono text-xs overflow-x-auto">
              x = floor((lon + 180) / 360 * 2^zoom)<br/>
              y = floor((1 - ln(tan(lat*π/180) + sec(lat*π/180)) / π) / 2 * 2^zoom)
            </div>
          </div>

          <div className="pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-1">
              3. True Offline Storage Architecture
            </h3>
            <p>
              Map tile image blobs are saved inside the browser’s persistent <strong>IndexedDB</strong> under the store <code>map_tiles</code>. The custom Leaflet <code>OfflineTileLayer</code> intercepts every tile request and resolves the blob locally via <code>URL.createObjectURL(blob)</code>. If outside the downloaded coverage boundary circle, an explicit SVG warning tile is rendered—eliminating fake online illusions.
            </p>
          </div>
        </div>
      </div>

      {/* Viva / Evaluation Questions & Answers Guide */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 sm:p-8 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <BookOpen className="w-5 h-5 text-roam-green dark:text-roam-mint" />
          <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
            Academic Viva Examination Guide
          </h2>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          <div className="p-4 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
            <strong className="text-slate-900 dark:text-white block font-bold mb-1">
              Q1: How does GPS work on a smartphone when mobile internet/cellular data is completely turned off?
            </strong>
            <p className="text-slate-600 dark:text-slate-300 text-xs">
              <strong>Answer:</strong> GPS (Global Positioning System) receives radio signals directly from orbital satellites (L-band radio frequencies). It does not require cellular network or internet to calculate geographic latitude and longitude. The browser's <code>navigator.geolocation</code> API interfaces directly with the hardware GNSS receiver.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
            <strong className="text-slate-900 dark:text-white block font-bold mb-1">
              Q2: Why use IndexedDB instead of localStorage or CacheStorage for map tiles?
            </strong>
            <p className="text-slate-600 dark:text-slate-300 text-xs">
              <strong>Answer:</strong> <code>localStorage</code> is limited to 5 MB of synchronous string data, making it unsuitable for hundreds of map tile images. <code>IndexedDB</code> is an asynchronous NoSQL transactional database that natively supports binary <code>Blob</code> objects with hundreds of megabytes of storage quota.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-roam-sand/40 dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder">
            <strong className="text-slate-900 dark:text-white block font-bold mb-1">
              Q3: How does the application avoid illegal tile scraping?
            </strong>
            <p className="text-slate-600 dark:text-slate-300 text-xs">
              <strong>Answer:</strong> Bulk recursive spider scrapers violate tile server acceptable use policies. RoamReady calculates a bounded mathematical bounding box for the user-selected radius (5–50 km), rate-limits parallel requests with chunked concurrency, and enforces strict zoom caps (up to zoom 15) to maintain compliance and respectful bandwidth consumption.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
}
