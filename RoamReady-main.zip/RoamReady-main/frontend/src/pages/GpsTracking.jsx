import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import L from 'leaflet';
import { 
  Play, 
  Pause, 
  Square, 
  Navigation, 
  MapPin, 
  Clock, 
  TrendingUp, 
  Gauge, 
  Compass, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle,
  Layers,
  ArrowRight
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { gpsTracker } from '../utils/gpsTracker';
import { formatDistance } from '../utils/geo';

export default function GpsTracking() {
  const navigate = useNavigate();
  const { distanceUnit } = useTheme();

  const [tripName, setTripName] = useState('Western Ghats Trail');
  const [destinationName, setDestinationName] = useState('Abbey Falls Scenic Route');
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [isLowPower, setIsLowPower] = useState(false);

  const [trackingState, setTrackingState] = useState({
    isTracking: false,
    isPaused: false,
    pointCount: 0,
    currentLocation: null
  });

  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [distanceKm, setDistanceKm] = useState(0);
  const [currentSpeedKmh, setCurrentSpeedKmh] = useState(0);
  const [errorMessage, setErrorMessage] = useState(null);
  const [finishedTrip, setFinishedTrip] = useState(null);

  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const polylineRef = useRef(null);
  const currentMarkerRef = useRef(null);
  const timerRef = useRef(null);

  // Initialize mini tracking preview map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [12.4244, 75.7382],
        zoom: 14,
        zoomControl: false
      });

      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap'
      }).addTo(map);

      polylineRef.current = L.polyline([], {
        color: '#16a34a',
        weight: 4.5,
        opacity: 0.85,
        smoothFactor: 1
      }).addTo(map);

      mapInstanceRef.current = map;
    }
  }, []);

  // Timer counter for duration
  useEffect(() => {
    if (trackingState.isTracking && !trackingState.isPaused) {
      timerRef.current = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [trackingState.isTracking, trackingState.isPaused]);

  const handleStart = () => {
    setErrorMessage(null);
    setFinishedTrip(null);
    setElapsedSeconds(0);
    setDistanceKm(0);

    gpsTracker.startTracking({
      tripName,
      destinationName,
      useDemo: isDemoMode,
      lowPower: isLowPower,
      demoStartCoords: [12.4244, 75.7382],
      onPoint: (point, allPoints) => {
        setCurrentSpeedKmh(point.speed || 4.5);

        // Update map polyline
        if (mapInstanceRef.current && polylineRef.current) {
          const latLngs = allPoints.map(p => [p.latitude, p.longitude]);
          polylineRef.current.setLatLngs(latLngs);

          // Update current location dot
          if (currentMarkerRef.current) {
            mapInstanceRef.current.removeLayer(currentMarkerRef.current);
          }

          const markerIcon = L.divIcon({
            className: 'tracking-radar-dot',
            html: `
              <div style="position: relative; width: 16px; height: 16px;">
                <div class="gps-pulse-ring"></div>
                <div class="gps-pulse-dot"></div>
              </div>
            `,
            iconSize: [16, 16],
            iconAnchor: [8, 8]
          });

          currentMarkerRef.current = L.marker([point.latitude, point.longitude], { icon: markerIcon })
            .addTo(mapInstanceRef.current);

          mapInstanceRef.current.panTo([point.latitude, point.longitude]);
        }
      },
      onStatusChange: (status) => {
        setTrackingState(status);
      },
      onError: (err) => {
        setErrorMessage(err);
      }
    });
  };

  const handlePause = () => {
    gpsTracker.pauseTracking();
  };

  const handleResume = () => {
    gpsTracker.resumeTracking();
  };

  const handleStop = async () => {
    const savedTrip = await gpsTracker.stopTracking();
    if (savedTrip) {
      setFinishedTrip(savedTrip);
    }
  };

  // Format HH:MM:SS
  const formatDuration = (totalSec) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-24">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Live GPS Trail Recorder
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Records your traveled path point-by-point, calculates distance, duration, and persists trails in IndexedDB.
          </p>
        </div>

        {/* Demo Mode Toggle for Classroom Viva */}
        <div className="flex items-center gap-2 p-2 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder shadow-soft">
          <Sparkles className="w-4 h-4 text-amber-500 ml-1" />
          <span className="text-xs font-bold text-slate-700 dark:text-slate-200">
            Demo Simulator Mode:
          </span>
          <button
            type="button"
            disabled={trackingState.isTracking}
            onClick={() => setIsDemoMode(!isDemoMode)}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors ${
              isDemoMode
                ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night'
                : 'bg-roam-sand dark:bg-roam-night text-slate-600 dark:text-slate-400'
            }`}
          >
            {isDemoMode ? 'Enabled (Viva)' : 'Disabled (Real)'}
          </button>
        </div>

        {/* Battery saver for long treks */}
        <div className="flex items-center gap-2 p-2 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder shadow-soft">
          <span className="text-xs font-bold text-slate-700 dark:text-slate-200 ml-1">
            Battery saver:
          </span>
          <button
            type="button"
            disabled={trackingState.isTracking}
            onClick={() => setIsLowPower(!isLowPower)}
            className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors ${
              isLowPower
                ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night'
                : 'bg-roam-sand dark:bg-roam-night text-slate-600 dark:text-slate-400'
            }`}
          >
            {isLowPower ? 'On (point every 15 s)' : 'Off'}
          </button>
        </div>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs font-bold text-rose-600 dark:text-rose-400 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Finished Trip Success Notification */}
      {finishedTrip && (
        <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-float animate-slide-down flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg">Trail Successfully Saved!</h3>
              <p className="text-xs text-white/90">
                {finishedTrip.name} • {finishedTrip.distanceKm} km in {Math.round(finishedTrip.durationSeconds / 60)} min ({finishedTrip.pointCount} GPS waypoints)
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate(`/trip/${finishedTrip.id}`)}
            className="px-5 py-2.5 rounded-xl bg-white text-emerald-800 font-bold text-xs shadow-md hover:bg-roam-sand transition-colors flex items-center gap-1.5"
          >
            <span>View Route Details</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Grid: Live Metrics & Interactive Track Map */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Live Stats & Action Controls */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Trip Name & Inputs */}
          {!trackingState.isTracking && (
            <div className="p-6 rounded-3xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder shadow-soft space-y-4">
              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
                  Trip Name
                </label>
                <input
                  type="text"
                  value={tripName}
                  onChange={(e) => setTripName(e.target.value)}
                  placeholder="e.g. Abbey Falls Trek"
                  className="w-full px-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green"
                />
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
                  Destination / Landmark
                </label>
                <input
                  type="text"
                  value={destinationName}
                  onChange={(e) => setDestinationName(e.target.value)}
                  placeholder="e.g. Madikeri Western Ghats"
                  className="w-full px-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-xs sm:text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green"
                />
              </div>
            </div>
          )}

          {/* Real-time Dashboard Cards */}
          <div className="grid grid-cols-2 gap-4">
            
            <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                Duration
              </div>
              <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white font-mono">
                {formatDuration(elapsedSeconds)}
              </div>
              <div className="mt-1 text-[11px] text-slate-400">Elapsed time</div>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase text-slate-400">
                <TrendingUp className="w-3.5 h-3.5" />
                Distance
              </div>
              <div className="mt-2 text-2xl font-black text-emerald-600 dark:text-emerald-400">
                {trackingState.pointCount > 0
                  ? formatDistance((trackingState.pointCount * 0.08), distanceUnit)
                  : '--'}
              </div>
              <div className="mt-1 text-[11px] text-slate-400">Haversine calculation</div>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase text-slate-400">
                <Gauge className="w-3.5 h-3.5" />
                Speed
              </div>
              <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white">
                {currentSpeedKmh.toFixed(1)} <span className="text-xs font-normal text-slate-400">km/h</span>
              </div>
              <div className="mt-1 text-[11px] text-slate-400">Instant pace</div>
            </div>

            <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase text-slate-400">
                <Navigation className="w-3.5 h-3.5" />
                Waypoints
              </div>
              <div className="mt-2 text-2xl font-black text-slate-900 dark:text-white font-mono">
                {trackingState.pointCount}
              </div>
              <div className="mt-1 text-[11px] text-slate-400">Logged GPS points</div>
            </div>

          </div>

          {/* Action Control Buttons */}
          <div className="space-y-3">
            {!trackingState.isTracking ? (
              <button
                type="button"
                onClick={handleStart}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:hover:bg-emerald-400 dark:text-roam-night font-black text-base shadow-float hover:scale-[1.01] transition-all"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>Start Trail Recording</span>
              </button>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {trackingState.isPaused ? (
                  <button
                    type="button"
                    onClick={handleResume}
                    className="flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-md"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Resume</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handlePause}
                    className="flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm shadow-md"
                  >
                    <Pause className="w-4 h-4 fill-current" />
                    <span>Pause</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleStop}
                  className="flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm shadow-md"
                >
                  <Square className="w-4 h-4 fill-current" />
                  <span>Stop & Save</span>
                </button>
              </div>
            )}
          </div>

          {/* Real-time GPS Position Coordinates Display */}
          {trackingState.currentLocation && (
            <div className="p-3.5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder text-xs flex items-center justify-between text-slate-600 dark:text-slate-300">
              <span className="font-semibold">Current Coordinate:</span>
              <span className="font-mono font-bold text-slate-800 dark:text-slate-100">
                {trackingState.currentLocation.latitude.toFixed(6)}, {trackingState.currentLocation.longitude.toFixed(6)} (±{trackingState.currentLocation.accuracy}m)
              </span>
            </div>
          )}

        </div>

        {/* Right Column: Live Trail Polyline Map */}
        <div className="lg:col-span-7 bg-white dark:bg-roam-nightcard rounded-3xl overflow-hidden border border-roam-stone/80 dark:border-roam-nightborder shadow-soft">
          <div className="p-4 bg-roam-sand/60 dark:bg-roam-night border-b border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Route Polyline Rendering
            </span>
            <span className="text-[11px] font-bold text-slate-500">
              {trackingState.isTracking ? (trackingState.isPaused ? 'Paused' : 'Recording Active') : 'Standby'}
            </span>
          </div>

          <div ref={mapContainerRef} className="h-80 sm:h-[480px] w-full" />
        </div>

      </div>

    </div>
  );
}
