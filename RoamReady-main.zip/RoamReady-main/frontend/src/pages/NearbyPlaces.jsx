import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MapPin, 
  Search, 
  Filter, 
  Compass, 
  PhoneCall, 
  Star, 
  Heart, 
  CheckCircle2, 
  Map, 
  ExternalLink,
  ShieldAlert,
  ArrowUpDown
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { getTouristPlaces, toggleFavourite, isFavourite, getAllDownloadedMaps } from '../utils/storage';
import { calculateHaversineDistance, formatDistance } from '../utils/geo';
import { CATEGORIES_LIST, DESTINATIONS_CATALOG } from '../data/mockDestinations';

export default function NearbyPlaces() {
  const navigate = useNavigate();
  const { distanceUnit } = useTheme();

  const [places, setPlaces] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentGps, setCurrentGps] = useState([12.4244, 75.7382]); // Default Madikeri
  const [gpsAcquired, setGpsAcquired] = useState(false);
  const [favouriteIds, setFavouriteIds] = useState(new Set());

  // Load POIs from IndexedDB
  useEffect(() => {
    async function loadData() {
      try {
        let loaded = await getTouristPlaces();
        if (!loaded || loaded.length === 0) {
          // If no custom regions yet, populate with catalog places
          const defaultPois = DESTINATIONS_CATALOG.flatMap(d => d.pois.map(p => ({
            ...p,
            regionName: d.name
          })));
          loaded = defaultPois;
        }
        setPlaces(loaded);
      } catch (err) {
        console.warn('Error loading nearby places:', err);
      }
    }
    loadData();

    // Get current GPS location
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCurrentGps([pos.coords.latitude, pos.coords.longitude]);
          setGpsAcquired(true);
        },
        () => {
          setGpsAcquired(false);
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    }
  }, []);

  // Filter and sort by Haversine distance
  const sortedAndFilteredPlaces = useMemo(() => {
    return places
      .filter((p) => {
        const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
        const matchesQuery = 
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.description.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCat && matchesQuery;
      })
      .map((p) => {
        const distKm = calculateHaversineDistance(
          currentGps[0],
          currentGps[1],
          p.latitude,
          p.longitude,
          'km'
        );
        return {
          ...p,
          distKm,
          formattedDistance: formatDistance(distKm, distanceUnit)
        };
      })
      .sort((a, b) => a.distKm - b.distKm); // Sort nearest first
  }, [places, selectedCategory, searchQuery, currentGps, distanceUnit]);

  const handleToggleFav = async (place) => {
    const isFav = await toggleFavourite(place);
    setFavouriteIds(prev => {
      const next = new Set(prev);
      if (isFav) next.add(place.id);
      else next.delete(place.id);
      return next;
    });
  };

  const handleViewOnMap = (place) => {
    navigate(`/map?regionId=${place.regionId || ''}&lat=${place.latitude}&lon=${place.longitude}`);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 pb-24">
      
      {/* Title & GPS Context */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Nearby Tourist Attractions
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Search your local downloaded dataset without cellular network. Sorted by nearest straight-line proximity.
          </p>
        </div>

        <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone dark:border-roam-nightborder text-xs font-semibold text-slate-700 dark:text-slate-300 shadow-soft">
          <MapPin className="w-4 h-4 text-emerald-500" />
          <span>
            {gpsAcquired ? 'Live GPS Position Active' : 'Reference Location: Madikeri, Coorg'}
          </span>
        </div>
      </div>

      {/* Approximate Distance Academic Disclaimer */}
      <div className="p-3.5 rounded-2xl bg-roam-sand dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder flex items-start gap-3 text-xs text-slate-600 dark:text-slate-300">
        <ShieldAlert className="w-4 h-4 text-roam-terracotta flex-shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-800 dark:text-slate-100">Approximate distance (straight-line):</strong> Distances are calculated using the Haversine formula based on your current GPS coordinate. Actual walking or trekking paths through mountain terrains or forest trails may vary according to topographic contours.
        </div>
      </div>

      {/* Local Offline Search Bar */}
      <div className="relative max-w-xl">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search local sights by name or keyword..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-white dark:bg-roam-nightcard text-xs sm:text-sm text-slate-800 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 font-bold"
          >
            Clear
          </button>
        )}
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {CATEGORIES_LIST.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex-shrink-0 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                isSelected
                  ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night shadow-sm scale-105'
                  : 'bg-white dark:bg-roam-nightcard text-slate-600 dark:text-slate-300 border border-roam-stone/70 dark:border-roam-nightborder hover:bg-roam-sand dark:hover:bg-roam-night'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Results Count & Sort info */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-roam-stone/60 dark:border-roam-nightborder">
        <span>Showing {sortedAndFilteredPlaces.length} attractions</span>
        <span className="flex items-center gap-1 font-semibold text-roam-green dark:text-roam-mint">
          <ArrowUpDown className="w-3.5 h-3.5" /> Nearest first
        </span>
      </div>

      {/* Nearby Places Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {sortedAndFilteredPlaces.map((place) => (
          <div
            key={place.id}
            className="bg-white dark:bg-roam-nightcard rounded-2xl p-5 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft flex flex-col justify-between hover:shadow-float transition-all"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-roam-sand dark:bg-roam-night text-roam-terracotta text-[10px] font-bold uppercase tracking-wider">
                  {place.category}
                </span>

                <button
                  onClick={() => handleToggleFav(place)}
                  aria-label="Add to favourites"
                  className="p-1 rounded-lg text-slate-400 hover:text-amber-500 transition-colors"
                >
                  <Star className={`w-4 h-4 ${favouriteIds.has(place.id) ? 'fill-amber-400 text-amber-400' : ''}`} />
                </button>
              </div>

              <h3 className="font-extrabold text-base text-slate-900 dark:text-white mt-2">
                {place.name}
              </h3>

              <div className="flex items-baseline gap-1.5 mt-1">
                <span className="text-sm font-black text-emerald-600 dark:text-emerald-400">
                  {place.formattedDistance}
                </span>
                <span className="text-[10px] text-slate-400 font-medium">approx. straight-line</span>
              </div>

              <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
                {place.description}
              </p>

              {place.emergencyContact && (
                <div className="mt-2.5 p-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-1.5 font-semibold">
                  <PhoneCall className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">{place.emergencyContact}</span>
                </div>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                {place.latitude.toFixed(4)}, {place.longitude.toFixed(4)}
              </span>

              <button
                onClick={() => handleViewOnMap(place)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90 transition-opacity"
              >
                <Map className="w-3.5 h-3.5" />
                <span>View on Map</span>
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}
