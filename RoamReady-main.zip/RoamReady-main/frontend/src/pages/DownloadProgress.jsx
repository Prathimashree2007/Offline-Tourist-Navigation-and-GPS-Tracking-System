import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { 
  DownloadCloud, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Map, 
  HardDrive, 
  MapPin, 
  ArrowRight,
  RotateCcw
} from 'lucide-react';
import { downloadManager } from '../utils/downloadManager';
import { DESTINATIONS_CATALOG } from '../data/mockDestinations';

export default function DownloadProgress() {
  const location = useLocation();
  const navigate = useNavigate();

  const destination = location.state?.destination || DESTINATIONS_CATALOG[0];
  const radiusKm = location.state?.radiusKm || 10;
  const regionId = `region_${destination.id}_${radiusKm}km`;

  const [progress, setProgress] = useState({
    status: 'starting',
    percentage: 0,
    current: 0,
    total: 0,
    mbDownloaded: '0.00',
    stage: 'Initializing download queue...'
  });
  const [downloadError, setDownloadError] = useState(null);
  const downloadInitiatedRef = useRef(false);

  const startDownload = async () => {
    setDownloadError(null);
    try {
      await downloadManager.downloadRegion({
        regionId,
        regionName: `${destination.name} (${radiusKm} km)`,
        destinationId: destination.id,
        centerLat: destination.latitude,
        centerLon: destination.longitude,
        radiusKm,
        pois: destination.pois,
        onProgress: (p) => setProgress(p)
      });
    } catch (err) {
      if (err.name !== 'AbortError') {
        setDownloadError(err.message || 'Download encountered an unexpected issue.');
      }
    }
  };

  useEffect(() => {
    if (!downloadInitiatedRef.current) {
      downloadInitiatedRef.current = true;
      startDownload();
    }
  }, []);

  const handleCancel = () => {
    downloadManager.cancelDownload(regionId);
    setProgress(prev => ({ ...prev, status: 'cancelled', stage: 'Download cancelled by user.' }));
  };

  const handleRetry = () => {
    startDownload();
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-24">
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-8 sm:p-12 border border-roam-stone/80 dark:border-roam-nightborder shadow-float text-center transition-colors">
        
        {/* Animated Icon based on Status */}
        <div className="mx-auto mb-6">
          {progress.status === 'completed' ? (
            <div className="w-20 h-20 rounded-3xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-glow">
              <CheckCircle2 className="w-10 h-10 animate-bounce" />
            </div>
          ) : progress.status === 'failed' || downloadError ? (
            <div className="w-20 h-20 rounded-3xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-10 h-10" />
            </div>
          ) : progress.status === 'cancelled' ? (
            <div className="w-20 h-20 rounded-3xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
              <XCircle className="w-10 h-10" />
            </div>
          ) : (
            <div className="w-20 h-20 rounded-3xl bg-roam-green/10 dark:bg-roam-mint/20 text-roam-green dark:text-roam-mint flex items-center justify-center mx-auto animate-pulse">
              <DownloadCloud className="w-10 h-10" />
            </div>
          )}
        </div>

        {/* Title & Region Name */}
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          {progress.status === 'completed'
            ? 'Region Download Complete!'
            : progress.status === 'cancelled'
            ? 'Download Cancelled'
            : progress.status === 'failed' || downloadError
            ? 'Download Interrupted'
            : 'Downloading Map Region'}
        </h1>

        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 font-medium">
          {destination.name} • {radiusKm} km radius ({destination.pois.length} bundled tourist sights)
        </p>

        {/* Progress Bar Container */}
        {progress.status !== 'completed' && progress.status !== 'cancelled' && !downloadError && (
          <div className="mt-8 max-w-lg mx-auto">
            <div className="flex items-center justify-between text-xs font-bold text-slate-600 dark:text-slate-400 mb-2">
              <span>{progress.stage}</span>
              <span>{progress.percentage}%</span>
            </div>

            <div className="w-full h-3 bg-roam-stone dark:bg-roam-nightborder rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-roam-green to-roam-mint transition-all duration-300 rounded-full"
                style={{ width: `${progress.percentage}%` }}
              />
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4 text-xs text-slate-500 pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder">
              <div>
                Tiles Cached: <strong className="text-slate-800 dark:text-slate-200">{progress.current} / {progress.total}</strong>
              </div>
              <div>
                Storage Size: <strong className="text-emerald-600 dark:text-emerald-400">{progress.mbDownloaded} MB</strong>
              </div>
            </div>

            {/* Cancel Button */}
            <div className="mt-6">
              <button
                type="button"
                onClick={handleCancel}
                className="px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs font-bold hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
              >
                Cancel Download
              </button>
            </div>
          </div>
        )}

        {/* Completed State Actions */}
        {progress.status === 'completed' && (
          <div className="mt-8 space-y-6 max-w-md mx-auto">
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 font-medium leading-relaxed">
              All map tile pyramids (Zoom 11–15) and {destination.pois.length} tourist points of interest are now stored permanently in IndexedDB. You can access this map anywhere without cellular network.
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                to={`/map?regionId=${regionId}`}
                className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night font-bold text-sm shadow-float hover:scale-[1.02] transition-all"
              >
                <Map className="w-4 h-4" />
                <span>Open Offline Map</span>
              </Link>

              <Link
                to="/downloads"
                className="flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-white dark:bg-roam-night border border-roam-stone dark:border-roam-nightborder text-slate-700 dark:text-slate-200 font-bold text-sm hover:bg-roam-sand transition-colors"
              >
                <HardDrive className="w-4 h-4 text-roam-green dark:text-roam-mint" />
                <span>Manage Maps</span>
              </Link>
            </div>
          </div>
        )}

        {/* Cancelled / Error State Actions */}
        {(progress.status === 'cancelled' || downloadError) && (
          <div className="mt-8 space-y-4 max-w-md mx-auto">
            <p className="text-xs text-rose-600 dark:text-rose-400">
              {downloadError || 'The download was stopped before completion.'}
            </p>
            <div className="flex gap-3 justify-center">
              <button
                type="button"
                onClick={handleRetry}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night font-bold text-xs shadow-sm hover:opacity-90"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry Download</span>
              </button>
              <Link
                to="/search"
                className="px-5 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder text-slate-700 dark:text-slate-300 font-semibold text-xs"
              >
                Choose Another Destination
              </Link>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
