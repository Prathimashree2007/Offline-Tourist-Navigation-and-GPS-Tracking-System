import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Footprints, 
  Calendar, 
  Clock, 
  TrendingUp, 
  Trash2, 
  MapPin, 
  ArrowRight, 
  AlertTriangle,
  Compass,
  Sparkles
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { getAllTrips, deleteTrip, deleteAllTrips, saveTrip } from '../utils/storage';
import { formatDistance } from '../utils/geo';
import ConfirmationModal from '../components/ConfirmationModal';

export default function TravelHistory() {
  const navigate = useNavigate();
  const { distanceUnit } = useTheme();

  const [trips, setTrips] = useState([]);
  const [deleteTargetId, setDeleteTargetId] = useState(null);
  const [isDeleteAllOpen, setIsDeleteAllOpen] = useState(false);

  const loadTrips = async () => {
    try {
      const history = await getAllTrips();
      // If user has zero trips, provide initial seed trip for instant academic review
      if (history.length === 0) {
        const seedTrip = {
          id: 'trip_demo_coorg',
          name: 'Abbey Falls Wilderness Expedition',
          destinationName: 'Madikeri, Coorg',
          startLat: 12.4244,
          startLon: 75.7382,
          endLat: 12.4542,
          endLon: 75.7196,
          startedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
          endedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
          distanceKm: 4.82,
          durationSeconds: 3420,
          avgSpeedKmh: 5.1,
          maxSpeedKmh: 7.2,
          pointCount: 38,
          points: [
            { latitude: 12.4244, longitude: 75.7382, timestamp: new Date(Date.now() - 3400000).toISOString() },
            { latitude: 12.4300, longitude: 75.7340, timestamp: new Date(Date.now() - 3000000).toISOString() },
            { latitude: 12.4410, longitude: 75.7280, timestamp: new Date(Date.now() - 2500000).toISOString() },
            { latitude: 12.4542, longitude: 75.7196, timestamp: new Date(Date.now() - 2000000).toISOString() }
          ]
        };
        await saveTrip(seedTrip);
        setTrips([seedTrip]);
      } else {
        setTrips(history);
      }
    } catch (err) {
      console.warn('Error fetching travel history:', err);
    }
  };

  useEffect(() => {
    loadTrips();
  }, []);

  const handleDeleteOne = async () => {
    if (deleteTargetId) {
      await deleteTrip(deleteTargetId);
      setDeleteTargetId(null);
      loadTrips();
    }
  };

  const handleDeleteAll = async () => {
    await deleteAllTrips();
    setIsDeleteAllOpen(false);
    loadTrips();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 pb-24">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            Travel History & Recorded Trails
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Persistent local records of your mountain and wilderness journeys. Accessible 100% offline.
          </p>
        </div>

        {trips.length > 0 && (
          <button
            type="button"
            onClick={() => setIsDeleteAllOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition-colors shadow-sm self-start sm:self-auto"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete All History</span>
          </button>
        )}
      </div>

      {/* Trips List */}
      {trips.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-roam-nightcard rounded-3xl border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <Footprints className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">No journeys recorded yet</h3>
          <p className="mt-1 text-xs text-slate-500">
            Start the GPS tracker during your next trail to record path waypoints and statistics.
          </p>
          <Link
            to="/tracking"
            className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night font-bold text-xs shadow-md"
          >
            <span>Record A Trail</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {trips.map((trip) => {
            const dateStr = new Date(trip.startedAt).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric'
            });
            const minutes = Math.max(1, Math.round(trip.durationSeconds / 60));

            return (
              <div
                key={trip.id}
                className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft hover:shadow-float transition-all flex flex-col md:flex-row md:items-center justify-between gap-5"
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md bg-roam-green/10 text-roam-green dark:bg-roam-mint/20 dark:text-roam-mint text-[11px] font-bold">
                      {dateStr}
                    </span>
                    {trip.isDemo && (
                      <span className="px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-600 dark:text-amber-400 text-[10px] font-bold">
                        Demo Trail
                      </span>
                    )}
                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-500 font-medium">
                      {trip.destinationName || 'Scenic Route'}
                    </span>
                  </div>

                  <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
                    {trip.name}
                  </h3>

                  {/* Summary Metric Strip */}
                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 dark:text-slate-300 pt-1">
                    <span className="flex items-center gap-1 font-bold text-emerald-600 dark:text-emerald-400">
                      <TrendingUp className="w-3.5 h-3.5" />
                      {formatDistance(trip.distanceKm, distanceUnit)}
                    </span>
                    <span className="flex items-center gap-1 font-medium">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      {minutes} mins
                    </span>
                    <span className="flex items-center gap-1 font-medium">
                      <Footprints className="w-3.5 h-3.5 text-slate-400" />
                      {trip.pointCount || 0} GPS points
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      Start: {trip.startLat?.toFixed(4)}, {trip.startLon?.toFixed(4)}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-roam-stone/60 dark:border-roam-nightborder">
                  <Link
                    to={`/trip/${trip.id}`}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90 transition-opacity"
                  >
                    <span>View Route</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>

                  <button
                    type="button"
                    onClick={() => setDeleteTargetId(trip.id)}
                    className="p-2.5 rounded-xl text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                    title="Delete this journey"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Confirmation Modal for Single Delete */}
      <ConfirmationModal
        isOpen={!!deleteTargetId}
        title="Delete Trip History?"
        message="Are you sure you want to permanently delete this recorded GPS trail? This action cannot be undone."
        confirmText="Delete Trip"
        onConfirm={handleDeleteOne}
        onClose={() => setDeleteTargetId(null)}
      />

      {/* Confirmation Modal for Delete All */}
      <ConfirmationModal
        isOpen={isDeleteAllOpen}
        title="Delete All Travel History?"
        message="Are you sure you want to delete ALL recorded journeys from your local IndexedDB? All waypoint tracks and statistics will be wiped."
        confirmText="Wipe All History"
        onConfirm={handleDeleteAll}
        onClose={() => setIsDeleteAllOpen(false)}
      />

    </div>
  );
}
