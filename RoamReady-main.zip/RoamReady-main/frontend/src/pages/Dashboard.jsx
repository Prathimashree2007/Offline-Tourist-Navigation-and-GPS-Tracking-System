import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Compass, 
  Map, 
  Navigation, 
  Search, 
  Footprints, 
  HardDrive, 
  DownloadCloud, 
  MapPin, 
  ArrowRight,
  TrendingUp,
  Sparkles,
  Mountain,
  Droplets,
  Waves,
  ShieldAlert
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { DESTINATIONS_CATALOG } from '../data/mockDestinations';
import { getStorageStats, getAllTrips, getAllDownloadedMaps } from '../utils/storage';
import { formatDistance } from '../utils/geo';

export default function Dashboard() {
  const { user, isOnline } = useAuth();
  const { distanceUnit } = useTheme();

  const [stats, setStats] = useState({
    mapCount: 0,
    tileCount: 0,
    poiCount: 0,
    tripCount: 0,
    totalTileMB: '0.00'
  });
  const [totalTrailDistanceKm, setTotalTrailDistanceKm] = useState(0);
  const [downloadedMapsList, setDownloadedMapsList] = useState([]);

  useEffect(() => {
    async function loadData() {
      try {
        const storageData = await getStorageStats();
        setStats(storageData);

        const trips = await getAllTrips();
        const totalDist = trips.reduce((acc, t) => acc + (t.distanceKm || 0), 0);
        setTotalTrailDistanceKm(totalDist);

        const maps = await getAllDownloadedMaps();
        setDownloadedMapsList(maps);
      } catch (err) {
        console.warn('Could not load dashboard metrics:', err);
      }
    }
    loadData();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 pb-20">
      
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-roam-green via-roam-lightgreen to-roam-teal text-white shadow-float relative overflow-hidden">
        <div className="relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider mb-2">
            <Compass className="w-3.5 h-3.5 animate-spin-slow" />
            Tourist Navigation Control Center
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome, {user?.name || 'Explorer'}!
          </h1>
          <p className="mt-1 text-white/85 text-sm max-w-xl">
            {isOnline
              ? 'You are online. Search destinations and pre-cache 5–50 km map regions before venturing into remote trails.'
              : 'You are offline. Your downloaded regions, offline POIs, and GPS trail tracking are fully active.'}
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap gap-2.5">
          <Link
            to="/search"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-roam-green font-bold text-sm hover:bg-roam-sand transition-colors shadow-sm"
          >
            <Search className="w-4 h-4" />
            <span>Search Destination</span>
          </Link>
          <Link
            to="/map"
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-black/25 hover:bg-black/40 text-white font-bold text-sm border border-white/20 transition-colors"
          >
            <Map className="w-4 h-4" />
            <span>Open Map</span>
          </Link>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Metric 1 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-500 tracking-wider">Offline Regions</span>
            <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400">
              <HardDrive className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {stats.mapCount}
            </span>
            <span className="text-xs text-slate-500 font-medium">({stats.totalTileMB} MB)</span>
          </div>
          <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            {stats.tileCount} cached map tiles
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-500 tracking-wider">GPS Trail Distance</span>
            <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
              <Navigation className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {formatDistance(totalTrailDistanceKm, distanceUnit)}
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            {stats.tripCount} recorded journeys
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-500 tracking-wider">Offline Sights</span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400">
              <MapPin className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              {stats.poiCount > 0 ? stats.poiCount : '35+'}
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            Waterfalls, viewpoints, hills
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-500 tracking-wider">Storage Status</span>
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white">
              Healthy
            </span>
          </div>
          <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">
            IndexedDB persistence active
          </div>
        </div>

      </div>

      {/* Quick Access Action Hub */}
      <div>
        <h2 className="text-lg font-extrabold text-slate-900 dark:text-white mb-4">
          Quick Action Hub
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          <Link
            to="/search"
            className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder hover:border-roam-green dark:hover:border-roam-mint shadow-soft hover:shadow-float transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <DownloadCloud className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Plan Map Download</h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Select 5km, 10km, 25km or 50km radius for pre-caching.
            </p>
          </Link>

          <Link
            to="/map"
            className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder hover:border-roam-green dark:hover:border-roam-mint shadow-soft hover:shadow-float transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Map className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Open Offline Map</h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              View GPS location, boundary circles, and markers offline.
            </p>
          </Link>

          <Link
            to="/nearby"
            className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder hover:border-roam-green dark:hover:border-roam-mint shadow-soft hover:shadow-float transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <MapPin className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Nearby Attractions</h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Discover spontaneous spots sorted by straight-line distance.
            </p>
          </Link>

          <Link
            to="/tracking"
            className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder hover:border-roam-green dark:hover:border-roam-mint shadow-soft hover:shadow-float transition-all group"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Footprints className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-slate-800 dark:text-slate-100">Record GPS Trail</h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Log waypoints, calculate average speed, and save trail history.
            </p>
          </Link>

        </div>
      </div>

      {/* Curated Featured Destinations */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Featured Remote Destinations
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Curated Western Ghats & Coastal hiking spots with bundled offline POIs
            </p>
          </div>
          <Link
            to="/search"
            className="text-xs font-bold text-roam-green dark:text-roam-mint hover:underline flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DESTINATIONS_CATALOG.slice(0, 3).map((dest) => (
            <div
              key={dest.id}
              className="bg-white dark:bg-roam-nightcard rounded-3xl overflow-hidden border border-roam-stone/80 dark:border-roam-nightborder shadow-soft flex flex-col justify-between group hover:shadow-float transition-all"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={dest.bannerImage}
                  alt={dest.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-[10px] font-bold uppercase tracking-wider">
                  {dest.category}
                </div>
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                  {dest.difficulty}
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    {dest.name}
                  </h3>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    {dest.state}, {dest.country} • Best: {dest.bestSeason}
                  </div>
                  <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                    {dest.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-roam-stone/60 dark:border-roam-nightborder flex items-center justify-between">
                  <div className="text-[11px] text-slate-500 font-medium">
                    {dest.pois.length} Sights Included
                  </div>
                  <Link
                    to={`/planning?id=${dest.id}`}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night text-xs font-bold shadow-sm hover:opacity-90 transition-opacity"
                  >
                    <DownloadCloud className="w-3.5 h-3.5" />
                    <span>Download Map</span>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
