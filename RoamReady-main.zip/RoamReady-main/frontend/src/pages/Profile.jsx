import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, 
  Mail, 
  MapPin, 
  Footprints, 
  HardDrive, 
  LogOut, 
  ShieldCheck, 
  RefreshCw, 
  CheckCircle2,
  TrendingUp,
  Settings as SettingsIcon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { getAllTrips, getAllDownloadedMaps } from '../utils/storage';
import { formatDistance } from '../utils/geo';

export default function Profile() {
  const { user, isOnline, logout } = useAuth();
  const { distanceUnit } = useTheme();
  const navigate = useNavigate();

  const [tripCount, setTripCount] = useState(0);
  const [totalKm, setTotalKm] = useState(0);
  const [mapCount, setMapCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);

  useEffect(() => {
    async function loadStats() {
      const trips = await getAllTrips();
      const maps = await getAllDownloadedMaps();
      setTripCount(trips.length);
      setTotalKm(trips.reduce((acc, t) => acc + (t.distanceKm || 0), 0));
      setMapCount(maps.length);
    }
    loadStats();
  }, []);

  const handleSyncCloud = async () => {
    if (!isOnline) {
      alert('Cloud synchronization requires active internet.');
      return;
    }
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncSuccess(true);
      setTimeout(() => setSyncSuccess(false), 3000);
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 pb-24">
      
      {/* Profile Card */}
      <div className="bg-white dark:bg-roam-nightcard rounded-3xl p-6 sm:p-8 border border-roam-stone/80 dark:border-roam-nightborder shadow-soft flex flex-col sm:flex-row items-center sm:items-start gap-6">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-roam-green to-roam-teal text-white flex items-center justify-center text-2xl font-black shadow-float">
          {user?.name ? user.name[0].toUpperCase() : 'U'}
        </div>

        <div className="flex-1 text-center sm:text-left space-y-1">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">
              {user?.name || 'Trail Explorer'}
            </h1>
            <span className="inline-flex self-center sm:self-auto items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 text-[11px] font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified Tourist
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center justify-center sm:justify-start gap-1.5">
            <Mail className="w-3.5 h-3.5 text-slate-400" />
            <span>{user?.email || 'explorer@roamready.app'}</span>
          </p>

          <p className="text-xs text-slate-400 pt-2">
            Preferred distance unit: <strong className="text-slate-700 dark:text-slate-200 uppercase">{distanceUnit}</strong>
          </p>
        </div>

        <div className="flex sm:flex-col gap-2">
          <button
            onClick={() => navigate('/settings')}
            className="px-4 py-2 rounded-xl border border-roam-stone dark:border-roam-nightborder text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-roam-sand dark:hover:bg-roam-night transition-colors"
          >
            Settings
          </button>
          <button
            onClick={() => {
              logout();
              navigate('/login');
            }}
            className="px-4 py-2 rounded-xl bg-rose-50 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400 text-xs font-bold hover:bg-rose-100 transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>

      {syncSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-2 animate-slide-down">
          <CheckCircle2 className="w-4 h-4" />
          <span>Local journeys synchronized successfully with MySQL cloud datastore!</span>
        </div>
      )}

      {/* Explorer Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <span className="text-xs font-bold uppercase text-slate-400 tracking-wider">Journeys</span>
          <div className="mt-2 text-3xl font-black text-slate-900 dark:text-white">
            {tripCount}
          </div>
          <span className="text-[11px] text-slate-500">Recorded GPS tracks</span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <span className="text-xs font-bold uppercase text-slate-400 tracking-wider">Distance Covered</span>
          <div className="mt-2 text-3xl font-black text-emerald-600 dark:text-emerald-400">
            {formatDistance(totalKm, distanceUnit)}
          </div>
          <span className="text-[11px] text-slate-500">Across wilderness trails</span>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-roam-nightcard border border-roam-stone/70 dark:border-roam-nightborder shadow-soft">
          <span className="text-xs font-bold uppercase text-slate-400 tracking-wider">Offline Regions</span>
          <div className="mt-2 text-3xl font-black text-roam-terracotta">
            {mapCount}
          </div>
          <span className="text-[11px] text-slate-500">Cached for offline travel</span>
        </div>

      </div>

      {/* Cloud Synchronization Section */}
      <div className="p-6 rounded-3xl bg-white dark:bg-roam-nightcard border border-roam-stone/80 dark:border-roam-nightborder shadow-soft flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
            Cloud Data Synchronization
          </h3>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            Sync local IndexedDB journeys and downloaded map metadata with backend MySQL.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSyncCloud}
          disabled={isSyncing}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night font-bold text-xs shadow-sm hover:opacity-90"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
          <span>{isSyncing ? 'Synchronizing...' : 'Sync with MySQL'}</span>
        </button>
      </div>

    </div>
  );
}
