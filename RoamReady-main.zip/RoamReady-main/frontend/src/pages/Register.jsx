import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Compass, User, Mail, Lock, ShieldCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [unit, setUnit] = useState('km');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await register(name, email, password, unit);
      if (res.success) {
        navigate('/dashboard');
      } else {
        setError(res.message || 'Registration failed. Please verify your details.');
      }
    } catch {
      setError('An unexpected error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full bg-white dark:bg-roam-nightcard rounded-3xl p-8 shadow-float border border-roam-stone/80 dark:border-roam-nightborder transition-colors">
        
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-roam-green to-roam-teal text-white flex items-center justify-center mx-auto mb-3 shadow-soft">
            <Compass className="w-6 h-6" />
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white">Create Your Account</h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Join RoamReady to download maps and save GPS trails
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-xs font-semibold">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
              Full Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Arjun Patil"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="explorer@roamready.app"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-roam-stone dark:border-roam-nightborder bg-roam-sand/40 dark:bg-roam-night text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-roam-green dark:focus:ring-roam-mint"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mb-1.5">
              Preferred Distance Unit
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setUnit('km')}
                className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                  unit === 'km'
                    ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night border-transparent shadow-sm'
                    : 'border-roam-stone dark:border-roam-nightborder text-slate-600 dark:text-slate-300'
                }`}
              >
                Kilometers (km)
              </button>
              <button
                type="button"
                onClick={() => setUnit('miles')}
                className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                  unit === 'miles'
                    ? 'bg-roam-green text-white dark:bg-roam-mint dark:text-roam-night border-transparent shadow-sm'
                    : 'border-roam-stone dark:border-roam-nightborder text-slate-600 dark:text-slate-300'
                }`}
              >
                Miles (mi)
              </button>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-roam-green hover:bg-roam-lightgreen text-white dark:bg-roam-mint dark:hover:bg-emerald-400 dark:text-roam-night font-bold text-sm shadow-md transition-all hover:scale-[1.01]"
            >
              <span>{loading ? 'Creating Account...' : 'Register Account'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </form>

        <div className="mt-6 text-center text-xs text-slate-500 dark:text-slate-400">
          Already registered?{' '}
          <Link to="/login" className="font-bold text-roam-green dark:text-roam-mint hover:underline">
            Sign In here
          </Link>
        </div>

        <div className="mt-6 p-3 rounded-xl bg-roam-sand dark:bg-roam-night border border-roam-stone/60 dark:border-roam-nightborder text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-500 flex-shrink-0" />
          <span>Works offline-first with IndexedDB and MySQL synchronization when online.</span>
        </div>

      </div>
    </div>
  );
}
