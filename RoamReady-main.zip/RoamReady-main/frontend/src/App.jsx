import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';

// Components
import Navbar from './components/Navbar';
import BottomNav from './components/BottomNav';
import OfflineBanner from './components/OfflineBanner';

// All 17 Required Pages
import Welcome from './pages/Welcome';
import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Search from './pages/Search';
import DestinationDetails from './pages/DestinationDetails';
import MapPlanning from './pages/MapPlanning';
import DownloadProgress from './pages/DownloadProgress';
import OfflineMap from './pages/OfflineMap';
import NearbyPlaces from './pages/NearbyPlaces';
import GpsTracking from './pages/GpsTracking';
import TravelHistory from './pages/TravelHistory';
import TripDetails from './pages/TripDetails';
import MapManagement from './pages/MapManagement';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import About from './pages/About';

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <div className="flex flex-col min-h-screen bg-roam-sand text-slate-800 dark:bg-roam-night dark:text-slate-100 transition-colors">
            {/* Top Navigation Bar */}
            <Navbar />

            {/* Offline Alert Strip */}
            <OfflineBanner />

            {/* Dynamic Page Routed Views */}
            <main className="flex-1">
              <Routes>
                {/* 1. Welcome / Landing Page */}
                <Route path="/" element={<Welcome />} />

                {/* 2. Registration */}
                <Route path="/register" element={<Register />} />

                {/* 3. Login */}
                <Route path="/login" element={<Login />} />

                {/* 4. Explore Dashboard */}
                <Route path="/dashboard" element={<Dashboard />} />

                {/* 5. Destination Search */}
                <Route path="/search" element={<Search />} />

                {/* 6. Destination Details */}
                <Route path="/destination/:id" element={<DestinationDetails />} />

                {/* 7. Map Download Planning */}
                <Route path="/planning" element={<MapPlanning />} />

                {/* 8. Download Progress */}
                <Route path="/progress" element={<DownloadProgress />} />

                {/* 9. Offline Navigation Map */}
                <Route path="/map" element={<OfflineMap />} />

                {/* 10. Nearby Tourist Places */}
                <Route path="/nearby" element={<NearbyPlaces />} />

                {/* 11. GPS Tracking */}
                <Route path="/tracking" element={<GpsTracking />} />

                {/* 12. Travel History */}
                <Route path="/history" element={<TravelHistory />} />

                {/* 13. Trip Details */}
                <Route path="/trip/:id" element={<TripDetails />} />

                {/* 14. Downloaded Maps Management */}
                <Route path="/downloads" element={<MapManagement />} />

                {/* 15. Profile */}
                <Route path="/profile" element={<Profile />} />

                {/* 16. Settings */}
                <Route path="/settings" element={<Settings />} />

                {/* 17. About Academic Page */}
                <Route path="/about" element={<About />} />

                {/* Fallback route */}
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </main>

            {/* Mobile Bottom Navigation Bar */}
            <BottomNav />
          </div>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}
