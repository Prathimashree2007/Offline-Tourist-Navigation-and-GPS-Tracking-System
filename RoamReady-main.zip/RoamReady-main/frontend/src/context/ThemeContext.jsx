import React, { createContext, useContext, useState, useEffect } from 'react';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('roamready_dark_mode');
    return saved !== null ? JSON.parse(saved) : false;
  });

  const [distanceUnit, setDistanceUnitState] = useState(() => {
    return localStorage.getItem('roamready_unit') || 'km';
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('roamready_dark_mode', JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  const setDistanceUnit = (unit) => {
    setDistanceUnitState(unit);
    localStorage.setItem('roamready_unit', unit);
  };

  return (
    <ThemeContext.Provider
      value={{
        isDarkMode,
        toggleDarkMode,
        distanceUnit,
        setDistanceUnit
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
