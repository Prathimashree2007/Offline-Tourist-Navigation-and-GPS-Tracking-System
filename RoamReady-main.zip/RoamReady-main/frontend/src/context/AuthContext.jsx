import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem('roamready_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState(() => localStorage.getItem('roamready_token') || null);
  const [isOnline, setIsOnline] = useState(() => navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const login = async (email, password) => {
    // If online, attempt REST API call
    if (isOnline) {
      try {
        const res = await fetch('http://localhost:5000/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (data.success) {
          setUser(data.user);
          setToken(data.token);
          localStorage.setItem('roamready_user', JSON.stringify(data.user));
          localStorage.setItem('roamready_token', data.token);
          return { success: true };
        } else {
          return { success: false, message: data.message };
        }
      } catch {
        // Fallback to local session if backend server is unreachable
      }
    }

    // Offline / Demo Local Login Fallback
    const localUser = {
      id: 1,
      name: email.split('@')[0] || 'Explorer',
      email: email,
      preferred_distance_unit: 'km'
    };
    const localToken = 'local_offline_token_' + Date.now();
    setUser(localUser);
    setToken(localToken);
    localStorage.setItem('roamready_user', JSON.stringify(localUser));
    localStorage.setItem('roamready_token', localToken);
    return { success: true, offlineNotice: true };
  };

  const register = async (name, email, password, preferred_distance_unit = 'km') => {
    if (isOnline) {
      try {
        const res = await fetch('http://localhost:5000/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, email, password, preferred_distance_unit })
        });
        const data = await res.json();
        if (data.success) {
          setUser(data.user);
          setToken(data.token);
          localStorage.setItem('roamready_user', JSON.stringify(data.user));
          localStorage.setItem('roamready_token', data.token);
          return { success: true };
        } else {
          return { success: false, message: data.message };
        }
      } catch {
        // Fallback to offline local registration
      }
    }

    const localUser = { id: Date.now(), name, email, preferred_distance_unit };
    const localToken = 'local_offline_token_' + Date.now();
    setUser(localUser);
    setToken(localToken);
    localStorage.setItem('roamready_user', JSON.stringify(localUser));
    localStorage.setItem('roamready_token', localToken);
    return { success: true, offlineNotice: true };
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('roamready_user');
    localStorage.removeItem('roamready_token');
  };

  const updateUser = (updates) => {
    const updated = { ...user, ...updates };
    setUser(updated);
    localStorage.setItem('roamready_user', JSON.stringify(updated));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isOnline,
        login,
        register,
        logout,
        updateUser
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
