/**
 * RoamReady Custom Offline TileLayer for Leaflet
 * Intercepts tile requests, pulls from IndexedDB when offline, falls back to network when online,
 * and renders an explicit "Coverage Unavailable" pattern if outside cached area while offline.
 */

import L from 'leaflet';
import { getTileBlob, findAnyTileBlob } from './storage';

export const OfflineTileLayer = L.TileLayer.extend({
  options: {
    regionId: null,
    isOfflineOnly: false,
    onCoverageWarning: null
  },

  initialize: function (urlTemplate, options) {
    L.TileLayer.prototype.initialize.call(this, urlTemplate, options);
    this.regionId = options.regionId || null;
    this.isOfflineOnly = options.isOfflineOnly || false;
    this.onCoverageWarning = options.onCoverageWarning || null;
  },

  createTile: function (coords, done) {
    const tile = document.createElement('img');

    L.DomEvent.on(tile, 'load', L.Util.bind(this._tileOnLoad, this, done, tile));
    L.DomEvent.on(tile, 'error', L.Util.bind(this._tileOnError, this, done, tile));

    if (this.options.crossOrigin || this.options.crossOrigin === '') {
      tile.crossOrigin = this.options.crossOrigin === true ? '' : this.options.crossOrigin;
    }

    tile.alt = '';
    tile.setAttribute('role', 'presentation');

    const z = coords.z;
    const x = coords.x;
    const y = coords.y;

    // First: Check local IndexedDB storage
    (async () => {
      try {
        let blob = null;
        if (this.regionId) {
          blob = await getTileBlob(this.regionId, z, x, y);
        }
        if (!blob) {
          blob = await findAnyTileBlob(z, x, y);
        }

        if (blob) {
          const url = URL.createObjectURL(blob);
          tile.src = url;
          // Revoke object URL after image loads
          tile.onload = () => {
            URL.revokeObjectURL(url);
            done(null, tile);
          };
          return;
        }

        // If not in IndexedDB:
        const isOnline = navigator.onLine && !this.options.isOfflineOnly;
        if (isOnline) {
          // Fetch from standard online source
          tile.src = this.getTileUrl(coords);
        } else {
          // True Offline Mode & Uncached Tile: Render explicit SVG placeholder
          tile.src = this._createMissingTileDataUri(z, x, y);
          if (this.options.onCoverageWarning) {
            this.options.onCoverageWarning({ z, x, y });
          }
          done(null, tile);
        }
      } catch (err) {
        console.warn('Error fetching tile from IndexedDB:', err);
        if (navigator.onLine && !this.options.isOfflineOnly) {
          tile.src = this.getTileUrl(coords);
        } else {
          tile.src = this._createMissingTileDataUri(z, x, y);
          done(null, tile);
        }
      }
    })();

    return tile;
  },

  _createMissingTileDataUri: function (z, x, y) {
    // Elegant SVG tile pattern indicating non-cached offline region
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">
        <rect width="256" height="256" fill="#182822" stroke="#273C34" stroke-width="1"/>
        <line x1="0" y1="0" x2="256" y2="256" stroke="#273C34" stroke-width="0.5" stroke-dasharray="4"/>
        <line x1="256" y1="0" x2="0" y2="256" stroke="#273C34" stroke-width="0.5" stroke-dasharray="4"/>
        <circle cx="128" cy="120" r="18" fill="none" stroke="#D96B43" stroke-width="2"/>
        <line x1="128" y1="112" x2="128" y2="122" stroke="#D96B43" stroke-width="2" stroke-linecap="round"/>
        <circle cx="128" cy="128" r="1.5" fill="#D96B43"/>
        <text x="128" y="152" fill="#94A3B8" font-size="11" font-family="system-ui, sans-serif" text-anchor="middle" font-weight="500">
          Uncached Area
        </text>
        <text x="128" y="168" fill="#64748B" font-size="9" font-family="system-ui, sans-serif" text-anchor="middle">
          z:${z} (${x}, ${y})
        </text>
      </svg>
    `;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
});

export function createOfflineTileLayer(urlTemplate, options) {
  return new OfflineTileLayer(urlTemplate, options);
}
