/**
 * RoamReady Download Manager
 * Coordinates genuine bounded tile pyramid downloading, POI caching,
 * progress updates, cancellation, and local persistence.
 */

import { calculateBoundingBox, getTilesInBoundingBox, estimateStorageSize } from './geo';
import { saveTileBlob, saveDownloadedMap, saveTouristPlaces } from './storage';
import { precacheRoutesForRegion } from './routing';

class DownloadManager {
  constructor() {
    this.activeDownloads = new Map(); // regionId -> AbortController
  }

  /**
   * Starts downloading map tiles and POIs for a specified destination and radius.
   * @param {Object} params
   * @param {string} params.regionId Unique identifier
   * @param {string} params.regionName Human-readable name
   * @param {number} params.centerLat Center latitude
   * @param {number} params.centerLon Center longitude
   * @param {number} params.radiusKm Radius (5, 10, 25, 50)
   * @param {Array} params.pois Array of tourist places in the region
   * @param {Function} params.onProgress Progress callback (progressObj)
   * @returns {Promise<Object>} Summary of downloaded map
   */
  async downloadRegion({
    regionId,
    regionName,
    destinationId = null,
    centerLat,
    centerLon,
    radiusKm,
    pois = [],
    onProgress = () => {}
  }) {
    if (this.activeDownloads.has(regionId)) {
      throw new Error(`A download for region "${regionName}" is already in progress.`);
    }

    const abortController = new AbortController();
    this.activeDownloads.set(regionId, abortController);

    try {
      const estimates = estimateStorageSize(radiusKm);
      const bbox = calculateBoundingBox(centerLat, centerLon, radiusKm);
      const tileCoordinates = getTilesInBoundingBox(bbox, estimates.minZoom, estimates.maxZoom);

      const totalTiles = tileCoordinates.length;
      let completedTiles = 0;
      let totalBytes = 0;
      let failedTiles = 0;

      onProgress({
        status: 'starting',
        current: 0,
        total: totalTiles,
        percentage: 0,
        bytesDownloaded: 0,
        stage: 'Initializing download queue...'
      });

      // Save POIs into IndexedDB first
      const regionPois = pois.map(p => ({
        ...p,
        regionId,
        regionName
      }));
      await saveTouristPlaces(regionPois);

      // Download tiles with concurrent chunks of 4 to prevent server throttling
      const CHUNK_SIZE = 4;
      for (let i = 0; i < tileCoordinates.length; i += CHUNK_SIZE) {
        if (abortController.signal.aborted) {
          throw new DOMException('Download cancelled by user', 'AbortError');
        }

        const chunk = tileCoordinates.slice(i, i + CHUNK_SIZE);
        await Promise.all(
          chunk.map(async (tileCoord) => {
            const { z, x, y } = tileCoord;
            const tileUrl = `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;

            try {
              const res = await fetch(tileUrl, {
                signal: abortController.signal,
                headers: {
                  'Accept': 'image/png,image/*;q=0.8'
                }
              });

              if (res.ok) {
                const blob = await res.blob();
                totalBytes += blob.size;
                await saveTileBlob(regionId, z, x, y, blob);
                completedTiles++;
              } else {
                failedTiles++;
              }
            } catch (err) {
              if (err.name === 'AbortError') throw err;
              failedTiles++;
            }
          })
        );

        const percentage = Math.round(((completedTiles + failedTiles) / totalTiles) * 100);
        onProgress({
          status: 'downloading',
          current: completedTiles + failedTiles,
          total: totalTiles,
          completed: completedTiles,
          failed: failedTiles,
          percentage,
          bytesDownloaded: totalBytes,
          mbDownloaded: (totalBytes / (1024 * 1024)).toFixed(2),
          stage: `Fetching tiles (${completedTiles}/${totalTiles})...`
        });

        // Small pause between chunks to be polite to tile infrastructure
        await new Promise(r => setTimeout(r, 60));
      }

      // Save road routes destination -> each tourist place, so paths work offline after arrival
      let routesSaved = 0;
      try {
        routesSaved = await precacheRoutesForRegion({
          regionId,
          origin: [centerLat, centerLon],
          pois: regionPois,
          signal: abortController.signal,
          onProgress: ({ done, total }) =>
            onProgress({
              status: 'downloading',
              current: totalTiles,
              total: totalTiles,
              percentage: 100,
              bytesDownloaded: totalBytes,
              mbDownloaded: (totalBytes / (1024 * 1024)).toFixed(2),
              stage: `Saving offline routes (${done}/${total})...`
            })
        });
      } catch (routeErr) {
        console.warn('[download] route pre-caching skipped:', routeErr.message);
      }

      // Finalize map metadata
      const mapMetadata = {
        id: regionId,
        destinationId,
        regionName,
        centerLat,
        centerLon,
        radiusKm,
        minZoom: estimates.minZoom,
        maxZoom: estimates.maxZoom,
        tileCount: completedTiles,
        failedTileCount: failedTiles,
        storageBytes: totalBytes,
        storageMB: (totalBytes / (1024 * 1024)).toFixed(2),
        poiCount: regionPois.length,
        routeCount: routesSaved,
        downloadedAt: new Date().toISOString(),
        status: failedTiles > (totalTiles / 2) ? 'partial' : 'completed',
        coverageBbox: bbox
      };

      await saveDownloadedMap(mapMetadata);

      onProgress({
        status: 'completed',
        current: totalTiles,
        total: totalTiles,
        percentage: 100,
        bytesDownloaded: totalBytes,
        mbDownloaded: mapMetadata.storageMB,
        stage: 'Region successfully downloaded and stored offline!'
      });

      this.activeDownloads.delete(regionId);
      return mapMetadata;
    } catch (err) {
      this.activeDownloads.delete(regionId);
      if (err.name === 'AbortError') {
        onProgress({ status: 'cancelled', stage: 'Download was cancelled.' });
      } else {
        onProgress({ status: 'failed', stage: `Download failed: ${err.message}` });
      }
      throw err;
    }
  }

  cancelDownload(regionId) {
    if (this.activeDownloads.has(regionId)) {
      const controller = this.activeDownloads.get(regionId);
      controller.abort();
      this.activeDownloads.delete(regionId);
      return true;
    }
    return false;
  }

  isDownloading(regionId) {
    return this.activeDownloads.has(regionId);
  }
}

export const downloadManager = new DownloadManager();
