/**
 * RoamReady road routing with offline support.
 *
 * Map tiles only draw pictures; they contain no road graph, so a route can't be
 * calculated offline. Instead we:
 *   1. ONLINE  -> ask a routing engine (OSRM) for the road route and SAVE it in IndexedDB.
 *   2. OFFLINE -> replay a saved route (exact match, or one that starts near the tourist).
 *   3. NOTHING SAVED -> straight line + compass bearing + distance, so the user always has direction.
 *
 * During region download we pre-compute routes destination -> every tourist place,
 * so "nearest famous place with path" works with zero network after arrival.
 */

import { calculateHaversineDistance } from './geo';
import { saveRoute, getSavedRoute, getSavedRoutesToDestination } from './storage';

// NOTE: the public OSRM demo server is for light use only. For production, host your own
// OSRM/Valhalla/GraphHopper or use a hosted service with an API key, and change this URL.
const OSRM_BASE_URL = 'https://router.project-osrm.org';
const MAX_JOIN_KM = 3; // a saved route is reused if it starts within this distance of the tourist

const toRad = (d) => (d * Math.PI) / 180;
const toDeg = (r) => (r * 180) / Math.PI;

export function bearingDegrees(lat1, lon1, lat2, lon2) {
  const dLon = toRad(lon2 - lon1);
  const y = Math.sin(dLon) * Math.cos(toRad(lat2));
  const x =
    Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
    Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(dLon);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

export function compassPoint(deg) {
  const points = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  return points[Math.round(deg / 45) % 8];
}

async function fetchOsrmRoute(from, to, signal) {
  // OSRM wants {lon},{lat}
  const url =
    `${OSRM_BASE_URL}/route/v1/driving/${from[1]},${from[0]};${to[1]},${to[0]}` +
    `?overview=full&geometries=geojson&steps=true`;
  const res = await fetch(url, { signal });
  if (!res.ok) throw new Error(`Routing server returned ${res.status}`);
  const data = await res.json();
  if (data.code !== 'Ok' || !data.routes?.length) throw new Error('No road route found');

  const route = data.routes[0];
  const steps = (route.legs?.[0]?.steps || []).map((st) => ({
    instruction: st.maneuver?.type
      ? `${st.maneuver.type}${st.maneuver.modifier ? ' ' + st.maneuver.modifier : ''}${st.name ? ' onto ' + st.name : ''}`
      : st.name || '',
    distanceKm: Number((st.distance / 1000).toFixed(2))
  }));

  return {
    coordinates: route.geometry.coordinates.map((c) => [c[1], c[0]]), // -> Leaflet [lat, lon]
    distanceKm: Number((route.distance / 1000).toFixed(2)),
    durationMin: Math.max(1, Math.round(route.duration / 60)),
    steps
  };
}

function straightLineRoute(from, to) {
  const km = calculateHaversineDistance(from[0], from[1], to[0], to[1], 'km');
  const bearing = bearingDegrees(from[0], from[1], to[0], to[1]);
  return {
    source: 'straight-line',
    coordinates: [from, to],
    distanceKm: Number(km.toFixed(2)),
    durationMin: Math.max(1, Math.round((km / 30) * 60)), // rough 30 km/h
    steps: [],
    bearing: Math.round(bearing),
    compass: compassPoint(bearing)
  };
}

/**
 * Get a route from -> to.
 * @param {[number, number]} from [lat, lon]
 * @param {[number, number]} to   [lat, lon]
 * @returns {Promise<{source:'live'|'saved'|'saved-nearby'|'straight-line', coordinates, distanceKm, durationMin, steps, bearing?, compass?}>}
 */
async function getRouteCore({ from, to, regionId = null, online = navigator.onLine }) {
  // 1) Online: live road route, then save it for offline use
  if (online) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const live = await fetchOsrmRoute(from, to, controller.signal);
      clearTimeout(timer);
      await saveRoute({ from, to, regionId, ...live });
      return { source: 'live', ...live };
    } catch (err) {
      console.warn('[routing] live route failed, trying saved routes:', err.message);
    }
  }

  // 2) Saved route with the same start and end
  const exact = await getSavedRoute(from, to);
  if (exact) {
    return {
      source: 'saved',
      coordinates: exact.coordinates,
      distanceKm: exact.distanceKm,
      durationMin: exact.durationMin,
      steps: exact.steps || []
    };
  }

  // 3) Saved route to the same place that starts near the tourist (e.g. precomputed from the destination centre)
  const candidates = await getSavedRoutesToDestination(to);
  let best = null;
  let bestGap = Infinity;
  for (const r of candidates) {
    const gap = calculateHaversineDistance(from[0], from[1], r.from[0], r.from[1], 'km');
    if (gap < bestGap) {
      best = r;
      bestGap = gap;
    }
  }
  if (best && bestGap <= MAX_JOIN_KM) {
    return {
      source: 'saved-nearby',
      coordinates: best.coordinates,
      distanceKm: best.distanceKm,
      durationMin: best.durationMin,
      steps: best.steps || [],
      joinedFromKm: Number(bestGap.toFixed(2))
    };
  }

  // 4) Nothing saved: direction only
  return straightLineRoute(from, to);
}

/**
 * Routing engines snap the start/end to the nearest ROAD. If the tourist is standing off-road
 * (forest, trail, viewpoint), the road route starts somewhere else. We add dashed connectors
 * from the real GPS position to the route start (and from the route end to the place), and
 * report how far the nearest road is.
 */
function addOffRoadConnectors(route, from, to) {
  if (route.source === 'straight-line' || !route.coordinates?.length) {
    return { ...route, connectors: [], startGapKm: 0, endGapKm: 0 };
  }
  const first = route.coordinates[0];
  const last = route.coordinates[route.coordinates.length - 1];
  const startGap = calculateHaversineDistance(from[0], from[1], first[0], first[1], 'km');
  const endGap = calculateHaversineDistance(last[0], last[1], to[0], to[1], 'km');
  const connectors = [];
  if (startGap > 0.03) connectors.push([from, first]);
  if (endGap > 0.03) connectors.push([last, to]);
  return {
    ...route,
    connectors,
    startGapKm: Number(startGap.toFixed(2)),
    endGapKm: Number(endGap.toFixed(2)),
    distanceKm: Number((route.distanceKm + startGap + endGap).toFixed(2))
  };
}

export async function getRoute(opts) {
  const route = await getRouteCore(opts);
  return addOffRoadConnectors(route, opts.from, opts.to);
}

/**
 * Pre-compute and save routes origin -> each POI. Call this while ONLINE (during region download).
 * Sequential with a small delay to be polite to the routing server. Failures are skipped.
 */
export async function precacheRoutesForRegion({ regionId, origin, pois, onProgress = () => {}, signal, limit = 25 }) {
  const targets = pois.slice(0, limit);
  let saved = 0;

  for (let i = 0; i < targets.length; i++) {
    if (signal?.aborted) break;
    const poi = targets[i];
    try {
      const to = [poi.latitude, poi.longitude];
      const live = await fetchOsrmRoute(origin, to, signal);
      await saveRoute({ from: origin, to, regionId, ...live });
      saved++;
    } catch (err) {
      if (err.name === 'AbortError') break;
      // one failed route should never fail the whole download
    }
    onProgress({ done: i + 1, total: targets.length, saved });
    await new Promise((r) => setTimeout(r, 250));
  }
  return saved;
}
