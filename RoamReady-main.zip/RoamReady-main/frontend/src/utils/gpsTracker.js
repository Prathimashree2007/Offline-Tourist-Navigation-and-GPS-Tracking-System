/**
 * RoamReady GPS Tracker & Trail Recorder
 * Manages high-accuracy Geolocation watch, pause/resume, route point filtering,
 * live trip calculations, and an academic presentation demo simulator.
 */

import { calculateHaversineDistance, isValidGpsPoint, calculateTripSummary } from './geo';
import { saveTrip } from './storage';

class GpsTracker {
  constructor() {
    this.watchId = null;
    this.isTracking = false;
    this.isPaused = false;
    this.isDemoMode = false;
    this.demoInterval = null;

    this.points = [];
    this.currentLocation = null;
    this.lastValidPoint = null;
    this.startTime = null;
    this.tripName = '';
    this.destinationName = '';

    this.listeners = {
      onPoint: null,
      onStatusChange: null,
      onError: null
    };
  }

  startTracking({
    tripName = 'Trail Exploration',
    destinationName = 'Wilderness Route',
    useDemo = false,
    lowPower = false,
    demoStartCoords = [12.4244, 75.7382], // Default Madikeri
    onPoint = () => {},
    onStatusChange = () => {},
    onError = () => {}
  }) {
    if (this.isTracking) return;

    this.points = [];
    this.tripName = tripName;
    this.destinationName = destinationName;
    this.startTime = new Date().toISOString();
    this.isTracking = true;
    this.isPaused = false;
    this.isDemoMode = useDemo;
    this.lastValidPoint = null;
    this.lowPower = lowPower;
    this.lastSavedAt = 0;

    this.listeners = { onPoint, onStatusChange, onError };
    this.notifyStatus();

    if (useDemo) {
      this._startDemoSimulation(demoStartCoords);
    } else {
      this._startRealGeolocation();
    }
  }

  _startRealGeolocation() {
    if (!('geolocation' in navigator)) {
      this.listeners.onError?.('Geolocation API is not supported on this browser/device.');
      return;
    }

    // Battery saver: network/cell location and a point at most every 15 s
    const options = {
      enableHighAccuracy: !this.lowPower,
      timeout: 20000,
      maximumAge: this.lowPower ? 15000 : 1000
    };

    this.watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (this.isPaused) return;
        if (this.lowPower && Date.now() - this.lastSavedAt < 15000) return;
        this.lastSavedAt = Date.now();

        const newPoint = {
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          altitude: pos.coords.altitude || null,
          accuracy: Math.round(pos.coords.accuracy || 10),
          speed: pos.coords.speed ? Math.round(pos.coords.speed * 3.6) : null,
          timestamp: new Date(pos.timestamp || Date.now()).toISOString()
        };

        this.currentLocation = newPoint;

        // Apply jump filtering
        if (isValidGpsPoint(newPoint, this.lastValidPoint)) {
          this.points.push(newPoint);
          this.lastValidPoint = newPoint;
          this.listeners.onPoint?.(newPoint, [...this.points]);
        }
      },
      (err) => {
        let msg = 'Failed to acquire GPS location.';
        if (err.code === 1) msg = 'Location access denied. Please grant GPS permission.';
        if (err.code === 2) msg = 'GPS signal lost or unavailable.';
        if (err.code === 3) msg = 'GPS request timed out.';
        this.listeners.onError?.(msg);
      },
      options
    );
  }

  _startDemoSimulation(startCoords) {
    let [lat, lon] = startCoords;
    let step = 0;
    // Trail offsets simulating a scenic walk towards a waterfall
    const deltas = [
      [0.0003, 0.0002],
      [0.0004, 0.0001],
      [0.0002, 0.0004],
      [0.0005, 0.0002],
      [0.0003, 0.0005],
      [0.0002, 0.0006],
      [0.0004, 0.0003],
      [0.0006, 0.0002],
      [0.0003, 0.0004]
    ];

    this.demoInterval = setInterval(() => {
      if (this.isPaused) return;

      const delta = deltas[step % deltas.length];
      lat += delta[0];
      lon += delta[1];
      step++;

      const demoPoint = {
        latitude: Number(lat.toFixed(6)),
        longitude: Number(lon.toFixed(6)),
        altitude: 1040 + Math.round(Math.sin(step) * 15),
        accuracy: 4,
        speed: 4.8, // Walking speed in km/h
        timestamp: new Date().toISOString()
      };

      this.currentLocation = demoPoint;
      this.points.push(demoPoint);
      this.lastValidPoint = demoPoint;
      this.listeners.onPoint?.(demoPoint, [...this.points]);
    }, 2500);
  }

  pauseTracking() {
    if (!this.isTracking || this.isPaused) return;
    this.isPaused = true;
    this.notifyStatus();
  }

  resumeTracking() {
    if (!this.isTracking || !this.isPaused) return;
    this.isPaused = false;
    this.notifyStatus();
  }

  async stopTracking() {
    if (!this.isTracking) return null;

    if (this.watchId !== null) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    if (this.demoInterval) {
      clearInterval(this.demoInterval);
      this.demoInterval = null;
    }

    this.isTracking = false;
    this.isPaused = false;
    this.notifyStatus();

    if (this.points.length === 0) return null;

    const summary = calculateTripSummary(this.points);
    const tripRecord = {
      id: 'trip_' + Date.now(),
      name: this.tripName || `Trip to ${this.destinationName}`,
      destinationName: this.destinationName,
      startLat: this.points[0].latitude,
      startLon: this.points[0].longitude,
      endLat: this.points[this.points.length - 1].latitude,
      endLon: this.points[this.points.length - 1].longitude,
      startedAt: this.startTime,
      endedAt: new Date().toISOString(),
      distanceKm: summary.totalDistanceKm,
      durationSeconds: summary.totalDurationSeconds,
      avgSpeedKmh: summary.averageSpeedKmh,
      maxSpeedKmh: summary.maxSpeedKmh,
      pointCount: this.points.length,
      points: this.points,
      isDemo: this.isDemoMode
    };

    await saveTrip(tripRecord);
    return tripRecord;
  }

  notifyStatus() {
    this.listeners.onStatusChange?.({
      isTracking: this.isTracking,
      isPaused: this.isPaused,
      isDemo: this.isDemoMode,
      pointCount: this.points.length,
      currentLocation: this.currentLocation
    });
  }
}

export const gpsTracker = new GpsTracker();
