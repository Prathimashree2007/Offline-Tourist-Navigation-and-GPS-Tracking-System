/**
 * RoamReady IndexedDB Persistence Layer
 * Provides robust offline storage for tiles, tourist places, travel history, and metadata.
 */

import { openDB } from 'idb';

const DB_NAME = 'roamready_local_db';
const DB_VERSION = 4;

export async function getDB() {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db, oldVersion) {
      // 1. Downloaded regions metadata
      if (!db.objectStoreNames.contains('downloaded_maps')) {
        const mapStore = db.createObjectStore('downloaded_maps', { keyPath: 'id' });
        mapStore.createIndex('by_date', 'downloadedAt');
      }

      // 2. Offline map tile binary blobs (key: `${regionId}_${z}_${x}_${y}`)
      if (!db.objectStoreNames.contains('map_tiles')) {
        const tileStore = db.createObjectStore('map_tiles', { keyPath: 'tileKey' });
        tileStore.createIndex('by_region', 'regionId');
      }

      // 3. Downloaded POIs (waterfalls, viewpoints, hills, hospitals, etc.)
      if (!db.objectStoreNames.contains('tourist_places')) {
        const poiStore = db.createObjectStore('tourist_places', { keyPath: 'id' });
        poiStore.createIndex('by_region', 'regionId');
        poiStore.createIndex('by_category', 'category');
      }

      // 4. GPS Travel History & Track Waypoints
      if (!db.objectStoreNames.contains('travel_history')) {
        const tripStore = db.createObjectStore('travel_history', { keyPath: 'id' });
        tripStore.createIndex('by_date', 'startedAt');
      }

      // 5. User Favourites
      if (!db.objectStoreNames.contains('favourites')) {
        db.createObjectStore('favourites', { keyPath: 'id' });
      }

      // 6. User Settings (theme, unit preference, GPS accuracy filter)
      if (!db.objectStoreNames.contains('app_settings')) {
        db.createObjectStore('app_settings', { keyPath: 'key' });
      }

      // 7. Dynamically saved worldwide destinations
      if (!db.objectStoreNames.contains('saved_destinations')) {
        const destStore = db.createObjectStore('saved_destinations', { keyPath: 'id' });
        destStore.createIndex('by_date', 'savedAt');
      }

      // 8. Road routes saved for offline use (added in DB v3)
      if (!db.objectStoreNames.contains('cached_routes')) {
        const routeStore = db.createObjectStore('cached_routes', { keyPath: 'id' });
        routeStore.createIndex('by_region', 'regionId');
        routeStore.createIndex('by_dest', 'destKey');
      }

      // 9. Tourist's own pins: hotel, parking, viewpoint... (added in DB v4)
      if (!db.objectStoreNames.contains('my_pins')) {
        const pinStore = db.createObjectStore('my_pins', { keyPath: 'id' });
        pinStore.createIndex('by_date', 'createdAt');
      }
    },
  });
}

// ----------------- MAP REGIONS -----------------

export async function saveDownloadedMap(mapMeta) {
  const db = await getDB();
  return db.put('downloaded_maps', {
    ...mapMeta,
    updatedAt: new Date().toISOString()
  });
}

export async function getAllDownloadedMaps() {
  const db = await getDB();
  return db.getAllFromIndex('downloaded_maps', 'by_date');
}

export async function getDownloadedMap(id) {
  const db = await getDB();
  return db.get('downloaded_maps', id);
}

export async function deleteDownloadedMap(id) {
  const db = await getDB();
  const tx = db.transaction(['downloaded_maps', 'map_tiles', 'tourist_places', 'cached_routes'], 'readwrite');
  
  // Delete map metadata
  await tx.objectStore('downloaded_maps').delete(id);

  // Delete all tile blobs belonging to this region
  const tileIndex = tx.objectStore('map_tiles').index('by_region');
  let tileCursor = await tileIndex.openKeyCursor(IDBKeyRange.only(id));
  while (tileCursor) {
    await tx.objectStore('map_tiles').delete(tileCursor.primaryKey);
    tileCursor = await tileCursor.continue();
  }

  // Delete all POIs belonging to this region
  const poiIndex = tx.objectStore('tourist_places').index('by_region');
  let poiCursor = await poiIndex.openKeyCursor(IDBKeyRange.only(id));
  while (poiCursor) {
    await tx.objectStore('tourist_places').delete(poiCursor.primaryKey);
    poiCursor = await poiCursor.continue();
  }

  // Delete saved routes belonging to this region
  const routeIndex = tx.objectStore('cached_routes').index('by_region');
  let routeCursor = await routeIndex.openKeyCursor(IDBKeyRange.only(id));
  while (routeCursor) {
    await tx.objectStore('cached_routes').delete(routeCursor.primaryKey);
    routeCursor = await routeCursor.continue();
  }

  await tx.done;
  return true;
}

export async function deleteAllDownloadedMaps() {
  const db = await getDB();
  const tx = db.transaction(['downloaded_maps', 'map_tiles', 'tourist_places', 'cached_routes'], 'readwrite');
  await tx.objectStore('downloaded_maps').clear();
  await tx.objectStore('map_tiles').clear();
  await tx.objectStore('tourist_places').clear();
  await tx.objectStore('cached_routes').clear();
  await tx.done;
  return true;
}

// ----------------- TILE STORAGE -----------------

export async function saveTileBlob(regionId, z, x, y, blob) {
  const db = await getDB();
  const tileKey = `${regionId}_${z}_${x}_${y}`;
  return db.put('map_tiles', {
    tileKey,
    regionId,
    z,
    x,
    y,
    blob,
    size: blob.size,
    savedAt: Date.now()
  });
}

export async function getTileBlob(regionId, z, x, y) {
  const db = await getDB();
  const tileKey = `${regionId}_${z}_${x}_${y}`;
  const entry = await db.get('map_tiles', tileKey);
  return entry ? entry.blob : null;
}

/**
 * Searches across ANY downloaded region for a matching tile at zoom z, x, y
 */
export async function findAnyTileBlob(z, x, y) {
  const db = await getDB();
  const allTiles = await db.getAll('map_tiles');
  const match = allTiles.find(t => t.z === z && t.x === x && t.y === y);
  return match ? match.blob : null;
}

// ----------------- TOURIST POIS -----------------

export async function saveTouristPlaces(places) {
  const db = await getDB();
  const tx = db.transaction('tourist_places', 'readwrite');
  for (const place of places) {
    await tx.store.put(place);
  }
  await tx.done;
}

export async function getTouristPlaces(regionId = null, category = null) {
  const db = await getDB();
  let places = [];
  if (regionId) {
    places = await db.getAllFromIndex('tourist_places', 'by_region', regionId);
  } else {
    places = await db.getAll('tourist_places');
  }

  if (category && category !== 'all') {
    places = places.filter(p => p.category === category);
  }
  return places;
}

// ----------------- TRAVEL HISTORY -----------------

export async function saveTrip(trip) {
  const db = await getDB();
  return db.put('travel_history', {
    ...trip,
    savedAt: new Date().toISOString()
  });
}

export async function getAllTrips() {
  const db = await getDB();
  const trips = await db.getAllFromIndex('travel_history', 'by_date');
  return trips.reverse(); // Newest first
}

export async function getTripById(id) {
  const db = await getDB();
  return db.get('travel_history', id);
}

export async function deleteTrip(id) {
  const db = await getDB();
  return db.delete('travel_history', id);
}

export async function deleteAllTrips() {
  const db = await getDB();
  return db.clear('travel_history');
}

// ----------------- FAVOURITES -----------------

export async function toggleFavourite(place) {
  const db = await getDB();
  const existing = await db.get('favourites', place.id);
  if (existing) {
    await db.delete('favourites', place.id);
    return false;
  } else {
    await db.put('favourites', {
      ...place,
      addedAt: new Date().toISOString()
    });
    return true;
  }
}

export async function getFavourites() {
  const db = await getDB();
  return db.getAll('favourites');
}

export async function isFavourite(id) {
  const db = await getDB();
  const item = await db.get('favourites', id);
  return !!item;
}

// ----------------- APP SETTINGS -----------------

export async function getSetting(key, defaultValue = null) {
  const db = await getDB();
  const entry = await db.get('app_settings', key);
  return entry ? entry.value : defaultValue;
}

export async function setSetting(key, value) {
  const db = await getDB();
  return db.put('app_settings', { key, value });
}

// ----------------- DYNAMIC SAVED DESTINATIONS -----------------

export async function saveLocalDestination(dest) {
  const db = await getDB();
  const id = dest.id || `loc_${Date.now()}`;
  const entry = {
    ...dest,
    id,
    savedAt: new Date().toISOString()
  };
  await db.put('saved_destinations', entry);
  return entry;
}

export async function getAllLocalDestinations() {
  const db = await getDB();
  return db.getAllFromIndex('saved_destinations', 'by_date');
}

export async function deleteLocalDestination(id) {
  const db = await getDB();
  return db.delete('saved_destinations', id);
}

// ----------------- STORAGE AUDIT -----------------

export async function getStorageStats() {
  const db = await getDB();
  const maps = await db.getAll('downloaded_maps');
  const tiles = await db.getAll('map_tiles');
  const places = await db.getAll('tourist_places');
  const trips = await db.getAll('travel_history');

  let totalTileBytes = 0;
  for (const t of tiles) {
    totalTileBytes += t.size || 25000;
  }

  let quotaEstimate = { quota: 0, usage: 0 };
  if (navigator.storage && navigator.storage.estimate) {
    try {
      quotaEstimate = await navigator.storage.estimate();
    } catch {
      // ignore
    }
  }

  return {
    mapCount: maps.length,
    tileCount: tiles.length,
    poiCount: places.length,
    tripCount: trips.length,
    totalTileBytes,
    totalTileMB: (totalTileBytes / (1024 * 1024)).toFixed(2),
    quotaMB: quotaEstimate.quota ? (quotaEstimate.quota / (1024 * 1024)).toFixed(0) : 'N/A',
    usageMB: quotaEstimate.usage ? (quotaEstimate.usage / (1024 * 1024)).toFixed(1) : (totalTileBytes / (1024 * 1024)).toFixed(1)
  };
}

// ----------------- SAVED ROUTES (offline road routing) -----------------

const roundKey = (lat, lon) => `${Number(lat).toFixed(3)},${Number(lon).toFixed(3)}`;

export function makeRouteId(from, to) {
  return `${roundKey(from[0], from[1])}|${roundKey(to[0], to[1])}`;
}

export async function saveRoute({ from, to, regionId = null, coordinates, distanceKm, durationMin, steps = [] }) {
  const db = await getDB();
  const record = {
    id: makeRouteId(from, to),
    regionId,
    destKey: roundKey(to[0], to[1]),
    from,
    to,
    coordinates,
    distanceKm,
    durationMin,
    steps,
    savedAt: new Date().toISOString()
  };
  await db.put('cached_routes', record);
  return record;
}

export async function getSavedRoute(from, to) {
  const db = await getDB();
  return (await db.get('cached_routes', makeRouteId(from, to))) || null;
}

/** All saved routes that end at `to` (used to find one that starts near the tourist). */
export async function getSavedRoutesToDestination(to) {
  const db = await getDB();
  return db.getAllFromIndex('cached_routes', 'by_dest', roundKey(to[0], to[1]));
}

// ----------------- MY PINS (user-dropped places, fully offline) -----------------

export async function savePin({ name, type = 'other', latitude, longitude, regionId = null }) {
  const db = await getDB();
  const pin = {
    id: `pin_${Date.now()}`,
    name: name.trim(),
    type,
    latitude,
    longitude,
    regionId,
    createdAt: new Date().toISOString()
  };
  await db.put('my_pins', pin);
  return pin;
}

export async function getAllPins() {
  const db = await getDB();
  const pins = await db.getAll('my_pins');
  return pins.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function deletePin(id) {
  const db = await getDB();
  await db.delete('my_pins', id);
}
