/**
 * RoamReady GIS and Mathematical Utilities
 * Implements Haversine distance, bounding box, tile pyramids, and GPS point filtering.
 */

const EARTH_RADIUS_KM = 6371.0;
const EARTH_RADIUS_MILES = 3958.8;

/**
 * Calculates straight-line great-circle distance between two GPS coordinates using Haversine formula.
 * @param {number} lat1 Latitude of point 1
 * @param {number} lon1 Longitude of point 1
 * @param {number} lat2 Latitude of point 2
 * @param {number} lon2 Longitude of point 2
 * @param {'km'|'miles'} unit Distance unit
 * @returns {number} Distance in chosen unit
 */
export function calculateHaversineDistance(lat1, lon1, lat2, lon2, unit = 'km') {
  if (lat1 === lat2 && lon1 === lon2) return 0;

  const toRad = (deg) => (deg * Math.PI) / 180.0;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const radLat1 = toRad(lat1);
  const radLat2 = toRad(lat2);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(radLat1) * Math.cos(radLat2) * Math.sin(dLon / 2) * Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const radius = unit === 'miles' ? EARTH_RADIUS_MILES : EARTH_RADIUS_KM;

  return radius * c;
}

/**
 * Human-friendly distance formatter.
 * @param {number} distanceKm Distance in kilometers
 * @param {'km'|'miles'} unit Unit
 * @returns {string} Formatted string e.g. "450 m" or "12.4 km"
 */
export function formatDistance(distanceKm, unit = 'km') {
  if (distanceKm === null || distanceKm === undefined || isNaN(distanceKm)) {
    return '--';
  }

  if (unit === 'miles') {
    const miles = distanceKm * 0.621371;
    if (miles < 0.1) {
      return `${Math.round(miles * 5280)} ft`;
    }
    return `${miles.toFixed(1)} mi`;
  }

  // Metric
  if (distanceKm < 1.0) {
    return `${Math.round(distanceKm * 1000)} m`;
  }
  return `${distanceKm.toFixed(1)} km`;
}

/**
 * Computes the bounding box [minLat, minLon, maxLat, maxLon] around a center point for a given radius.
 * @param {number} lat Center latitude
 * @param {number} lon Center longitude
 * @param {number} radiusKm Radius in kilometers
 */
export function calculateBoundingBox(lat, lon, radiusKm) {
  const latDelta = radiusKm / 111.0; // 1 deg lat approx 111 km
  const lonDelta = radiusKm / (111.0 * Math.cos((lat * Math.PI) / 180.0));

  return {
    minLat: lat - latDelta,
    maxLat: lat + latDelta,
    minLon: lon - lonDelta,
    maxLon: lon + lonDelta,
    radiusKm,
    center: [lat, lon]
  };
}

/**
 * Checks whether a target point is within the download radius circle.
 */
export function isPointInRadius(centerLat, centerLon, targetLat, targetLon, radiusKm) {
  const dist = calculateHaversineDistance(centerLat, centerLon, targetLat, targetLon, 'km');
  return dist <= radiusKm;
}

/**
 * Converts latitude and longitude to Slippy Map tile numbers (X, Y) for a given zoom level.
 */
export function latLonToTile(lat, lon, zoom) {
  const x = Math.floor(((lon + 180) / 360) * Math.pow(2, zoom));
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor(
    ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) * Math.pow(2, zoom)
  );
  return { x, y, z: zoom };
}

/**
 * Generates all tile coordinate triplets {x, y, z} within a bounding box for given zoom levels.
 */
export function getTilesInBoundingBox(bbox, minZoom = 12, maxZoom = 14) {
  const tiles = [];
  for (let z = minZoom; z <= maxZoom; z++) {
    const p1 = latLonToTile(bbox.maxLat, bbox.minLon, z);
    const p2 = latLonToTile(bbox.minLat, bbox.maxLon, z);

    const minX = Math.min(p1.x, p2.x);
    const maxX = Math.max(p1.x, p2.x);
    const minY = Math.min(p1.y, p2.y);
    const maxY = Math.max(p1.y, p2.y);

    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        tiles.push({ x, y, z });
      }
    }
  }
  return tiles;
}

/**
 * Accurately estimates storage size and tile counts for radius selection.
 * @param {number} radiusKm 5, 10, 25, 50 km
 */
export function estimateStorageSize(radiusKm) {
  // Tile estimates and zoom limits tailored for fast, safe regional downloads
  if (radiusKm <= 5) {
    return {
      radiusKm,
      minZoom: 12,
      maxZoom: 15,
      estimatedTiles: 48,
      approxStorageMB: 1.8,
      downloadTimeSec: 4
    };
  }
  if (radiusKm <= 10) {
    return {
      radiusKm,
      minZoom: 12,
      maxZoom: 14,
      estimatedTiles: 96,
      approxStorageMB: 3.5,
      downloadTimeSec: 7
    };
  }
  if (radiusKm <= 25) {
    return {
      radiusKm,
      minZoom: 11,
      maxZoom: 14,
      estimatedTiles: 210,
      approxStorageMB: 8.2,
      downloadTimeSec: 14
    };
  }
  // 50 km extended option
  return {
    radiusKm,
    minZoom: 11,
    maxZoom: 13,
    estimatedTiles: 380,
    approxStorageMB: 15.4,
    downloadTimeSec: 25
  };
}

/**
 * Filters out erroneous GPS jumps / noise (e.g. tunnel exit, multipath reflection).
 * Returns true if point is physically plausible.
 */
export function isValidGpsPoint(newPoint, lastPoint, maxSpeedKmh = 120) {
  if (!lastPoint) return true;
  if (!newPoint.latitude || !newPoint.longitude) return false;

  // Filter out excessive accuracy error (greater than 60m)
  if (newPoint.accuracy && newPoint.accuracy > 60) {
    return false;
  }

  const timeDiffSec = (new Date(newPoint.timestamp).getTime() - new Date(lastPoint.timestamp).getTime()) / 1000;
  if (timeDiffSec <= 0) return false;

  const distKm = calculateHaversineDistance(
    lastPoint.latitude,
    lastPoint.longitude,
    newPoint.latitude,
    newPoint.longitude,
    'km'
  );

  const speedKmh = (distKm / timeDiffSec) * 3600;
  return speedKmh <= maxSpeedKmh;
}

/**
 * Calculates complete trip summary from track points.
 */
export function calculateTripSummary(points) {
  if (!points || points.length === 0) {
    return {
      totalDistanceKm: 0,
      totalDurationSeconds: 0,
      averageSpeedKmh: 0,
      maxSpeedKmh: 0,
      pointCount: 0
    };
  }

  let totalDistanceKm = 0;
  let maxSpeedKmh = 0;

  for (let i = 1; i < points.length; i++) {
    const p1 = points[i - 1];
    const p2 = points[i];
    const segmentDist = calculateHaversineDistance(p1.latitude, p1.longitude, p2.latitude, p2.longitude, 'km');
    totalDistanceKm += segmentDist;

    const dtHours = (new Date(p2.timestamp).getTime() - new Date(p1.timestamp).getTime()) / (1000 * 3600);
    if (dtHours > 0) {
      const segSpeed = segmentDist / dtHours;
      if (segSpeed > maxSpeedKmh && segSpeed < 120) {
        maxSpeedKmh = segSpeed;
      }
    }
  }

  const startTime = new Date(points[0].timestamp).getTime();
  const endTime = new Date(points[points.length - 1].timestamp).getTime();
  const totalDurationSeconds = Math.max(1, Math.round((endTime - startTime) / 1000));
  const totalHours = totalDurationSeconds / 3600;
  const averageSpeedKmh = totalHours > 0 ? totalDistanceKm / totalHours : 0;

  return {
    totalDistanceKm: Number(totalDistanceKm.toFixed(3)),
    totalDurationSeconds,
    averageSpeedKmh: Number(averageSpeedKmh.toFixed(1)),
    maxSpeedKmh: Number(maxSpeedKmh.toFixed(1)),
    pointCount: points.length,
    startedAt: points[0].timestamp,
    endedAt: points[points.length - 1].timestamp
  };
}
