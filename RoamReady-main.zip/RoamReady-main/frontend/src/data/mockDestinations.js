/**
 * Curated Tourist Destinations and Offline POI Data
 * Serves as rich baseline data for online search, offline pre-caching, and academic evaluation.
 */

export const DESTINATIONS_CATALOG = [
  {
    id: 'coorg-madikeri',
    name: 'Madikeri (Coorg)',
    regionName: 'Coorg Western Ghats',
    state: 'Karnataka',
    country: 'India',
    latitude: 12.4244,
    longitude: 75.7382,
    category: 'hills',
    difficulty: 'easy',
    bestSeason: 'October - March',
    bannerImage: 'https://images.unsplash.com/photo-1596422846543-75c6fc197f07?auto=format&fit=crop&w=1000&q=80',
    description: 'Picturesque hill town enveloped in misty coffee plantations, spices, rolling emerald peaks, and tranquil colonial charm.',
    pois: [
      {
        id: 'poi-abbey-falls',
        name: 'Abbey Falls',
        category: 'waterfalls',
        latitude: 12.4542,
        longitude: 75.7196,
        description: 'Roaring waterfall cascading from 70 ft into a rocky ravine surrounded by private coffee and spice plantations.',
        emergencyContact: 'Madikeri Emergency: 112 / +91-8272-228333',
        offlineAvailable: true
      },
      {
        id: 'poi-rajas-seat',
        name: "Raja's Seat Sunset Viewpoint",
        category: 'viewpoints',
        latitude: 12.4182,
        longitude: 75.7371,
        description: 'Historic scenic terrace where Kodagu kings enjoyed sunsets over misty layered valleys and musical fountains.',
        emergencyContact: 'District Police: 100',
        offlineAvailable: true
      },
      {
        id: 'poi-mandalpatti',
        name: 'Mandalpatti Peak Ridge',
        category: 'hills',
        latitude: 12.5028,
        longitude: 75.7297,
        description: 'Spectacular windswept mountain ridge offering 360-degree views of Pushpagiri Wildlife Sanctuary. 4x4 Jeep trail.',
        emergencyContact: 'Forest Checkpost: +91-8272-228400',
        offlineAvailable: true
      },
      {
        id: 'poi-omkareshwara',
        name: 'Omkareshwara Ancient Temple',
        category: 'temples',
        latitude: 12.4239,
        longitude: 75.7428,
        description: 'Built in 1820 featuring a blend of Gothic and Islamic architecture with a freshwater fish pond in the center.',
        emergencyContact: 'Madikeri Town Station: +91-8272-228222',
        offlineAvailable: true
      },
      {
        id: 'poi-madikeri-hospital',
        name: 'District Government Hospital Madikeri',
        category: 'emergency',
        latitude: 12.4271,
        longitude: 75.7356,
        description: '24/7 Casualty, trauma care, ambulance service, and pharmacy for travellers and residents.',
        emergencyContact: 'Ambulance: 108 / Casualty: +91-8272-225225',
        offlineAvailable: true
      },
      {
        id: 'poi-dubare',
        name: 'Dubare Forest & River Camp',
        category: 'nature',
        latitude: 12.3686,
        longitude: 75.9048,
        description: 'Elephant conservation sanctuary situated on the serene banks of the Cauvery River with nature walks.',
        emergencyContact: 'River Patrol / Checkpost: +91-8276-274200',
        offlineAvailable: true
      }
    ]
  },
  {
    id: 'chikmagalur',
    name: 'Chikmagalur (Mullayanagiri)',
    regionName: 'Chikmagalur High Ranges',
    state: 'Karnataka',
    country: 'India',
    latitude: 13.3912,
    longitude: 75.7214,
    category: 'hills',
    difficulty: 'challenging',
    bestSeason: 'September - February',
    bannerImage: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1000&q=80',
    description: 'The coffee land of Karnataka, home to Mullayanagiri—the highest peak in the state—with breathtaking ridge hiking.',
    pois: [
      {
        id: 'poi-mullayanagiri-peak',
        name: 'Mullayanagiri Summit (1,930 m)',
        category: 'hills',
        latitude: 13.3912,
        longitude: 75.7214,
        description: 'Karnataka’s tallest peak with a small Shiva shrine at the summit, mist-laden trails, and cool mountain breezes.',
        emergencyContact: 'Hill Rescue / Police: 112',
        offlineAvailable: true
      },
      {
        id: 'poi-baba-budangiri',
        name: 'Baba Budangiri (Datta Peeta)',
        category: 'historical',
        latitude: 13.4218,
        longitude: 75.7682,
        description: 'Sacred mountain range famous for the Sufi shrine and the legend of the first coffee seeds planted in India.',
        emergencyContact: 'Chikmagalur Police: +91-8262-230401',
        offlineAvailable: true
      },
      {
        id: 'poi-jhari-falls',
        name: 'Jhari (Buttermilk) Falls',
        category: 'waterfalls',
        latitude: 13.3678,
        longitude: 75.7324,
        description: 'Serene secluded falls surrounded by dense woods and private plantations with refreshing natural mountain spray.',
        emergencyContact: 'Forest Patrol: 112',
        offlineAvailable: true
      },
      {
        id: 'poi-z-point',
        name: 'Z Point Kemmangundi',
        category: 'viewpoints',
        latitude: 13.5489,
        longitude: 75.7533,
        description: 'Thrilling cliff edge trail overlooking deep green valleys and Shanti Falls along the narrow pathway.',
        emergencyContact: 'Tarikere Forest Range: +91-8261-222300',
        offlineAvailable: true
      },
      {
        id: 'poi-ckm-hospital',
        name: 'Chikmagalur General Trauma Care',
        category: 'emergency',
        latitude: 13.3182,
        longitude: 75.7745,
        description: '24/7 Emergency trauma center, snake-bite antivenom facility, and round-the-clock ambulance.',
        emergencyContact: 'Hospital ER: 108 / +91-8262-230555',
        offlineAvailable: true
      }
    ]
  },
  {
    id: 'gokarna-trail',
    name: 'Gokarna Beach Trail',
    regionName: 'Gokarna Coastal Belt',
    state: 'Karnataka',
    country: 'India',
    latitude: 14.5436,
    longitude: 74.3188,
    category: 'beaches',
    difficulty: 'moderate',
    bestSeason: 'November - April',
    bannerImage: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1000&q=80',
    description: 'Golden sand beaches intersected by rocky seaside hills and ancient coastal temple heritage.',
    pois: [
      {
        id: 'poi-om-beach',
        name: 'Om Beach Shoreline',
        category: 'beaches',
        latitude: 14.5186,
        longitude: 74.3156,
        description: 'Iconic beach naturally shaped like the auspicious OM symbol, featuring calm waters, cliff rocks, and water sports.',
        emergencyContact: 'Coastal Lifeguard Post: +91-8386-256100',
        offlineAvailable: true
      },
      {
        id: 'poi-kudle-beach',
        name: 'Kudle Beach Cove',
        category: 'beaches',
        latitude: 14.5292,
        longitude: 74.3150,
        description: 'Gentle horseshoe-shaped bay flanked by palm-topped headlands, perfect for sunset walks and beach volleyball.',
        emergencyContact: 'Tourist Police Help: 112',
        offlineAvailable: true
      },
      {
        id: 'poi-half-moon-beach',
        name: 'Half Moon Beach & Cliff Path',
        category: 'viewpoints',
        latitude: 14.5122,
        longitude: 74.3214,
        description: 'Secluded cove accessible only by boat or hiking trail over the rocky hill pass from Om Beach.',
        emergencyContact: 'Coastal Guard: +91-8386-256222',
        offlineAvailable: true
      },
      {
        id: 'poi-mahabaleshwar-temple',
        name: 'Mahabaleshwar Temple',
        category: 'temples',
        latitude: 14.5428,
        longitude: 74.3182,
        description: '4th-century CE Dravidian temple housing the sacred Atmalinga facing the Arabian sea.',
        emergencyContact: 'Temple Office: +91-8386-256250',
        offlineAvailable: true
      },
      {
        id: 'poi-gokarna-clinic',
        name: 'Gokarna Primary Health & Emergency Centre',
        category: 'emergency',
        latitude: 14.5462,
        longitude: 74.3204,
        description: 'First aid, heatstroke treatment, dehydration rehydration, and ambulance transfer services.',
        emergencyContact: 'Clinic Line: 108 / +91-8386-256111',
        offlineAvailable: true
      }
    ]
  },
  {
    id: 'ooty-nilgiris',
    name: 'Ooty (Nilgiris)',
    regionName: 'Nilgiri Biosphere',
    state: 'Tamil Nadu',
    country: 'India',
    latitude: 11.4102,
    longitude: 76.6950,
    category: 'hills',
    difficulty: 'easy',
    bestSeason: 'September - May',
    bannerImage: 'https://images.unsplash.com/photo-1589182373726-e4f658ab50f0?auto=format&fit=crop&w=1000&q=80',
    description: 'The Queen of Hill Stations, crowned with fragrant eucalyptus forests, rolling tea gardens, and crisp alpine air.',
    pois: [
      {
        id: 'poi-doddabetta',
        name: 'Doddabetta Peak (2,637 m)',
        category: 'viewpoints',
        latitude: 11.4014,
        longitude: 76.7364,
        description: 'Highest mountain in Nilgiri Hills with an observatory telescope house showing panoramic views of Coimbatore plains.',
        emergencyContact: 'Forest Rescue: 112',
        offlineAvailable: true
      },
      {
        id: 'poi-pykara-falls',
        name: 'Pykara Waterfalls & Lake',
        category: 'waterfalls',
        latitude: 11.4883,
        longitude: 76.6022,
        description: 'Pristine mountain river cascading down in two separate falls through shola forests and grassy meadows.',
        emergencyContact: 'Pykara Boating Station: +91-423-2443977',
        offlineAvailable: true
      },
      {
        id: 'poi-ooty-lake',
        name: 'Ooty Boating Lake',
        category: 'lakes',
        latitude: 11.4072,
        longitude: 76.6853,
        description: 'Artificial lake constructed in 1824, flanked by eucalyptus groves and pedal-boating facilities.',
        emergencyContact: 'Ooty Central Police: +91-423-2442222',
        offlineAvailable: true
      },
      {
        id: 'poi-ooty-hospital',
        name: 'Nilgiris District Headquarters Hospital',
        category: 'emergency',
        latitude: 11.4135,
        longitude: 76.6998,
        description: '24/7 emergency unit, trauma center, oxygen supplies for altitude-related respiratory care.',
        emergencyContact: 'Emergency: 108 / +91-423-2442212',
        offlineAvailable: true
      }
    ]
  },
  {
    id: 'wayanad-chembra',
    name: 'Wayanad (Chembra Peak)',
    regionName: 'Wayanad High Plateau',
    state: 'Kerala',
    country: 'India',
    latitude: 11.5129,
    longitude: 76.0827,
    category: 'hills',
    difficulty: 'challenging',
    bestSeason: 'October - May',
    bannerImage: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1000&q=80',
    description: 'Highland plateau of Kerala boasting ancient rock petroglyphs, heart-shaped alpine lake, and spice trails.',
    pois: [
      {
        id: 'poi-chembra-lake',
        name: 'Chembra Heart-Shaped Alpine Lake',
        category: 'lakes',
        latitude: 11.5129,
        longitude: 76.0827,
        description: 'Natural heart-shaped perennial lake perched halfway up Chembra Peak with misty mountain reflections.',
        emergencyContact: 'Meppadi Forest Station: +91-4936-282210',
        offlineAvailable: true
      },
      {
        id: 'poi-edakkal-caves',
        name: 'Edakkal Neolithic Caves',
        category: 'historical',
        latitude: 11.6289,
        longitude: 76.2347,
        description: 'Prehistoric rock shelters with 8,000-year-old carvings from the late Stone Age, reached via steep hillside trail.',
        emergencyContact: 'Sulthan Bathery Police: +91-4936-220221',
        offlineAvailable: true
      },
      {
        id: 'poi-soochipara-falls',
        name: 'Soochipara (Sentinel Rock) Falls',
        category: 'waterfalls',
        latitude: 11.5117,
        longitude: 76.1606,
        description: 'Three-tiered waterfall descending into a large natural pool suitable for shallow bathing and photography.',
        emergencyContact: 'Forest Guard Help: 112',
        offlineAvailable: true
      },
      {
        id: 'poi-wayanad-clinic',
        name: 'Meppadi Community Health Centre',
        category: 'emergency',
        latitude: 11.5542,
        longitude: 76.1264,
        description: 'Trauma support, dehydration and wilderness injury treatment, 24/7 doctor on call.',
        emergencyContact: 'Ambulance: 108 / +91-4936-282240',
        offlineAvailable: true
      }
    ]
  },
  {
    id: 'jog-falls',
    name: 'Jog Falls (Shimoga)',
    regionName: 'Sharavathi Valley',
    state: 'Karnataka',
    country: 'India',
    latitude: 14.2285,
    longitude: 74.8124,
    category: 'waterfalls',
    difficulty: 'easy',
    bestSeason: 'August - December',
    bannerImage: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1000&q=80',
    description: 'India’s majestic untiered waterfall where four distinct cascades—Raja, Roarer, Rocket, and Rani—plunge into a deep gorge.',
    pois: [
      {
        id: 'poi-raja-viewpoint',
        name: 'Raja Viewpoint Platform',
        category: 'viewpoints',
        latitude: 14.2285,
        longitude: 74.8124,
        description: 'Main observation amphitheater presenting uninterrupted frontal perspective of the four cascades.',
        emergencyContact: 'Jog Falls Police: +91-8186-244222',
        offlineAvailable: true
      },
      {
        id: 'poi-sharavathi-sanctuary',
        name: 'Sharavathi Valley Wildlife Sanctuary',
        category: 'nature',
        latitude: 14.2120,
        longitude: 74.7890,
        description: 'Dense evergreen jungle hosting lion-tailed macaques, hornbills, and tranquil river backwaters.',
        emergencyContact: 'Wildlife Warden: +91-8186-222400',
        offlineAvailable: true
      },
      {
        id: 'poi-sagara-hospital',
        name: 'Sub-Divisional Hospital Sagara',
        category: 'emergency',
        latitude: 14.1682,
        longitude: 75.0298,
        description: 'Major regional medical facility with ICU, blood bank, ambulance transfer, and emergency trauma wing.',
        emergencyContact: 'Emergency: 108 / +91-8183-226222',
        offlineAvailable: true
      }
    ]
  }
];

export const CATEGORIES_LIST = [
  { id: 'all', label: 'All Sights', icon: 'Compass' },
  { id: 'waterfalls', label: 'Waterfalls', icon: 'Droplets' },
  { id: 'viewpoints', label: 'Viewpoints', icon: 'Eye' },
  { id: 'hills', label: 'Hills & Peaks', icon: 'Mountain' },
  { id: 'beaches', label: 'Beaches', icon: 'Waves' },
  { id: 'temples', label: 'Temples & Heritage', icon: 'Church' },
  { id: 'historical', label: 'Historical Places', icon: 'Landmark' },
  { id: 'parks', label: 'Parks & Gardens', icon: 'Trees' },
  { id: 'lakes', label: 'Lakes & Rivers', icon: 'Fish' },
  { id: 'nature', label: 'Nature Spots', icon: 'Leaf' },
  { id: 'emergency', label: 'Hospitals & Medical', icon: 'Cross' },
];
