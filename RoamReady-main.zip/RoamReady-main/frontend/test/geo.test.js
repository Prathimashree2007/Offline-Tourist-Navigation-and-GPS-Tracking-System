import { test, describe } from 'node:test';
import assert from 'node:assert';
import { 
  calculateHaversineDistance, 
  formatDistance, 
  calculateBoundingBox, 
  latLonToTile, 
  estimateStorageSize, 
  isValidGpsPoint,
  calculateTripSummary
} from '../src/utils/geo.js';

describe('RoamReady GIS and Mathematical Engine Tests', () => {
  
  test('Haversine distance between Madikeri and Abbey Falls', () => {
    // Madikeri (12.4244, 75.7382) to Abbey Falls (12.4542, 75.7196)
    const distKm = calculateHaversineDistance(12.4244, 75.7382, 12.4542, 75.7196, 'km');
    assert.ok(distKm > 3.5 && distKm < 4.5, `Abbey Falls distance ${distKm} km is realistic`);

    // In miles
    const distMiles = calculateHaversineDistance(12.4244, 75.7382, 12.4542, 75.7196, 'miles');
    assert.ok(distMiles > 2.0 && distMiles < 3.0, `Distance in miles ${distMiles} is accurate`);
  });

  test('Format distance helper', () => {
    assert.strictEqual(formatDistance(0.45, 'km'), '450 m');
    assert.strictEqual(formatDistance(4.52, 'km'), '4.5 km');
    assert.strictEqual(formatDistance(12.0, 'miles'), '7.5 mi');
  });

  test('Bounding box calculation for 10 km radius', () => {
    const bbox = calculateBoundingBox(12.4244, 75.7382, 10);
    assert.ok(bbox.maxLat > bbox.minLat);
    assert.ok(bbox.maxLon > bbox.minLon);
    assert.strictEqual(bbox.radiusKm, 10);
  });

  test('Slippy Map tile coordinate conversion', () => {
    const tile = latLonToTile(12.4244, 75.7382, 13);
    assert.strictEqual(typeof tile.x, 'number');
    assert.strictEqual(typeof tile.y, 'number');
    assert.strictEqual(tile.z, 13);
    assert.ok(tile.x > 0);
    assert.ok(tile.y > 0);
  });

  test('Storage size estimation for 5km, 10km, 25km, 50km', () => {
    const est5 = estimateStorageSize(5);
    const est10 = estimateStorageSize(10);
    const est25 = estimateStorageSize(25);
    const est50 = estimateStorageSize(50);

    assert.ok(est5.approxStorageMB < est10.approxStorageMB);
    assert.ok(est10.approxStorageMB < est25.approxStorageMB);
    assert.ok(est25.approxStorageMB < est50.approxStorageMB);
    assert.ok(est50.approxStorageMB <= 20, 'Max 50km storage is safe for mobile browsers');
  });

  test('GPS noise jump filtering', () => {
    const p1 = { latitude: 12.4244, longitude: 75.7382, timestamp: '2026-11-20T10:00:00Z', accuracy: 5 };
    // Physically plausible point (walking 10 meters in 5 seconds)
    const pValid = { latitude: 12.4245, longitude: 75.7383, timestamp: '2026-11-20T10:00:05Z', accuracy: 6 };
    assert.strictEqual(isValidGpsPoint(pValid, p1), true);

    // Erroneous tele-jumping point (10 km away in 2 seconds)
    const pJump = { latitude: 12.5244, longitude: 75.8382, timestamp: '2026-11-20T10:00:02Z', accuracy: 5 };
    assert.strictEqual(isValidGpsPoint(pJump, p1), false);

    // Inaccurate point with excessive uncertainty (>60m)
    const pInaccurate = { latitude: 12.4245, longitude: 75.7383, timestamp: '2026-11-20T10:00:05Z', accuracy: 95 };
    assert.strictEqual(isValidGpsPoint(pInaccurate, p1), false);
  });

  test('Trip summary calculation', () => {
    const points = [
      { latitude: 12.4244, longitude: 75.7382, timestamp: '2026-11-20T10:00:00Z' },
      { latitude: 12.4270, longitude: 75.7360, timestamp: '2026-11-20T10:10:00Z' },
      { latitude: 12.4300, longitude: 75.7340, timestamp: '2026-11-20T10:20:00Z' }
    ];

    const summary = calculateTripSummary(points);
    assert.ok(summary.totalDistanceKm > 0.5);
    assert.strictEqual(summary.totalDurationSeconds, 1200);
    assert.strictEqual(summary.pointCount, 3);
  });
});
