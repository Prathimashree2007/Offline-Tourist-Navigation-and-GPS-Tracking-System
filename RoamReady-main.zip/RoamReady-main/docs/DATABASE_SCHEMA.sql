-- ==============================================================
-- RoamReady: Database Schema (MySQL 8.0+)
-- Department of Information Science & Engineering Mini-Project
-- ==============================================================

CREATE DATABASE IF NOT EXISTS roamready_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE roamready_db;

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  avatar_url VARCHAR(255) DEFAULT NULL,
  preferred_distance_unit ENUM('km', 'miles') DEFAULT 'km',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_email (email)
) ENGINE=InnoDB;

-- 2. DESTINATIONS TABLE (Curated catalogue & dynamically discovered worldwide destinations)
CREATE TABLE IF NOT EXISTS destinations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  state VARCHAR(100) NOT NULL,
  country VARCHAR(100) DEFAULT 'India',
  latitude DECIMAL(10, 7) NOT NULL,
  longitude DECIMAL(10, 7) NOT NULL,
  category ENUM('hills', 'waterfalls', 'beaches', 'forests', 'temples', 'historical', 'lakes', 'viewpoints', 'parks', 'hotel', 'restaurant', 'emergency', 'other') NOT NULL,
  description TEXT,
  external_place_id VARCHAR(150) NULL,
  provider VARCHAR(50) DEFAULT 'curated',
  display_name TEXT NULL,
  source ENUM('curated', 'dynamic', 'user_saved') DEFAULT 'curated',
  banner_image VARCHAR(255),
  best_time_to_visit VARCHAR(100),
  difficulty_level ENUM('easy', 'moderate', 'challenging') DEFAULT 'moderate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dest_coords (latitude, longitude),
  INDEX idx_dest_category (category),
  INDEX idx_provider_ext_id (provider, external_place_id),
  INDEX idx_dest_source (source)
) ENGINE=InnoDB;

-- 3. DOWNLOADED_MAPS TABLE (Metadata of regions downloaded by users)
CREATE TABLE IF NOT EXISTS downloaded_maps (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  region_name VARCHAR(150) NOT NULL,
  destination_id INT NULL,
  center_lat DECIMAL(10, 7) NOT NULL,
  center_lon DECIMAL(10, 7) NOT NULL,
  radius_km DECIMAL(6, 2) NOT NULL,
  tile_count INT DEFAULT 0,
  storage_bytes BIGINT DEFAULT 0,
  min_zoom INT DEFAULT 11,
  max_zoom INT DEFAULT 15,
  poi_count INT DEFAULT 0,
  download_status ENUM('pending', 'downloading', 'completed', 'failed') DEFAULT 'completed',
  downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE SET NULL,
  INDEX idx_dl_user (user_id)
) ENGINE=InnoDB;

-- 4. TRAVEL_HISTORY TABLE (Recorded trips/journeys)
CREATE TABLE IF NOT EXISTS travel_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  trip_name VARCHAR(150) NOT NULL,
  start_lat DECIMAL(10, 7) NOT NULL,
  start_lon DECIMAL(10, 7) NOT NULL,
  end_lat DECIMAL(10, 7) NOT NULL,
  end_lon DECIMAL(10, 7) NOT NULL,
  start_location_name VARCHAR(150),
  end_location_name VARCHAR(150),
  total_distance_km DECIMAL(8, 3) NOT NULL,
  total_duration_seconds INT NOT NULL,
  average_speed_kmh DECIMAL(6, 2) DEFAULT 0.00,
  point_count INT NOT NULL DEFAULT 0,
  notes TEXT,
  started_at TIMESTAMP NOT NULL,
  ended_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_travel_user (user_id),
  INDEX idx_travel_dates (started_at)
) ENGINE=InnoDB;

-- 5. TRIP_POINTS TABLE (Granular GPS track waypoints)
CREATE TABLE IF NOT EXISTS trip_points (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  trip_id INT NOT NULL,
  latitude DECIMAL(10, 7) NOT NULL,
  longitude DECIMAL(10, 7) NOT NULL,
  altitude DECIMAL(7, 2) NULL,
  accuracy_meters DECIMAL(6, 2) NOT NULL,
  speed_mps DECIMAL(6, 2) NULL,
  recorded_at TIMESTAMP NOT NULL,
  point_order INT NOT NULL,
  FOREIGN KEY (trip_id) REFERENCES travel_history(id) ON DELETE CASCADE,
  INDEX idx_trip_point_order (trip_id, point_order)
) ENGINE=InnoDB;

-- 6. FAVOURITES TABLE (Saved tourist POIs or destinations)
CREATE TABLE IF NOT EXISTS favourites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  destination_id INT NULL,
  custom_place_name VARCHAR(150) NULL,
  place_category VARCHAR(50) NULL,
  latitude DECIMAL(10, 7) NOT NULL,
  longitude DECIMAL(10, 7) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE SET NULL,
  UNIQUE KEY unique_user_fav (user_id, destination_id, latitude, longitude)
) ENGINE=InnoDB;
