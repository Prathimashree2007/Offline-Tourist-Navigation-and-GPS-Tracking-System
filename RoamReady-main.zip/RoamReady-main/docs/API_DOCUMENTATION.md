# RoamReady — REST API Documentation
**Base URL**: `http://localhost:5000/api`

---

## 1. System Health & Diagnostics
### `GET /health`
Returns server operational status, database connectivity, and timestamp.

**Response `200 OK`**:
```json
{
  "status": "online",
  "service": "RoamReady REST API Backend",
  "timestamp": "2026-11-20T14:50:00.000Z",
  "mysql_connected": true,
  "node_version": "v24.11.1"
}
```

---

## 2. Authentication API (`/api/auth`)

### `POST /api/auth/register`
Creates a new user profile with bcrypt-hashed credentials.

**Request Body**:
```json
{
  "name": "Priya Sharma",
  "email": "priya@roamready.app",
  "password": "password123",
  "preferred_distance_unit": "km"
}
```

**Response `201 Created`**:
```json
{
  "success": true,
  "message": "User registered successfully.",
  "token": "eyJhbGciOi...",
  "user": {
    "id": 1,
    "name": "Priya Sharma",
    "email": "priya@roamready.app",
    "preferred_distance_unit": "km"
  }
}
```

### `POST /api/auth/login`
Authenticates user and returns JWT bearer token.

**Request Body**:
```json
{
  "email": "priya@roamready.app",
  "password": "password123"
}
```

**Response `200 OK`**:
```json
{
  "success": true,
  "message": "Login successful.",
  "token": "eyJhbGciOi...",
  "user": {
    "id": 1,
    "name": "Priya Sharma",
    "email": "priya@roamready.app",
    "preferred_distance_unit": "km"
  }
}
```

### `GET /api/auth/profile`
*(Requires `Authorization: Bearer <TOKEN>`)*
Returns authenticated user profile details.

---

## 3. Destinations API (`/api/destinations`)

### `GET /api/destinations/search`
Search destinations by keyword or category.

**Query Parameters**:
- `query` (optional): string e.g. "coorg"
- `category` (optional): "hills" | "waterfalls" | "beaches" | "temples"

**Response `200 OK`**:
```json
{
  "success": true,
  "count": 1,
  "destinations": [
    {
      "id": 1,
      "name": "Madikeri (Coorg)",
      "state": "Karnataka",
      "country": "India",
      "latitude": 12.4244,
      "longitude": 75.7382,
      "category": "hills",
      "description": "Lush highland hill station known for misty coffee plantations...",
      "best_time_to_visit": "October - March",
      "difficulty_level": "easy"
    }
  ]
}
```

---

## 4. Travel History API (`/api/trips`)
*(All endpoints require `Authorization: Bearer <TOKEN>`)*

### `POST /api/trips/sync`
Synchronizes a locally recorded GPS trail to MySQL database.

**Request Body**:
```json
{
  "trip_name": "Abbey Falls Trail",
  "destination_name": "Madikeri, Coorg",
  "start_lat": 12.4244,
  "start_lon": 75.7382,
  "end_lat": 12.4542,
  "end_lon": 75.7196,
  "total_distance_km": 4.82,
  "total_duration_seconds": 3420,
  "average_speed_kmh": 5.1,
  "started_at": "2026-11-20T10:00:00.000Z",
  "ended_at": "2026-11-20T10:57:00.000Z",
  "points": [
    { "latitude": 12.4244, "longitude": 75.7382, "timestamp": "...", "accuracy": 5 }
  ]
}
```

### `GET /api/trips`
Retrieves user travel history journeys.

### `DELETE /api/trips/:id`
Deletes a specific recorded trip.

---

## 5. Downloaded Maps Metadata API (`/api/maps`)
*(All endpoints require `Authorization: Bearer <TOKEN>`)*

### `POST /api/maps/sync`
Saves offline map download metadata to cloud.

### `GET /api/maps`
Retrieves user downloaded map region metadata.
