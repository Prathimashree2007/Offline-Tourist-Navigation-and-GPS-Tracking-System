-- ==============================================================
-- RoamReady: Seed Data for Curated Tourist Destinations
-- ==============================================================

USE roamready_db;

CREATE TABLE IF NOT EXISTS searched_destinations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    display_name TEXT,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    place_type VARCHAR(100),
    country VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_coordinates (latitude, longitude)
);