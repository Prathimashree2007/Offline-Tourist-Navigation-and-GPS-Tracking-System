# RoamReady — Installation & Setup Guide
**Offline Tourist Navigation & GPS Trail Companion**

---

## Prerequisites
- **Node.js**: v18.0.0 or higher (Tested on v24.11.1)
- **npm**: v9.0.0 or higher (Tested on 11.6.2)
- **MySQL Server**: 8.0 or higher (Optional for cloud sync; backend includes an internal resilient data store if MySQL is not running)
- **Modern Browser**: Chrome, Edge, Safari, or Firefox with Geolocation and IndexedDB support

---

## 1. Setup Backend Server

1. Open a terminal and navigate to the backend directory:
   ```bash
   cd roamready/backend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure environment variables in `.env` (a template is provided in `.env.example`):
   ```env
   PORT=5000
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=root
   DB_NAME=roamready_db
   JWT_SECRET=roamready_jwt_secure_super_secret_key_2026_ise
   ```
4. (Optional) Run MySQL schema setup if you wish to connect MySQL:
   ```bash
   mysql -u root -p < ../docs/DATABASE_SCHEMA.sql
   mysql -u root -p < ../docs/SEED_DATA.sql
   ```
5. Start the backend server:
   ```bash
   npm start
   # Or for development with automatic restart:
   npm run dev
   ```
   *Health Check URL*: `http://localhost:5000/api/health`

---

## 2. Setup Frontend Application

1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd roamready/frontend
   ```
2. Install frontend dependencies:
   ```bash
   npm install
   ```
3. Start the Vite development server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to:
   ```
   http://localhost:5173
   ```

---

## 3. How to Demonstrate in College Viva / Evaluations

1. **Online Preparation**:
   - Navigate to **Explore Dashboard** or **Destination Search**.
   - Search for **"Madikeri (Coorg)"**, **"Gokarna"**, or **"Mullayanagiri"**.
   - Click **"Plan Download"** and select a radius (e.g., 10 km).
   - Click **"Download Offline Region"** to watch the real-time tile download and POI persistence into IndexedDB.
2. **Offline Simulation**:
   - Click the **"Simulate Offline"** button on the map navigation screen or turn off your device's Wi-Fi.
   - The map remains fully interactive using tiles cached in IndexedDB.
   - Sights like Abbey Falls and Raja's Seat appear on the map with Haversine distance.
   - Panning outside the 10 km circle displays the boundary warning.
3. **GPS Trail Recording**:
   - Navigate to **GPS Tracker**.
   - Enable **Demo Simulator Mode** (simulates realistic trail walk).
   - Watch the route polyline draw point-by-point with live duration and speed.
   - Click **"Stop & Save"** to persist the journey into travel history.
4. **Travel History & GeoJSON Export**:
   - Navigate to **Trips** to review the recorded journey, inspect start/end pins, and click **"Export GeoJSON"**.
