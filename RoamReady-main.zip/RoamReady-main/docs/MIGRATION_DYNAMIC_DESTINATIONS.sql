-- ==============================================================
-- RoamReady: Database Migration for Worldwide Dynamic Destinations
-- Supports dynamic destination discovery, external geocoding IDs,
-- and duplicate detection without modifying existing seed records.
-- ==============================================================

USE roamready_db;

-- 1. Add columns to destinations table to support external geocoding providers
ALTER TABLE destinations
  ADD COLUMN IF NOT EXISTS external_place_id VARCHAR(150) NULL AFTER description,
  ADD COLUMN IF NOT EXISTS provider VARCHAR(50) DEFAULT 'curated' AFTER external_place_id,
  ADD COLUMN IF NOT EXISTS display_name TEXT NULL AFTER provider,
  ADD COLUMN IF NOT EXISTS source ENUM('curated', 'dynamic', 'user_saved') DEFAULT 'curated' AFTER display_name,
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

-- 2. Add composite index for quick provider + external ID deduplication lookups
ALTER TABLE destinations
  ADD INDEX IF NOT EXISTS idx_provider_ext_id (provider, external_place_id),
  ADD INDEX IF NOT EXISTS idx_dest_source (source);

-- 3. Ensure existing seed records are tagged as curated
UPDATE destinations SET source = 'curated', provider = 'curated' WHERE source IS NULL;
