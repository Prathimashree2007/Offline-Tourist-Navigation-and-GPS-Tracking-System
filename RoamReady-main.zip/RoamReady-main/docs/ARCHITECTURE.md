# RoamReady — Architecture Specification
**Offline Tourist Navigation & GPS Trail Companion**  
*Department of Information Science & Engineering*

---

## 1. System Overview & Problem Statement
Tourists visiting remote ecological, coastal, and highland destinations (waterfalls, mountain trails, dense reserves, isolated beaches) regularly experience degraded or absent cellular connectivity. Traditional web mapping applications (e.g., standard Google Maps or dynamic OSM web viewers) fail under these conditions:
1. Web map vector/raster tiles cannot be fetched over the network.
2. Geocoding and destination search APIs become unreachable.
3. Points of Interest (POIs) such as nearby viewpoints, emergency clinics, potable water, or historic landmarks are lost.
4. Traveled trail waypoints cannot be uploaded to remote cloud databases.

**RoamReady** resolves this with an **offline-first hybrid architecture**:
- **Pre-trip Preparation (Online Mode)**: Tourists search destinations, select an adaptive geographical radius (5 km, 10 km, 25 km, 50 km), and download the map tile pyramid (zoom levels 11–16) along with categorized POIs and emergency contact data directly into persistent browser storage.
- **On-Trail Navigation (Offline Mode)**: The application functions fully disconnected. MapLibre/Leaflet loads cached tiles from local IndexedDB and CacheStorage via a Service Worker. The browser's native Geolocation API tracks high-accuracy GPS coordinates without cellular data. Nearby POIs are queried in-memory and sorted using the spherical **Haversine formula**. Travel paths are recorded point-by-point and persisted locally.
- **Post-Trip Review & Synchronization**: Travel history and recorded GPS trails can be played back, inspected with elevation/speed statistics, managed locally, or synchronized with the backend MySQL database when internet connectivity is re-established.

---

## 2. Multi-Tier Architecture Diagram

```
+-----------------------------------------------------------------------------------+
|                              CLIENT TIER (PWA)                                    |
|                                                                                   |
|  +--------------------+   +-----------------------+   +------------------------+  |
|  |   React 18 + Vite  |   |    Tailwind UI / UX   |   |   Framer Motion        |  |
|  |   SPA Router       |   |  Forest Green Theme   |   |   Micro-interactions   |  |
|  +---------+----------+   +-----------+-----------+   +-----------+------------+  |
|            |                          |                           |               |
|            +--------------------------+---------------------------+               |
|                                       |                                           |
|       +-------------------------------+-------------------------------+           |
|       |                                                               |           |
|  +----+------------------+                               +------------+--------+  |
|  |  Interactive Map Engine|                               |  GPS Trail Recorder |  |
|  |  Leaflet / Map Engine  |                               |  Geolocation API    |  |
|  |  Custom IndexedDB      |                               |  Haversine Filter   |  |
|  |  Tile Layer Provider   |                               |  Live Distance/Dur. |  |
|  +----+------------------+                               +------------+--------+  |
|       |                                                               |           |
|  +----+---------------------------------------------------------------+--------+  |
|  |                          STORAGE & OFFLINE ENGINE                           |  |
|  |  - Service Worker (CacheStorage: App Shell, Styles, Icons, UI Assets)        |  |
|  |  - IndexedDB Layer (Stores: map_tiles, tourist_places, travel_history,      |  |
|  |                     downloaded_maps, favourites, user_settings)             |  |
|  +----+---------------------------------------------------------------+--------+  |
+-------|---------------------------------------------------------------|-----------+
        | (Online Sync / REST API)                                      |
        v                                                               v
+-----------------------------------------------------------------------------------+
|                             BACKEND TIER (Node.js)                                |
|                                                                                   |
|  +-----------------------------------------------------------------------------+  |
|  |  Express.js REST API Server                                                 |  |
|  |  - Auth Controller (JWT + Bcrypt Password Hashing)                          |  |
|  |  - Destination Controller (Search, Radius Bounding Box, POI Curated Feeds)  |  |
|  |  - Map Download Metadata Controller                                         |  |
|  |  - Travel History Sync Controller                                           |  |
|  +-------------------------------------+---------------------------------------+  |
|                                        |                                          |
+----------------------------------------|------------------------------------------+
                                         v
+-----------------------------------------------------------------------------------+
|                             PERSISTENCE TIER (MySQL)                              |
|                                                                                   |
|  Tables: users, destinations, downloaded_maps, travel_history, trip_points,      |
|          favourites                                                              |
+-----------------------------------------------------------------------------------+
```

---

## 3. Legal & Technically Sound Offline Map Strategy
OpenStreetMap tile usage policy strictly prohibits bulk automated scrapers. To ensure technical correctness, academic integrity, and operational legality:
1. **Bounded Regional Pyramid Extraction**: Downloads are strictly constrained to user-selected destination coordinates and discrete radii (5 km, 10 km, 25 km, 50 km).
2. **Tile Calculation**:
   Given latitude $\phi$, longitude $\lambda$, and zoom level $z$:
   $$x = \left\lfloor \frac{\lambda + 180}{360} \cdot 2^z \right\rfloor$$
   $$y = \left\lfloor \left(1 - \frac{\ln(\tan(\phi \cdot \frac{\pi}{180}) + \sec(\phi \cdot \frac{\pi}{180}))}{\pi}\right) \cdot 2^{z-1} \right\rfloor$$
3. **Adaptive Zoom Sampling**:
   - For 5–10 km: Zoom levels 12 to 15 (high detail for trails, forest paths, POIs).
   - For 25–50 km: Adaptive zoom sampling (levels 11 to 14) to maintain safe storage footprints (under 40 MB).
4. **Permanent Local Persistence**:
   - Tiles are stored as `Blob` objects in IndexedDB under store `map_tiles` keyed by `${regionId}_${z}_${x}_${y}`.
   - The custom Map TileLayer checks IndexedDB first. If available, it creates an object URL and renders instantaneously with zero network overhead.
   - If the user moves outside the downloaded bounding box, the map draws an explicit **Coverage Boundary Circle** and displays a prominent coverage warning. No misleading fake data or silent online fallbacks occur.
5. **Pre-Bundled Academic Demo Regions**:
   - Includes full offline demo packages for key destinations (e.g., Coorg / Abbey Falls / Madikeri, Ooty / Nilgiris, Gokarna Beaches, Chikmagalur Hills) with real pre-cached tile packages and rich POI datasets for viva demonstration without internet.

---

## 4. Distance Calculation via Haversine Formula
The great-circle distance between two GPS points $(\phi_1, \lambda_1)$ and $(\phi_2, \lambda_2)$ with Earth radius $R = 6371.0 \text{ km}$:
$$\Delta \phi = (\phi_2 - \phi_1) \cdot \frac{\pi}{180}$$
$$\Delta \lambda = (\lambda_2 - \lambda_1) \cdot \frac{\pi}{180}$$
$$a = \sin^2\left(\frac{\Delta \phi}{2}\right) + \cos\left(\phi_1 \cdot \frac{\pi}{180}\right) \cdot \cos\left(\phi_2 \cdot \frac{\pi}{180}\right) \cdot \sin^2\left(\frac{\Delta \lambda}{2}\right)$$
$$c = 2 \cdot \text{atan2}\left(\sqrt{a}, \sqrt{1 - a}\right)$$
$$d = R \cdot c$$
In the UI, this is strictly labeled as **"Approximate distance (straight-line)"** with an informative banner explaining that topographic terrain or winding mountain paths require following local trail markers.
