# RoamReady demo script (offline mode)

1. While ONLINE: Search -> pick destination -> Plan Map -> choose radius -> Download.
   Wait for "Saving offline routes" to finish (tiles, places and road routes are saved on the device).
2. Open Offline Map. Turn on "Simulate Offline" (or switch on flight mode).
3. Tap a place marker -> "Show route to this place" (green line = saved road route, orange dashed = direction only).
4. Tap the pin button -> Nearby: closest places sorted by distance, filter by category, tap Route.
5. Pin button -> My pins: save hotel/parking at your position; it appears on the map and works offline.
6. Red SOS button: coordinates, send by SMS, emergency numbers, nearest emergency places.
7. GPS Tracking: start a trip (Demo Simulator for class, Battery saver for long treks) -> stop and save.
8. Travel History -> open a trip -> Export GPX / GeoJSON, or delete.
9. Map Management: storage used per region, update when online, delete.
